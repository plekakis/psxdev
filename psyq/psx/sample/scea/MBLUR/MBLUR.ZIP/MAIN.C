/*******************************************************************
 *
 *    DESCRIPTION: Motion Blur Demo
 *
 *    AUTHOR:	   dc 7/14/98
 *
 *    Explanation
 *    Heres a simple motion blur example..
 *	  This is how it works:
 *	  The back drop image is rendered to the current frame buffer at 50% 
 *	  brightness.
 *	  Then the previous frame ( the back drop image with the foreground
 *	  objects already rendered on it is rendered to the current frame buffer.
 *	  The result is that the back ground image is now combined to reach 100%
 *	  brightness but the foreground objects are not so bright...
 *	  Then the current frames foreground objects are rendered over the top of
 *	  the image.
 *	  The cool thing about this is that you can have the blur effect on 3d 
 *	  objects as well as on simple sprites and you don't have to do it against
 *	  a solid background.
 *	  Of course its hideously inefficient and couldn't be used for much other 
 *	  than the front end.
 *
 *    HISTORY:    
 *    Urrr No photoshop on my machine so I nabbed this awful picture from the
 *    net.... 
 *    note the weird trails left by the yellow over the blue parts of the mars
 *    lander. I guess the blue is too saturated.... 
 *	  This is all a bit of a hack.
 *******************************************************************/

#include <r3000.h>
#include <asm.h>
#include <kernel.h>
#include <sys/file.h>
#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libetc.h>
#include <libcd.h>
#include <libsn.h>
#include <libsnd.h>
#include <libmath.h>

#include "main.h"
#include "ctrller.h"

/**----- globals ------------------------------------------------------**/
DB		db[2];			/* packet double buffer */
DB* 	cdb;			/* current db */
ControllerPacket buffer1, buffer2;

extern unsigned long	surrealtim[]; 
extern unsigned long	spritetim[]; 

#define MAX_FT4 512
POLY_FT4 poly_store[2][MAX_FT4];
POLY_FT4* ft4_p;

int frame_counter=0;
int frame=0;

void draw_back_drop(char trans);
void draw_previous_frame(char trans);
void init_balls(void);
void draw_balls(void);


/**---------------------------------------------------------------------**/
/**---------------------------------------------------------------------**/
/**---------------------------------------------------------------------**/
main()
{

ResetCallback();	
init_graph();	
InitPAD(&buffer1,MAX_CONTROLLER_BYTES,&buffer2,MAX_CONTROLLER_BYTES);
StartPAD();

load_texture(surrealtim);
load_texture(spritetim);
init_balls();

do{
   	frame_counter++;
	frame = (frame==0)? 1: 0;			
	cdb = (cdb==db)? db+1: db;			
	ClearOTagR(db[frame	].ot, OTSIZE);		

	ft4_p = &poly_store[frame][0];
	FntPrint("Motion Blur Demo\n");
	draw_balls();
	draw_back_drop(64);
	draw_previous_frame(64);
   	FntFlush(-1);		
   	DrawSync(0);						
   	VSync(0);							
   	PutDrawEnv(&db[frame].draw); 		
   	PutDispEnv(&db[frame].disp); 		
   	DrawOTag(db[frame].ot+OTSIZE-1);	  			
}while(1);


}
/**-------------------------------------------------------------------------**/


/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
void draw_back_drop(char trans)
{
setPolyFT4(ft4_p);
setSemiTrans(ft4_p,1);
setUVWH(ft4_p,0,0,255,239);
setXYWH(ft4_p,0,0,255,239);
setRGB0(ft4_p,trans,trans,trans);
ft4_p->tpage = getTPage(2,1,320,0);	
AddPrim(db[frame].ot+1,ft4_p);   
ft4_p++;

setPolyFT4(ft4_p);
setSemiTrans(ft4_p,1);
setUVWH(ft4_p,  0,0,64,239);
setXYWH(ft4_p,255,0,64,239);
setRGB0(ft4_p,trans,trans,trans);
ft4_p->tpage = getTPage(2,1,576,0);	
AddPrim(db[frame].ot+1,ft4_p);   
ft4_p++;

}
/**-------------------------------------------------------------------------**/

/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
void draw_previous_frame(char trans)
{
setPolyFT4(ft4_p);
setSemiTrans(ft4_p,1);
setUVWH(ft4_p,0,0,255,239);
setXYWH(ft4_p,0,0,255,239);
setRGB0(ft4_p,trans,trans,trans);
if(frame==0)
	ft4_p->tpage = getTPage(2,1,0,256);	
else
	ft4_p->tpage = getTPage(2,1,0,0);	
AddPrim(db[frame].ot+1,ft4_p);   
ft4_p++;

setPolyFT4(ft4_p);
setSemiTrans(ft4_p,1);
setUVWH(ft4_p,  0,0,64,239);
setXYWH(ft4_p,255,0,64,239);
setRGB0(ft4_p,trans,trans,trans);
if(frame==0)
	ft4_p->tpage = getTPage(2,1,256,256);	
else
	ft4_p->tpage = getTPage(2,1,256,0);	

AddPrim(db[frame].ot+1,ft4_p);   
ft4_p++;


}
/**-------------------------------------------------------------------------**/

#define MAX_BALLS 12

SVECTOR ball_pos[MAX_BALLS];
SVECTOR ball_vec[MAX_BALLS];

/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
void init_balls(void)
{
short i;

for(i=0; i<MAX_BALLS; i++)
	{
	ball_pos[i].vx = rand()%320;
	ball_pos[i].vy = rand()%240;
	ball_vec[i].vx = -8+rand()%16;
	ball_vec[i].vy = -8+rand()%16;
	}
}
/**-------------------------------------------------------------------------**/

/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
/**-------------------------------------------------------------------------**/
void draw_balls(void)
{
short i;

for(i=0; i<MAX_BALLS; i++)
	{
	ball_pos[i].vx +=ball_vec[i].vx; 
	ball_pos[i].vy +=ball_vec[i].vy; 
	if (ball_pos[i].vx>320) ball_vec[i].vx*=-1;
	if (ball_pos[i].vx<  0) ball_vec[i].vx*=-1;
	if (ball_pos[i].vy>240) ball_vec[i].vy*=-1;
	if (ball_pos[i].vy<  0) ball_vec[i].vy*=-1;

	setPolyFT4(ft4_p);
	setSemiTrans(ft4_p,0);
	setUVWH(ft4_p,  0,0, 32, 32);
	setXYWH(ft4_p, ball_pos[i].vx,ball_pos[i].vy,32, 32);
	setRGB0(ft4_p,127,127,127);
	ft4_p->tpage = getTPage(2,1,650,0);	
	AddPrim(db[frame].ot+1,ft4_p);   
	ft4_p++;
	}
}
/**-------------------------------------------------------------------------**/

