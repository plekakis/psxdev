
Widescreen made easy!

A small addition to libgs to allow the aspect ratio to be set.

Includes:
 * header, object & codewarrior library
 * 3D example for both command line tools & codewarrior

coming soon... a modified sprite scaling function to support different aspect ratios.

Mark Baker, SCEE
24/9/98