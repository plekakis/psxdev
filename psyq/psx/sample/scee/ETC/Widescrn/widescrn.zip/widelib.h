/*
 * widelib.h
 *
 * Mark Baker 9/9/98
 */

#ifndef __WIDELIB_H
#define __WIDELIB_H

#include <sys/types.h>
#include <libgte.h>		/* LIBGS uses libgte */
#include <libgpu.h>		/* LIBGS uses libgpu */
#include <libgs.h>		/* for LIBGS */

/* GsSetAspectRatio function
 *
 * allows the normal aspect ratio of 4:3 to be changed, allowing widescreen 16:9 mode
 * and others (should they be needed!)
 */

extern void GsSetAspectRatio (short horizontal, short vertical);

/*
 * coming soon...
 *
extern void GsSetSpriteDefaultScale (short scalex, short scaley);
extern void GsSortDefaultScaleSprite (GsSPRITE * sprite, GsOT * ot, u_short pri);
 */

#endif