/*
 *          LoadExec Dual Shock MENU Sample Program
 *
 *      Copyright (C) 1995 by Sony Computer Entertainment Inc.
 *          All rights Reserved
 *
 *   Version    Date
 *  ------------------------------------------
 *  1.00        Mar,09,1995 yoshi
 *  1.01        Mar,15,1995 suzu
 *	1.02		Jun,29,1998 Mike
 *
 * child program execute sample. In this example, we present two way.
 *      1) use Exec() after loading by CD function. (child program loaded
 *			into spare area of memory)
 *      2) use LoadExec(). (child program is loaded over parent.)
 * Version 1.02 modified all pad functions to make use of Dual Shock
 * expanded library. All programs correctly reset controller to 
 * previous state oafter Load - Exec or LoadExec
 *===============================================================
 */
#include <sys/types.h>
#include <sys/file.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libpad.h>

u_long _ramsize = 0x00200000;
u_long _stacksize = 0x0000400;

// title string screen position
#define TITLE_X 100
#define TITLE_Y 32

#define PADMESG_X 	30
#define PADMESG_Y	200

#define MENU_X 260
#define MENU_Y 64
#define FSIZE 16
#define MARG 40

#define PAD_A_SELECT 0x00000100
#define PAD_A_START 0x00000800
#define PAD_A_UP 0x00001000
#define PAD_A_DOWN 0x00004000


#define H_SIZE 2048 //  EXEfile header size
// stack pointer of child EXE.
#define STACKP 0x8017fff0	// over parent's stack
#define STACKP2 0x801ffff0	//  not over parent's stack
static struct XF_HDR *head;     //  header of child EXE

typedef struct demo {
  char *s;		// demo title displayed in menu
  char *fn;		// child executable path and file name
  int	loadflag;	// 0: run child EXE by cdload() & Exec()
					// 1: run child EXE by LoadExec()
} DMENU;

#define MENU_MAX 4

// { demo title, EXEfile name, load-flag }
static DMENU dm[MENU_MAX] = {
  { "BALLS",	"\\EXECMENU\\BALLS.EXE;1",0 },
  { "RCUBE",	"\\EXECMENU\\RCUBE.EXE;1",0 },
  { "BALLS2",	"\\EXECMENU\\BALLS2.EXE;1",1 },
  { "RCUBE2",	"\\EXECMENU\\RCUBE2.EXE;1",1 },
};

typedef struct {
  DRAWENV draw;
  DISPENV disp;
  long x,y;
} DB;

static DB db[2];
static DR_MODE  mode;
static SPRT_16  sprt;

// pad buffers
static unsigned char padbuff[2][34];

// Dual Shock values
unsigned char Motor[2];
int portNo = 0;
static unsigned char align[6]={0,1,0xFF,0xFF,0xFF,0xFF};
#define DUALSHOCKMODE ((u_long *)0x80010000)
unsigned long *storedMode = DUALSHOCKMODE;
int ctr;

// function prototypes
void InitGraphics(void);
int handlePad(int portNo,u_char *buffer);


main()
{
  int	x, y, c;
  long pad,padd,padr;
	long i,j;
  char title[] = "PlayStation Dual Shock Sample";
  DB *cdb;
  unsigned char co1,co2,co3;	
  POLY_G4 g4;
  char fname[128];

	while(1)
	{
	    ResetCallback();
	    CdInit();

	//    PadInit(0);
		PadInitDirect(padbuff[0],padbuff[1]);
		PadStartCom();
		initShock();

		InitGraphics();

	    cdb = &db[0];
	    co1 = 255;
	    co2 = 0;
	    co3 = 0;
	    i = 0;

	    while(1)
	    {

			cdb = ( cdb == &db[1] ) ? &db[0] : &db[1];  
			PutDrawEnv(&cdb->draw);
			PutDispEnv(&cdb->disp);

			SetPolyG4(&g4);
			setXYWH(&g4, 0, 0, 640, 240);
			setRGB0(&g4, co1, co2, co3);
			setRGB1(&g4, co3, co1, co2);
			setRGB2(&g4, co2, co3, co1);
			setRGB3(&g4, co1, co2, co3);
			DrawPrim(&g4);

			// cycle colours on background
			if( co3 == 0 && co1 > 0 )
	      	{
				co1--;
				co2++;
			}
			if( co1 == 0 && co2 > 0 )
			{
				co2--;
				co3++;
			}
			if( co2 == 0 && co3 > 0 )
			{
				co3--;
				co1++;
			}

			Puts(TITLE_X,TITLE_Y,title);

			for( j=0;j<MENU_MAX;j++ )
			{
				y = j*FSIZE + MENU_Y;
				Puts(MENU_X,y,dm[j].s);
			}

			if( i < 0 ) i = MENU_MAX-1;
			if( i >= MENU_MAX ) i = 0;
		
			y = i*FSIZE + MENU_Y;
			Puts(MENU_X-MARG,y,">>");

			padr = handlePad(0,padbuff[0]);
			pad = padr & ~padd;
			padd = padr;

			// select ends menu program
			if ( pad & PADselect )
			{
				PadStopCom();
				ResetGraph(3);
				StopCallback();
				return 0;
			}

			if (pad & PAD_A_START)
			{

				if( !dm[i].loadflag )
				{
					printf("cdload:%s\n",dm[i].fn);
					// load EXEfile by CD function.
					if(cdload(dm[i].fn))
						goto error;
					ResetGraph(3);
					PadStopCom();
					printf("Pad Stopped, pretending to take a long time to load..\n");
					// pause for at least four seconds to simulate long load
					VSync(240);
					StopCallback();
					// child's stack pointer = STACKP
					(head->exec).s_addr = STACKP;
					(head->exec).s_size = 0;
					EnterCriticalSection();
					printf("EXEC!\n");
					Exec(&(head->exec),1,0);
					// If escape from child's main(), it's returned here.
					printf("RET!\n");
					// do again from initialization.
					break;
				}
				else
				{
					strcpy(fname,"cdrom:");	// need 'cdrom:'
					strcat(fname,dm[i].fn);
					ResetGraph(3);
					PadStopCom();
					printf("Pad Stopped, pretending to take a long time to load..\n");
					// pause for at least four seconds to simulate long load
					VSync(240);
					StopCallback();
					// need _96_init(), because open() & read() are called in LoadExec().
					_96_init();
					printf("LoadExec:%s\n",fname);
					// child's stack pointer = STACKP2
					LoadExec(fname,STACKP2,0);
					// If escape from child's main(), it's returned here.
					break;
				}
			}

			if(pad & PAD_A_UP)
				i--;
			if( (pad & PAD_A_DOWN) || (pad & PAD_A_SELECT) )
				i++;
			error:
				VSync(0);
		}
	}
}

/*
*
*       NAME            void InitFont(int tx, int ty, int cx, int cy)
*
*       FUNCTION        Initialises graphical font for menu
*
*       NOTES           Copied from original EXECMENU sample
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       29/06/98        Mike Kav        Created
*
*/
void InitFont(int tx, int ty, int cx, int cy)
{
  extern u_long fonttex[];
	
  u_short	tpage, clut;
	
  tpage = LoadTPage(fonttex+0x80, 0, 1, tx, ty, 256,256);
  clut  = LoadClut(fonttex, cx, cy);
	
  SetDrawMode(&mode, 0, 0, tpage, 0);
  SetSprt16(&sprt);
  SetSemiTrans(&sprt, 1);
  SetShadeTex(&sprt, 1);
  sprt.clut = clut;
  return;
}

	
Puts(x, y, s)
int	x, y;
char	*s;
{
  int	code, u, v;
	
  DrawPrim(&mode);
  while (*s) {
    code = *s - '0' + 48;
    v = (code%16)*16;
    u = (code/16)*16;
    setUV0(&sprt, u, v);
    setXY0(&sprt, x, y);
    DrawPrim(&sprt);
		
    s++;
    x += 16;
  }
}

int
cdload(file)

char *file;
{
  CdlFILE	fp;	// file location & size
  int	mode = CdlModeSpeed;	
  char hbuf[H_SIZE];		// buffer of EXE-header
  unsigned long offset;		// sector location
  int cnt,i;

  for (i = 0; i < 10; i++) {	/* 10 times retry :: ���g���C�� 10 �� */
    if (CdSearchFile(&fp, file) == 0) 
      continue;

    /* set target position :: �^�[�Q�b�g�|�W�V������ݒ� */
    CdControl(CdlSetloc, (u_char *)&(fp.pos), 0);
    cnt = _read1(H_SIZE,(void *)hbuf,mode); /* read EXE-header :: EXE�w�b�_���[�h */
    if(cnt)
      continue;

    head = (struct XF_HDR *)hbuf;		

    printf("pc = %08x\n",(head->exec).pc0);
    printf("t_addr = %08x\n",(head->exec).t_addr);
    printf("t_size = %08x\n",(head->exec).t_size);

    /* 
    /* LOC�����΃Z�N�^�ɒ����A�P�Z�N�^�iEXE�t�@�C���̃w�b�_���j
       �@�C���N�������g������A�Ă�LOC���ɒ��� */


    offset = CdPosToInt(&fp.pos);
    offset++;
    CdIntToPos(offset,&fp.pos);

    /* set target position :: �^�[�Q�b�g�|�W�V������ݒ� */
    CdControlB(CdlSetloc, (u_char *)&(fp.pos), 0);
    /* read program :: �v���O���������[�h */
    cnt = _read1((head->exec).t_size,(void *)((head->exec).t_addr),mode);

    /* If it success, return. :: ����I���Ȃ�΃u���[�N */
    if (cnt == 0)	return(0);
  }
  printf("%s: can not read\n", file);	
  return(0);
}


int
_read1(byte,sectbuf,mode)

long byte;
void *sectbuf;
int mode;
{	
	int nsector,cnt;
	unsigned char com;

	nsector = (byte+2047) / 2048;

	com = mode;
	CdControlB( CdlSetmode, &com, 0 );
	VSync( 3 );

	/* read start :: ���[�h�J�n */
	CdRead(nsector, sectbuf, mode);

	while ((cnt = CdReadSync(1, 0)) > 0 ) {
		VSync(0);
	}

	return(cnt);
}

void InitGraphics(void)
{
    ResetGraph(0);		// reset graphic subsystem (0:cold,1:warm)
    SetGraphDebug(0);	// set debug mode

    SetDefDrawEnv(&(db[0].draw), 0,   0, 640, 240);
    SetDefDrawEnv(&(db[1].draw), 0, 240, 640, 240);
    SetDefDispEnv(&(db[0].disp), 0, 240, 640, 240);
    SetDefDispEnv(&(db[1].disp), 0,   0, 640, 240);
    db[0].x = 0;
    db[0].y = 0;
    db[1].x = 0;
    db[1].y = 240;

    SetDispMask(1);

	InitFont(640, 0, 0, 481);

	return;
}

// Does not use multitap
int handlePad(int portNo,u_char *buffer)
{	
	int padState;
	int button;
	int set;
	char Motor0Str[12];
	char Motor1Str[12];
	int currentPad;
	int offs;
	int maxID;
	int savedID;

#define DEBUG 1

#ifdef DEBUG
	int flop;
	static int bs = 0;
	static ringbuff[10] = { -1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
	char temp[5];
#endif
	padState = PadGetState(portNo);


#ifdef DEBUG

		if(padState != ringbuff[bs]) {
			bs = (bs+1) % 10;
			ringbuff[bs] = padState;
		}
		flop = (bs + 1) % 10;
		for(set = 0; set < 10; set++) {
			if(ringbuff[flop] == -1) {
				sprintf(temp,"-1");
				Puts(70,set*20,temp);
				
			} else {
				sprintf(temp,"%d",ringbuff[flop]);
				Puts(70,set*20,temp);
			}
			flop = (flop + 1) % 10;
		}
#endif

	if(padState==PadStateDiscon)
	{

		Puts(PADMESG_X,PADMESG_Y,"No Pad Connected");
		return 0;
	}

	if(padState==PadStateFindPad)
	{
		Puts(PADMESG_X,PADMESG_Y,"Pad State Find Pad");

		// Set actuators if Dual Shock or old vibrator
		set = 0;
		while(!set)
		{
			if(PadGetState(portNo) == PadStateStable)
			{
				if(PadInfoMode(portNo,InfoModeCurExID,0))
				{
					PadSetAct(0x00,Motor,2);
					while( PadSetActAlign(0x00,align) == 0)
					{
						for(ctr=0;ctr<6;ctr++)
							VSync(0);
					}
				}
				set = 1;
			}
			if(PadGetState(portNo) == PadStateFindCTP1)
			{
				printf("Found Normal Controller\n");
				set = 1;
			}


		}
		return 0;
	}

	// ignore received data when communication failed
	if(*buffer)
	{
		return 0;
	}

	button = ~((buffer[2]<<8) | buffer[3]);

	currentPad = PadInfoMode(portNo,InfoModeCurExID,0);
	if((currentPad == 4) || (currentPad==7) )
	{
		// Dual Shock connected
		Puts(PADMESG_X,PADMESG_Y,"Dual Shock Connected");

		sprintf(Motor0Str,"Motor0 %03d",Motor[0]);
		Puts(400,180,Motor0Str);

		sprintf(Motor1Str,"Motor1 %03d",Motor[1]);
		Puts(400,200,Motor1Str);
	}
	else
	{
		// Normal controller of some type connected
		currentPad = PadInfoMode(portNo,InfoModeCurID,0) +10;

		switch(currentPad)
		{
		case 14:
		{
			Puts(PADMESG_X,PADMESG_Y,"Standard Pad Connected");
			break;
		}
		case 17:
		{
			Puts(PADMESG_X,PADMESG_Y,"Old Analog Pad Connected");
			break;
		}
		default:
		{
			Puts(PADMESG_X,PADMESG_Y,"Unhandled Pad Connected");
			return 0;
		}
		}

	}

	if((button & PADRdown) && ((currentPad == 4) || (currentPad == 7)) )
	{
		// vibrate actuator 0 (can only be on or off)
		if(Motor[0] == 1)
			Motor[0] = 0;
		else
			Motor[0] = 1;

		PadSetAct(0x00,Motor,2);

	}
	if((button & PADRup) && ((currentPad == 4) || (currentPad == 7)) )
	{
		// vibration off
		Motor[0] = 0;
		Motor[1] = 0;
		PadSetAct(0x00,Motor,2);

	}
	if((button & PADRleft) && ((currentPad == 4) || (currentPad == 7))  )
	{
		// vibration
		if(Motor[1] != 0)
			Motor[1] --;

		PadSetAct(0x00,Motor,2);

	}
	if((button & PADRright) && ((currentPad == 4) || (currentPad == 7)) )
	{
		// vibration
		if(Motor[1] != 255)
			Motor[1] ++;
		PadSetAct(0x00,Motor,2);
	}

	if((button & PADR2) && ((currentPad == 4) || (currentPad == 7)) )
	{
                PadSetMainMode(0x00,1,2);
	}

	if((button & PADR1) && ((currentPad == 4) || (currentPad == 7)) )
	{
		savedID = PadInfoMode(0x00,InfoModeCurExID,0);
		printf("Saved:%d\n",savedID);

		maxID = PadInfoMode(0x00,InfoModeIdTable,-1);
		printf("Max:%d\n",maxID);

		for(offs=0;offs<maxID;offs++)
		{
		printf("%dMax:%d\n",offs,PadInfoMode(0x00,InfoModeIdTable,offs));
		}

		PadStopCom();
		printf("Pad Stopped, pausing..");
		// pause for five seconds
		VSync(300);
		printf("Pad Restarting\n");
		PadStartCom();
		VSync(5);
		maxID = PadInfoMode(0x00,InfoModeIdTable,-1);
		printf("Max:%d\n",maxID);

		for(offs=0;offs<maxID;offs++)
		{
			printf("Entry:%d Searching for:%d, Mode:%d\n",offs,savedID,PadInfoMode(0x00,InfoModeIdTable,offs));
		
			if( PadInfoMode(0x00,InfoModeIdTable,offs) == savedID)
			{
				printf("Found Match:%d\n",offs);
				VSync(6);
				PadSetMainMode(0x00,offs,2);
				break;

			}
		}
		printf("Finished Dual Shock Setup\n");
	}

	if((button & PADstart))
	{
		if( (currentPad == 4) || (currentPad == 7) )
		{
			*storedMode = PadInfoMode(0x00,InfoModeCurExID,0);
			printf("Storing Dual Shock Mode:%d\n",*storedMode);
		}
		else
		{
			*storedMode = 0;
			printf("Clearing Dual Shock Mode:%d\n",*storedMode);
		}
	}

	return button;

}


initShock()
{
	int offs;
	int maxID;
	int set;

	// ReInit Dual Shock if required
	printf("%d\n",*storedMode);
	VSync(20);
	maxID = PadInfoMode(0x00,InfoModeIdTable,-1);
	printf("Max:%d\n",maxID);
	VSync(5);

	for(offs=0;offs<maxID;offs++)
	{
		printf("Entry:%d Searching for:%d, Mode:%d\n",offs,*storedMode,PadInfoMode(0x00,InfoModeIdTable,offs));
	
		if( PadInfoMode(0x00,InfoModeIdTable,offs) == *storedMode)
		{
			printf("Found Match:%d\n",offs);
			VSync(6);
			PadSetMainMode(0x00,offs,2);
			break;

		}
	}

	// Wait till it's stable
	set = 0;
	while(!set)
	{
		if(PadGetState(portNo) == PadStateStable)
		{
			if(PadInfoMode(portNo,InfoModeCurExID,0))
			{

				PadSetAct(0x00,Motor,2);
				VSync(20);
				while( PadSetActAlign(0x00,align) == 0)
				{
					for(ctr=0;ctr<6;ctr++)
						VSync(0);
				}
			}
			set = 1;
		}
		if(PadGetState(portNo) == PadStateFindCTP1)
		{
			printf("Found Normal Controller\n");
			set = 1;
		}
	}

	printf("Finished Dual Shock Setup\n");

}
