#include <sys/types.h>
#include <sys/file.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libpad.h>
#include <stdio.h>
#include "main.h"
#include "graphics.h"

#define NONE	-1
#define DIRECT	0
#define MULTI	1
#define SCRWIDTH 640

#ifdef NTSC
#define SCRHEIGHT 240
#else
#define SCRHEIGHT 256
#endif

POLY_FT4 poly1;
POLY_FT4 poly2;
int tpage_x, tpage_y;

static POLY_FT4	*sp;
static POLY_F4			*sp2;				// pointer, non-textured polys
extern unsigned long	DualShockTIM[];		// picture inbin'd from	 datafile
static u_long			*ot;				// pointer, current OT
extern long				fIdA;				// Applic font id.
extern DCONTROL			ControlSet[4];		// Pad control
extern int				DualShockload;
extern unsigned char	padbuff[2][34];		// pad buffers
TEXTURE_INFO			texture;			// Texture structure for dual shock texture

/*
*
*       NAME            void InitGraphics(DB *db0, DB *db1)
*
*       FUNCTION        Initialises graphical Env
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
void InitGraphics(DB *db0, DB *db1)
{
    SetDefDrawEnv(&db0->draw, 0,   0, SCRWIDTH, 256);
    SetDefDrawEnv(&db1->draw, 0, 256, SCRWIDTH, 256);
    SetDefDispEnv(&db0->disp, 0, 256, SCRWIDTH, 256);
    SetDefDispEnv(&db1->disp, 0,   0, SCRWIDTH, 256);

	setRECT(&db0->disp.screen, 0, 18, 0, 256);	
	setRECT(&db1->disp.screen, 0, 18, 0, 256);	

	// Turn off dithering
	db0->draw.dtd=0;
	db1->draw.dtd=0;

    db0->x = 0;
    db0->y = 0;
    db1->x = 0;
    db1->y = 256;
	PutDispEnv(&db0->disp);
    SetDispMask(1);

	return;
}

/*
*
*       NAME            void drawBackground(u_long	*ot)
*
*       FUNCTION        Draws background colour cycling polgon
*
*       NOTES           
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
void drawBackground(u_long *ot, POLY_G4 *backPoly)
{

	static unsigned char co1 = 255;
	static unsigned char co2 = 0;
	static unsigned char co3 = 0;

	SetPolyG4(backPoly);
	setXYWH(backPoly, 0, 0, SCRWIDTH, SCRHEIGHT);
	setRGB0(backPoly, co1, co2, co3);
	setRGB1(backPoly, co3, co1, co2);
	setRGB2(backPoly, co2, co3, co1);
	setRGB3(backPoly, co1, co2, co3);
	AddPrim(ot, backPoly);	// apend to OT

	// cycle colours on background
	if( co3 <= 0 && co1 > 0 )
  	{
		co1--;
		co2++;
	}
	if( co1 <= 0 && co2 > 0 )
	{
		co2--;
		co3++;
	}
	if( co2 <= 0 && co3 > 0 )
	{
		co3--;
		co1++;
	}

	return;
}

/*
*
*	NAME		int	loadTIM(TEXTURE_INFO *info)
*
*	FUNCTION	Loads TIM into VRAM
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
int	loadTIM(TEXTURE_INFO *info)
{
	RECT		CLUTrect;
	RECT		IMAGErect;
	TIM_IMAGE	image;		// TIM header


	if( OpenTIM(info->addr) == 0)
		printf("Successfully Opened TIM\n");
	else
	{
		printf("Failed to open TIM\n");
		return 0;
	}

	if(ReadTIM(&image)) {
		if (image.caddr)
		{	// load CLUT (if needed)

			CLUTrect.x = image.crect->x;
			CLUTrect.y = image.crect->y;
			CLUTrect.w = image.crect->w;
			CLUTrect.h = image.crect->h;
			LoadImage(&CLUTrect, image.caddr);
			printf("Clut X = %d , Clut Y = %d \n", image.crect->x, image.crect->y);
			printf("Clut Width = %d , Clut= %d \n", image.crect->w, image.crect->h);

			info->clut_x = image.crect->x;
			info->clut_y = image.crect->y;

		}
		if (image.paddr)
		{
			// load texture pattern
			// Check mode
			IMAGErect.x = image.prect->x;
			IMAGErect.y = image.prect->y;
			IMAGErect.w = image.prect->w;
			IMAGErect.h = image.prect->h;

			LoadImage(&IMAGErect, image.paddr);

			info->texture_x = image.prect->x;
			info->texture_y = image.prect->y;
			info->texture_w = image.prect->w;
			info->texture_h = image.prect->h;
			info->tpage     = (image.prect->x>>6) + ((image.prect->y>>8) * 16);
// divide x by 64 to give tpage id then to see if 2nd row divide y by 256
			printf("Texture X = %d , Texture Y = %d \n", image.prect->x, image.prect->y);
			printf("Texture Width = %d , Height = %d \n", image.prect->w, image.prect->h);

		}
	}
	else
		return 0;

	return 1;
}

/*
*
*	NAME		void drawPadState(int controllerNo, int padState)
*
*	FUNCTION	draws a little message queue showing the pad state
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
void drawPadState(int controllerNo, int padState)
{

	int flop;
	static int bs = 0;
	static int ringbuff[10] = { -1,-1,-1,-1,-1,-1,-1,-1,-1,-1 };
	char temp[17];
	int i;

//        | 0| PadStateDiscon  | Controller disconnected                        |
//        | 1| PadStateFindPad | Found controller and being recognizing         |
//        | 2| PadStateFindCTP1| Recognized none expanded-protocol controller   |
//        | 4| PadStateReqInfo | Loading actuator information(expanded-protocol)|
//        | 5| PadStateExecCmd | Library being communicating with controller    |
//        |  |                 |    (e.g. due to call PadSetActAlign())         |
//        | 6| PadStateStable  | Completed loading actuator information and     |
//        |  |                 | completed execution of packet combination      |
//        |  |                 | function (PadSetActAlign() executable)         |

	if(padState != ringbuff[bs])
	{
		bs = (bs+1) % 10;
		ringbuff[bs] = padState;
	}
	flop = (bs + 1) % 10;
	FntPrint("\n");
	for(i = 0; i < 10; i++)
	{
		switch(ringbuff[flop])
		{
		case -1:
		{
			sprintf(temp,"\t-1");
			FntPrint(fIdA,temp);
			break;
		}
		case 0:
		{
			sprintf(temp,"\tPADSTATEDISCON:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		case 1:
		{
			sprintf(temp,"\tPADSTATEFINDPAD:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		case 2:
		{
			sprintf(temp,"\tPADSTATEFINDCTP1:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		case 4:
		{
			sprintf(temp,"\tPADSTATEREQINFO:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		case 5:
		{
			sprintf(temp,"\tPADSTATEEXECCMD:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		case 6:
		{
			sprintf(temp,"\tPADSTATESTABLE:%d",controllerNo);
			FntPrint(fIdA,temp);
			break;
		}
		default:
		{
			sprintf(temp,"\t%d",ringbuff[flop]);
			FntPrint(fIdA,temp);
			break;
		}
		}

		if(!((i+1)%3))
			FntPrint("\n");
		flop = (flop + 1) % 10;
	}
	return;
}

/*
*
*	NAME		void drawBuffer(void)
*
*	FUNCTION	Draws pad buffers
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
void drawBuffer(void)
{
	char dataline[256];

	int padBuf1;
	int i=0;
	int j;
	int motorNum=0;
	int stopValue=8;

	// Set position of output, when multitap is plugged in the buffer changes
	if(padbuff[0][1]==0x80)
        padBuf1=2;
    else
        padBuf1=0;

	for(j=0;j<2;j++)
	{
	    for(;i<stopValue;i++)
	    {
			if((i==0)||(i==16))
				sprintf(dataline,"  %02x\t\t\t\t\tMOTOR 0: %d\t  %02x\t\t\t\t\t  MOTOR 0: %d\n",padbuff[0][(i+padBuf1)],
											ControlSet[motorNum].Motor[0],padbuff[0][(i+8+padBuf1)],ControlSet[motorNum+1].Motor[0]);
			else if( (i==3)||(i==19))
				sprintf(dataline,"  %02x\t\t\t\t\tMOTOR 1: %03d\t%02x\t\t\t\t\t  MOTOR 1 :%03d\n",padbuff[0][(i+padBuf1)],ControlSet[motorNum].Motor[1],padbuff[0][(i+8+padBuf1)],ControlSet[motorNum+1].Motor[1]);
			else if( (i==7)||(i==23))
			{
				sprintf(dataline,"  %02x\t\t\t\t\tVIBRATE:%s \t%02x\t\t\t\t\t  VIBRATE:%s\n",padbuff[0][(i+padBuf1)],((ControlSet[motorNum].motorState) ? "ON " : "OFF"),padbuff[0][(i+8+padBuf1)],((ControlSet[motorNum+1].motorState) ? "ON" : "OFF"));
				// reached end of first set of Dual Shocks, so increase motor count
				motorNum=2;
			}
 			else
				sprintf(dataline,"  %02x\t\t\t\t\t\t\t\t\t%02x\n",padbuff[0][(i+padBuf1)],padbuff[0][(i+8+padBuf1)]);

			FntPrint(fIdA,dataline);
    	}

		if(j==0)
		{
			FntPrint(fIdA,"\n  DUAL SHOCK LOAD: %d\n\n",DualShockload);
		}

		i+=8;
		stopValue=24;
	}
	return;
}

/*
*
*	NAME		void InitDualShockSprites(DB *db)
*
*	FUNCTION	Initialises various polygons
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
void InitDualShockSprites(DB *db)
{

	int	i;

	// init sprites, assume 4-bit texture
	for (sp = db->polys, i = 0; i < (MAXOBJ-1); i++, sp++)
	{
    	SetPolyFT4(sp);
	    setRGB0(sp, 100, 100, 100);
		setXYWH(sp, 100, 0, 100, 100);
	    sp->tpage = getTPage(texture.mode, 1, tpage_x, tpage_y);
		setUVWH(sp, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w*4-1, texture.texture_h-1);
		setXYWH(sp, 255, 0, texture.texture_w*4, texture.texture_h);
		sp->clut = getClut( texture.clut_x, texture.clut_y);
	}

	// set up motor polygons
	for (sp2 = db->flats, i = 0; i < MAXFLATS; i++, sp2++)
	{
    	SetPolyF4(sp2);
	}

	SetPolyG4(&db->backpoly);
	return;
}

/*
*
*	NAME		void InitDualShockTexture(void)
*
*	FUNCTION	Initialises Dual Shock texture
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
void InitDualShockTexture(void)
{

	// Load texture to VRAM
	texture.addr=DualShockTIM;
	if(!loadTIM(&texture))
		return;

	// set up tpage values
    tpage_x = (texture.texture_x>>6)<<6;
    tpage_y = (texture.texture_y>>8)<<8;

    if (texture.mode != 0)
		printf("Unexpected Texture Mode\n");

	return;
}

/*
*
*	NAME		void drawPolys(DB *cdb)
*
*	FUNCTION	Draws controllers and motor graphics on screen
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	05/11/98	Mike Kav		Created
*
*/
void drawPolys(DB *cdb)
{
	int i;

	// update sprites
	ot = cdb->ot;
	sp = cdb->polys;
	sp2 = cdb->flats;
		

	// four controller graphics
	for (i = 0; i < 4; i++, sp++)
	{
		setXYWH(sp, ControlSet[i].x, ControlSet[i].y, ControlSet[i].w, ControlSet[i].h);	//update vertex
		if(ControlSet[i].active)
		    setRGB0(sp, 125, 125, 125);
		else
		    setRGB0(sp, 75, 75, 75);
			
		AddPrim(ot, sp);	// apend to OT
	}

	// Motor backgrounds
	for (i = 0; i < 4; i++, sp2++)
	{
		// Motor 0
		setXYWH(sp2, ControlSet[i].x+143, ControlSet[i].y+11, 81, 10);

		if(ControlSet[i].Motor[0]==0)
		    setRGB0(sp2, 0, 0, 0);
		else
		    setRGB0(sp2, 255, 0, 0);
		setSemiTrans(sp2,1);
		AddPrim(ot, sp2);	// apend to OT
		sp2++;
				
		// Motor 1
		setXYWH(sp2, ControlSet[i].x+143, ControlSet[i].y+35, 98, 10);
		if(ControlSet[i].Motor[1]==0)
		    setRGB0(sp2, 0, 0, 0);
		else
		    setRGB0(sp2, 255, 0, 0);
		setSemiTrans(sp2,1);
		AddPrim(ot, sp2);	// apend to OT
	}

	// Total load poly, offset x and y position from ControlSet[0].x and ControlSet[0].y
	sp2++;
	setXYWH(sp2, ControlSet[0].x+100, ControlSet[0].y+83, 300, 10);
    setRGB0(sp2, 0, 0, 0);
	setSemiTrans(sp2,1);
	AddPrim(ot, sp2);	// apend to OT

	sp2++;
	setXYWH(sp2, ControlSet[0].x+100, ControlSet[0].y+83, (DualShockload*5), 10);
    setRGB0(sp2, 255, 0, 0);
	setSemiTrans(sp2,1);
	AddPrim(ot, sp2);	// apend to OT

}

/*
*
*       NAME		void ClearVRAM(void)
*
*       FUNCTION	Clear entire contents of VRAM.
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       04/11/98	Mike Kav        Created
*
*/
void ClearVRAM(void)
{
	RECT rectTL;
	
	setRECT(&rectTL, 0, 0, 1024, 512);
	ClearImage2(&rectTL, 0, 0, 0);
	DrawSync(0);						// Ensure VRAM is cleared before exit.

	return;
}

/*
*
*       NAME		void drawTitle(int connection)
*
*       FUNCTION	Draws title line
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       04/11/98	Mike Kav        Created
*
*/
void drawTitle(int connection)
{
	FntPrint(fIdA,"\tMULTITAP DUAL SHOCK SAMPLE ");
	FntPrint(fIdA,"CONNECT:");
	switch(connection)
	{
		case NONE:
		{
			FntPrint(fIdA,"NONE");
			break;
		}
		case DIRECT:
		{
			FntPrint(fIdA,"DIRECT");
			break;
		}
		case MULTI:
		{
			FntPrint(fIdA,"MULTI");
			break;
		}
	}

	return;
}
