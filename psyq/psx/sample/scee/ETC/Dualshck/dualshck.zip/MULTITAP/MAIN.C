/* Dual Shock Multitap example, shows vibration of Dual Shock pads,
*	initialisation and detection of Dual Shock plus current drain
*	when using Dual Shock pads.
*
*	NOTES   
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	05/11/98	Mike Kav		Created
*/

#include <sys/types.h>
#include <sys/file.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include <libpad.h>
#include <stdio.h>
#include "main.h"
#include "graphics.h"

u_long _ramsize = 0x00200000;
u_long _stacksize = 0x0000400;

#define PAD_A_SELECT 0x00000100
#define PAD_A_START 0x00000800
#define PAD_A_UP 0x00001000
#define PAD_A_DOWN 0x00004000
#define DIGITAL	0
#define ANALOG	1
#define NONE	-1
#define DIRECT	0
#define MULTI	1

POLY_G4					g4;									// polygon for background
int						tpage_x, tpage_y;
long					fIdA;								// Applic font id.
int						hSync=0;							// timer

// Dual Shock values
int						DualShockload=0;					// load for current drain, max is 60, motor 0 takes 10, motor 1 takes 20
int 					portNo = 0x0;						// Only uses one controller port
static unsigned char	align[6]={0,1,0xFF,0xFF,0xFF,0xFF};	// Alignment for Dual Shock motors
unsigned char			clearMotor[2] = { 0,0};				// For setting motor values to 0 when disconnected
DCONTROL				ControlSet[4];

static DB				db[2];								// double buffer structure
DB						*cdb;								// pointer, current double buffer

unsigned char			padbuff[2][34];						// pad buffers
int						connectType=NONE;					// connection type, direct, multitap or none
int						bufferOffset=0;						// where to read the pad buffer information from, if multitap then offset = 2

// function prototypes
int		main(void);
void	InitGraphicsSystem(void);
void	InitValues(void);
int		handlePad(int portNo,u_char *buffer);
void	handlePress(int button,int portNo);

/*
*
*       NAME            int main(void)
*
*       FUNCTION        main game loop
*
*       NOTES           all graphics routines have been moved out so that ths file only contains
*						the main game loop and the Dual Shock / pad handling stuff
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
int main(void)
{

	InitGraphicsSystem();
	PadInitMtap(padbuff[0],padbuff[1]);
	PadStartCom();

    cdb = &db[0];
    while(1)
    {
		cdb = ( cdb == &db[1] ) ? &db[0] : &db[1];  

		ClearOTag(cdb->ot, OTSIZE);	

		drawTitle(connectType);
		FntPrint(fIdA,"\tHSYNC:%d\n\n",hSync);


		// draw pad buffer contents
		drawBuffer();
		// draw controllers and motor indicators
		drawPolys(cdb);
		// Background
		drawBackground(cdb->ot,&cdb->backpoly);

		// handle controllers and whats being pressed
		if(!handlePad(0,padbuff[0]))
		{
			// Pause screen
			while(!handlePad(0,padbuff[0]))
			{

				cdb = ( cdb == &db[1] ) ? &db[0] : &db[1];  
				ClearOTag(cdb->ot, OTSIZE);	
				drawTitle(connectType);
				drawBackground(cdb->ot,&cdb->backpoly);
				FntFlush(fIdA);
				DrawSync(0);
				hSync = VSync(0);
				PutDrawEnv(&cdb->draw);
				PutDispEnv(&cdb->disp);
				DrawOTag(cdb->ot);
			}
		}

		FntFlush(fIdA);
		DrawSync(0);
		hSync = VSync(0);
		PutDrawEnv(&cdb->draw);
		PutDispEnv(&cdb->disp);
		DrawOTag(cdb->ot);
	}

	return 0;
}

/*
*
*       NAME            int handlePad(int portNo,u_char *buffer)
*
*       FUNCTION        handles all pad states and unplugging/plugging
*
*       NOTES           returns 0 to indicate nothing plugged in
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
int handlePad(int portNo,u_char *buffer)
{	
	int padState;
	int button;
	int currentPad;
	int ctr;
	int i;
	int numControllers;

	// ignore data when communication failed, FF in first byte, indicating nothing plugged into port
	// reset all controller values (normally display pause or message screen)
	if(*buffer)
	{
		connectType=NONE;
		InitValues();
		return 0;
	}

	// Check for multitap, normally add this to a pause screen
	connectType = PadChkMtap(portNo);

	// Loop through all four controllers if necessary, again this would be setup in a pause screen after a
	// controller had been plugged in
	if(connectType == 1)
	{
		numControllers=4;
		bufferOffset=2;
	}
	else
	{
		numControllers=1;
		bufferOffset=0;
	}

	// Handle each controller in turn
	for(i=0;i<numControllers;i++)
	{

		padState = PadGetState(i);

		// if change to pad state then display state change in message buffer at bottom of screen
		// only tracks first controller
		if(i==0)
			drawPadState(i,padState);

		// If current pad is disconnected, stop all processing of this iteration, resetting values if necessary
		switch(padState)
		{
			case PadStateDiscon:
			{
				if(ControlSet[i].active)
				{
					// Controller removed, reset all motor values
					ControlSet[i].active	= 0;
					ControlSet[2].state		= PadStateDiscon;
					ControlSet[i].mode		= DIGITAL;

					if(ControlSet[i].Motor[0]>0)
					{
						ControlSet[i].Motor[0] = 0;
						DualShockload-=10;
					}

					if(ControlSet[i].Motor[1]>0)
					{
						ControlSet[i].Motor[1] = 0;
						DualShockload-=20;
					}

				}
				// goto next controller
				continue;
			}
			case PadStateFindPad:
			{
				// This indicates that a controller has been plugged in but not yet recognized, quit out of loop
				// and set a flag to indicate that next time round test for controller type
				ControlSet[i].state=PadStateFindPad;
				continue;
			}
			case PadStateFindCTP1:
			{
				// If we get here either the mode has just changed to PadStateFindCTP1 or is stable, i.e.
				// has been PadStateFindCTP1 for a while.

				if(ControlSet[i].state!=PadStateStable)
				{
					// Normal controller of some type connected
					printf("Found Normal Controller:%d\n",i);
					ControlSet[i].state=PadStateStable;
					currentPad = PadInfoMode(i,InfoModeCurID,0);
					switch(currentPad)
					{
						case 4:
						{
							printf("Standard Pad Connected\n");
							break;
						}
						case 7:
						{
							printf("Old Analog Pad (Red Mode) Connected\n");
							break;
						}
						case 5:
						{
							printf("Old Analog Pad (Greeen Mode) Connected:%d\n",currentPad);
							break;
						}
						default:
						{
							printf("Pad Connected:%d\n",currentPad);
							break;
						}
					}
					continue;
				}
				break;
			}
			case PadStateStable:
			{
				
				if(ControlSet[i].state!=PadStateStable)
				{
					printf("Found Expanded Controller:%d\n",i);
					ControlSet[i].state=PadStateStable;

					printf("setting actuator\n");
					// if expanded controller (Dual Shock) then set motors
					currentPad = PadInfoMode(i,InfoModeCurExID,0);
					if(currentPad)
					{
						while(PadSetActAlign(i,align) == 0)
						{
						        // Failed To Load Actuator, wait a bit
						        for(ctr=0;ctr<6;ctr++)
						                VSync(0);
						}

						// call this if we want the motors running after controller is plugged in, as we current reset the motors to
						// zero there is no need at present
						// PadSetAct(portNo,Motor[0],2);

						ControlSet[i].active = 1;
						if(currentPad == 4)
							ControlSet[i].mode = DIGITAL;
						else if(currentPad == 7)
							ControlSet[i].mode = ANALOG;

						ControlSet[i].motorState = 0;
						ControlSet[i].Motor[0] = 0;
						ControlSet[i].Motor[1] = 0;
					}
					else
						printf("Unhandled expanded controller");
					continue;
				}
				break;
			}
			case PadStateReqInfo:
			{
					// just wait for pad to stabilize before reading button presses
					continue;
			}

		}

		// Check all buttons on all controllers, we are only interested in the last six bytes of each data packet
		// Add 2 to the buffer position to skip ID value, add the bufferoffset value, which is 2 if a multitap
		// is connected
		// buffer 1	(no multitap) would be handled like this: button = ~((buffer[2]<<8) | buffer[3]);
		button = ~((buffer[(i*8)+2+bufferOffset]<<8) | buffer[(i*8)+3+bufferOffset]);

		// manipulate button presses, only necessary if we have a Dual Shock as buttons change motor values
		if(ControlSet[i].active)
			handlePress(button,i);
	}

	return 1;
}

/*
*
*       NAME            void handlePress(int button,int portNo)
*
*       FUNCTION        handles all pad button presses
*
*       NOTES           UP			Motor 1 start
*						DOWN		Motor 1 stop
*						TRIANGLE	Motor 2 +1
*						CIRCLE		Motor 2 +10
*						CROSS		Motor 2 -1
*						SQUARE		Motor 2 -10
*						L2			Vibrate off
*						R2			Vibrate on
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
void handlePress(int button,int portNo)
{
	if(button & PADRdown)
	{

		if(ControlSet[portNo].Motor[1] > 0)
		{
			ControlSet[portNo].Motor[1]--;
			// if the motor is now zero then return load to the main pool
			if(ControlSet[portNo].Motor[1] == 0)
				DualShockload-=20;
		}
	}
	else if(button & PADRup)
	{

		if(ControlSet[portNo].Motor[1] < 255)
			ControlSet[portNo].Motor[1]++;
		if(ControlSet[portNo].Motor[1] == 1)
		{
			// check we can allocate motor
			if(DualShockload>40)
				ControlSet[portNo].Motor[1] = 0;
			else
				DualShockload+=20;
		}
	}
	else if(button & PADRleft)
	{

		if(ControlSet[portNo].Motor[1] > 10)
			ControlSet[portNo].Motor[1]-=10;
		else if(ControlSet[portNo].Motor[1] > 0)
		{
			ControlSet[portNo].Motor[1]=0;
			// As it's now zero return load to the main pool
				DualShockload-=20;
		}
	}
	else if(button & PADRright)
	{

		if(ControlSet[portNo].Motor[1] < 245)
			ControlSet[portNo].Motor[1]+=10;
		else
			ControlSet[portNo].Motor[1]=255;
			
		if(ControlSet[portNo].Motor[1] == 10)
		{
			if(DualShockload>40)
				ControlSet[portNo].Motor[1]=0;
			else
				DualShockload+=20;
		}
	}

	if(button & PADLup)
	{
		if(ControlSet[portNo].Motor[0]==0)
		{
			if(DualShockload<60)
			{
				ControlSet[portNo].Motor[0]=1;
				DualShockload+=10;
			}
		}
	}

	if(button & PADLdown)
	{
		if(ControlSet[portNo].Motor[0]==1)
		{
			DualShockload-=10;
			ControlSet[portNo].Motor[0]=0;
		}
	}

	if(button & PADR2)
	{
			if(ControlSet[portNo].motorState != 1)
			{
				ControlSet[portNo].motorState=1;
				PadSetAct(portNo,ControlSet[portNo].Motor,2);
			}
	}
	else if(button & PADL2)
	{
			if(ControlSet[portNo].motorState == 1)
			{

				ControlSet[portNo].motorState=0;
				PadSetAct(portNo,clearMotor,2);

				// Now add motor load back to main pool
				if(ControlSet[portNo].Motor[0]>0)
				{
					ControlSet[portNo].Motor[0] = 0;
					DualShockload-=10;
				}
				if(ControlSet[portNo].Motor[1]>0)
				{
					ControlSet[portNo].Motor[1] = 0;
					DualShockload-=20;
				}
			}
	}
	return;
}

/*
*
*       NAME            void handlePress(int button,int portNo)
*
*       FUNCTION        Initialises controller values
*
*       NOTES
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
void InitValues(void)
{
	int i;

	// As we use this to reset all controllers when the multitap is unplugged
	// reset overall load value if required

	for(i=0;i<4;i++)
	{
		if(ControlSet[i].active)
		{
			if(ControlSet[i].Motor[0]>0)
			{
				ControlSet[i].Motor[0] = 0;
				DualShockload-=10;
			}
			if(ControlSet[i].Motor[1]>0)
			{
				ControlSet[i].Motor[1] = 0;
				DualShockload-=20;
			}
		}
	}

	ControlSet[0].active		= 0;
	ControlSet[0].mode			= DIGITAL;
	ControlSet[0].state			= PadStateDiscon;
 	ControlSet[0].x				= 55;
	ControlSet[0].y				= 10;
	ControlSet[0].w				= 140;
	ControlSet[0].h				= 80;
	ControlSet[0].Motor[0]		= 0;
	ControlSet[0].Motor[1]		= 0;
	ControlSet[0].motorState	= 0;
	ControlSet[0].inputDelay	= 0;

	ControlSet[1].active		= 0;
	ControlSet[1].mode			= DIGITAL;
	ControlSet[1].state			= PadStateDiscon;
	ControlSet[1].x				= 375;
	ControlSet[1].y				= 10;
	ControlSet[1].w				= 140;
	ControlSet[1].h				= 80;
	ControlSet[1].Motor[0]		= 0;
	ControlSet[1].Motor[1]		= 0;
	ControlSet[1].motorState	= 0;
	ControlSet[1].inputDelay	= 0;

	ControlSet[2].active		= 0;
	ControlSet[2].mode			= DIGITAL;
	ControlSet[2].state			= PadStateDiscon;
	ControlSet[2].x				= 55;
	ControlSet[2].y				= 98;
	ControlSet[2].w				= 140;
	ControlSet[2].h				= 80;
	ControlSet[2].Motor[0]		= 0;
	ControlSet[2].Motor[1]		= 0;
	ControlSet[2].motorState	= 0;
	ControlSet[2].inputDelay	= 0;

	ControlSet[3].active		= 0;
	ControlSet[3].mode			= DIGITAL;
	ControlSet[3].state			= PadStateDiscon;
	ControlSet[3].x				= 375;
	ControlSet[3].y				= 98;
	ControlSet[3].w				= 140;
	ControlSet[3].h				= 80;
	ControlSet[3].Motor[0]		= 0;
	ControlSet[3].Motor[1]		= 0;
	ControlSet[3].motorState	= 0;
	ControlSet[3].inputDelay	= 0;

	return;
}


/*
*
*       NAME            void InitGraphicsSystem(void)
*
*       FUNCTION        Initialises graphics
*
*       NOTES
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       05/11/98        Mike Kav        Created
*
*/
void InitGraphicsSystem(void)
{
    SetDispMask(1);
	ResetGraph(0);	 						// reset graphic subsystem (0:cold,1:warm)
	ResetCallback();
    SetGraphDebug(0);

#ifdef NTSC
        SetVideoMode(MODE_NTSC);
#else
        SetVideoMode(MODE_PAL);
#endif
	ClearVRAM();

	InitGraphics(&db[0],&db[1]);
	// Init font environment.
	FntLoad(960, 256);	
	fIdA = FntOpen(6, 6, 640, 240, 0, 1024);
	SetDumpFnt(fIdA);	

	// load in textures
	InitDualShockTexture();
	InitDualShockSprites(&db[0]);
	InitDualShockSprites(&db[1]);
	InitValues();

	return;
}

