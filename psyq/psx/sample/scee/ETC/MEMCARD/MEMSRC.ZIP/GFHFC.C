 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		GFHFC.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Loads the File header from the Memory card						  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/


#include "memcard.h"


int _mc_LoadFromCard(long channel, char *fileName, FILE_HEADER *fileHeader, int DownLoadSize)
{
int file;
char path[64];			 
int count;

  sprintf(path, "bu%.2x:%s", channel, fileName);
  file=open(path, O_RDONLY);

  if(file <0)			return 0;	 // file could not be opened

  count = read(file, fileHeader, DownLoadSize);
							    
  if(count != DownLoadSize)   
  {																	   
       close(file);
       return 2;  // error during read
  }

  close(file);
  return 1;
}
