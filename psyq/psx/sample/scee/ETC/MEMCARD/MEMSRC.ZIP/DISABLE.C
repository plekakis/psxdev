 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		disable.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Disables the Memory card events									  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"

int _mc_DisableCardEvents(void)
{
DisableEvent(Ev0);
DisableEvent(Ev1);
DisableEvent(Ev2);
DisableEvent(Ev3);
DisableEvent(Ev10);
DisableEvent(Ev11);
DisableEvent(Ev12);
DisableEvent(Ev13);
return 1;
}