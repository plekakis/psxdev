 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		FFileNF.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Reads the Directory information from the Memory card  			  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/




#include "memcard.h"

int _mc_ReadDirectoryInformation(long port, char *drive,struct DIRENTRY *d)	 
{																						   
int i;
char key[128];
int ret;      
   
         _mc_ClearEventHw();
         _card_clear(port);
         _mc_GetCardEventHw();

         _mc_ClearEventSw();
         _new_card();
         ret = _card_load(port);
         _mc_GetCardEventSw();
		 _mc_ClearEventSw();

		sprintf(key, "%s*",drive);
        
        i=0;


			if(firstfile(key,d)==d)
            	  {
                	 do
                  	 {
                         i++;
                       	 d++;
                  	 }
                     while(nextfile(d)==d);
             	  }
return i;
}