 /***************************************************************************************
 *		Lib Rev 4.0											 	  			 			*
 *																  			 			*
 *		Filename:		CDOTCMes.c 								  			 			*
 *																 			 			*
 *		Author:		    Kevin Thompson						   	  			 			*													
 *																			 			*
 *		Description:    Checking Data on the Memory card, warnings and messages   		*
 *																						*
 *		History:												 			 			*
 *			01-07-97	(LPGE)									 						*
 *						Created									 						*
 *																 						* 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    					 	* 
 *		  All Rights Reserved														 	*
 *																 					    *
 ****************************************************************************************/

#include "memcard.h"

int _mc_CheckingDataOnCardMessages(int message, char *slot,int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nAccessing %s, do not remove %s!",AUTH_NAMES1,AUTH_NAMES1);
if(message == 2)  KanjiFntPrint(mess,"\nAccessing %s in %s %s, do not remove %s!",AUTH_NAMES1,AUTH_NAMES2,slot,AUTH_NAMES1);
if(message == 3)  KanjiFntPrint(mess,"\nData error! Read failed. Try again or insert a new %s.",AUTH_NAMES1);
if(message == 4)  KanjiFntPrint(mess,"\nData error! Read failed. Try again or insert a new %s in %s %s",AUTH_NAMES1,AUTH_NAMES2,slot);
if(message == 5)  KanjiFntPrint(mess,"\nData may be corrupt. Try again or insert a new %s.",AUTH_NAMES1);
if(message == 6)  KanjiFntPrint(mess,"\nData may be corrupt. Try again or insert a new %s in %s %s",AUTH_NAMES1,AUTH_NAMES2,slot);
return mess;
}
