 /****************************************************************************************
 *		Lib Rev 4.0											 	  			 			 *
 *																  						 *
 *		Filename:		DCEvenHw.c 								  						 *
 *																 						 *
 *		Author:		    Kevin Thompson						   	  						 *													
 *																						 *
 *		Description:   Gets The Hardware events											 *
 *																						 *
 *		History:													 					 *	
 *			01-07-97	(LPGE)										 					 *
 *						Created										 					 *
 *																	 					 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						 * 
 *		  All Rights Reserved															 *
 *																 						 *
 *****************************************************************************************/

#include "memcard.h"

int _mc_GetCardEventHw(void)
{
    while(1)
	{
      if(TestEvent(Ev10)==1)	return EVENT_IOE;
      if(TestEvent(Ev11)==1)	return EVENT_ERROR;
      if(TestEvent(Ev12)==1)	return EVENT_TIMEOUT;
      if(TestEvent(Ev13)==1)	return EVENT_NEWCARD;
	}
}