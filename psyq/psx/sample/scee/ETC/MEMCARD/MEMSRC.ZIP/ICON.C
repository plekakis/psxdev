 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		icon.c 								  							  *
 *																						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Downloads selectd icon into Vram								  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"


  
int _mc_LoadIconDataIntoVram(int u, int v, int w, int h, int cu, int cv, char *icon, char *clut)
{
RECT rect;
setRECT(&rect, u,v,w,h);
  																			  
LoadImage(&rect, (u_long *)icon);
LoadClut2((u_long *)clut,cu,cv);
}			   




															    

		   


						  


					  