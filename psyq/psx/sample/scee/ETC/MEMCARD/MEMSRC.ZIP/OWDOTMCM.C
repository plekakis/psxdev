 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		OWDOTMCM.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	Overwriting data on the Memory card Warnings and messages		  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/


#include "memcard.h"

int _mc_OverWrittingDataFromOnMemoryCardMessages(int message, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nSelect block to overwrite");
if(message == 2)  KanjiFntPrint(mess,"\nOverwrite block %s ? Y or N",GAME_TITLE);
if(message == 3)  KanjiFntPrint(mess,"\nSelect data to overwrite");
if(message == 4)  KanjiFntPrint(mess,"\nOverwrite data %s ? Y or N",GAME_TITLE);
if(message == 5)  KanjiFntPrint(mess,"\nOverwriting data. Do not remove %s!",AUTH_NAMES1);
if(message == 6)  KanjiFntPrint(mess,"\nOverwrite Complete. OK");
return mess;
}
