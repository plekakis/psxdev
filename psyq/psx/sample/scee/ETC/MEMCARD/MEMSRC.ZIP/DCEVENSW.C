 /****************************************************************************************
 *		Lib Rev 4.0											 	  			 			 *
 *																  						 *
 *		Filename:		DCEvenSw.c 								  						 *
 *																 						 *
 *		Author:		    Kevin Thompson						   	  						 *													
 *																						 *
 *		Description:   Gets The Software events											 *
 *																						 *
 *		History:													 					 *	
 *			01-07-97	(LPGE)										 					 *
 *						Created										 					 *
 *																	 					 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						 * 
 *		  All Rights Reserved															 *
 *																 						 *
 *****************************************************************************************/

#include "memcard.h"

int _mc_GetCardEventSw(void)
{
    while(1)
	{
      if(TestEvent(Ev0)==1)		return EVENT_IOE;
      if(TestEvent(Ev1)==1)		return EVENT_ERROR;
      if(TestEvent(Ev2)==1)		return EVENT_TIMEOUT;
      if(TestEvent(Ev3)==1)		return EVENT_NEWCARD;
	}
}