 /*******************************************************************************w*********
 *		Lib Rev 4.0											 	  			 			 *
 *																  						 *
 *		Filename:		DDFMCMes.c 								  						 *
 *																 						 *
 *		Author:		    Kevin Thompson						   	  						 *													
 *																						 *
 *		Description:   Deleteing data from the Memory card warnings and messages 		 *
 *																						 *
 *		History:													 					 *	
 *			01-07-97	(LPGE)										 					 *
 *						Created										 					 *
 *																	 					 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						 * 
 *		  All Rights Reserved															 *
 *																 						 *
 *****************************************************************************************/

#include "memcard.h"

int _mc_DeletingDataFromTheMemoryCardMessages(int message, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nSelect block to delete");
if(message == 2)  KanjiFntPrint(mess,"\nSelect saved slot to delete");
if(message == 3)  KanjiFntPrint(mess,"\nDelete this block %s ? Y or N",GAME_TITLE);
if(message == 4)  KanjiFntPrint(mess,"\nDelete this saved slot %s ? Y or N",GAME_TITLE);
if(message == 5)  KanjiFntPrint(mess,"\nCancel delete? Y or N");
return mess;
}

