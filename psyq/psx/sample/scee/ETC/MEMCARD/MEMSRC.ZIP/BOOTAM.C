 /****************************************************************************************
 *		Lib Rev 4.0											 	  			 			 *
 *																  						 *
 *		Filename:		BootAM.c 								  						 *
 *																 						 *
 *		Author:		    Kevin Thompson						   	  						 *													
 *																						 *
 *		Description:   Bootup messages and warnings for a game that saves automaticaly	 *
 *																						 *
 *		History:													 					 *	
 *			01-07-97	(LPGE)										 					 *
 *						Created										 					 *
 *																	 					 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						 * 
 *		  All Rights Reserved															 *
 *																 						 *
 *****************************************************************************************/

#include "memcard.h"


int _mc_BootUpAutoMessages(int message, int FreeBlocks, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"Caution! %s uses an Autosave feature. Insertion of a %s beyond this point, may cause data to be overwritten.",GAME_TITLE,AUTH_NAMES1); 
if(message == 2)  KanjiFntPrint(mess,"Caution! %s uses an Autosave feature. Insert a formatted %s with at least %d free blocks or press %s  to continue without saving.",GAME_TITLE,AUTH_NAMES1,FreeBlocks,FORWARD_BUTTON);
if(message == 3)  KanjiFntPrint(mess,"%s is full.  Insert a %s with at least %d free blocks or delete some blocks using the Console's internal %s Manager.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,AUTH_NAMES1); 
if(message == 4)  KanjiFntPrint(mess,"Insufficient space on %s.  Insert a %s with at least %d free blocks or delete some blocks using the Console's internal %s Manager.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,FORWARD_BUTTON);
return mess;
}


													    


											    