 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		FTMCMess.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    formating the Memory card warnings and messages					  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"

int _mc_FormattingTheMemoryCardMessages(int message, char *slot , int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nAre you sure you wish to format %s? Y or N",AUTH_NAMES1);
if(message == 2)  KanjiFntPrint(mess,"\nAre you sure you wish to format %s in %s %s? Y or N",AUTH_NAMES1,AUTH_NAMES2,slot);
if(message == 3)  KanjiFntPrint(mess,"\nFormatting %s, do not remove %s !",AUTH_NAMES1,AUTH_NAMES1);
if(message == 4)  KanjiFntPrint(mess,"\nFormatting %s in %s %s, do not remove %s!",AUTH_NAMES1,AUTH_NAMES2,slot,AUTH_NAMES1);
if(message == 5)  KanjiFntPrint(mess,"\nCancel format? Y or N");
if(message == 6)  KanjiFntPrint(mess,"\nFormat Completed. OK");
if(message == 7)  KanjiFntPrint(mess,"\nFormat failed! Try again or insert a new %s.",AUTH_NAMES1);
return mess;
}