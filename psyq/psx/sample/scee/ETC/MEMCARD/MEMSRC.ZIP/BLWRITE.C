 /****************************************************************************
 *		Lib Rev 4.0											 	  			 *
 *																  			 *
 *		Filename:		BlWrite.c 								  			 *
 *																 			 *
 *		Author:		    Kevin Thompson						   	  			 *													
 *																			 *
 *		Description:	Writes A Save Block To the Memory card				 *
 *																			 *
 *		History:												 			 *
 *			01-07-97	(LPGE)									 			 *
 *						Created									 			 *
 *																 			 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    			 * 
 *		  All Rights Reserved												 *
 *																 			 *
 *****************************************************************************/

#include "memcard.h"

int _mc_BlockWrite(int blocks, char *buffer, char *SaveName)
{
int fd=0;
int i=0;				  

	i=_mc_FileExistsOnCard(SaveName);
	  
	if(i==1)	return 0;		// file already exists

    if((fd=open(SaveName,O_CREAT|(blocks<<16)))==-1)		return 2;  // unable to open save

	i = write(fd,buffer,(blocks*8192));
	
	if(i!=(blocks*8192)) 
		{
		printf(" error during write.  int byte %d ",i);
		close(fd);
		return 3;			 // error failed while writting to the card
		}
 	close(fd);
	return 1;		// write successful
}
