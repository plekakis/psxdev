 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		Enable.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Enables the Memory card events									  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/



#include "memcard.h"

int _mc_EnableCardEvents(void)
{
EnableEvent(Ev0);
EnableEvent(Ev1);
EnableEvent(Ev2);
EnableEvent(Ev3);
EnableEvent(Ev10);
EnableEvent(Ev11);
EnableEvent(Ev12);
EnableEvent(Ev13);
return 1;
}
