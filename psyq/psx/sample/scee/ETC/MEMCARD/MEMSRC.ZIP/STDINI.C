/******************************************************************************************
 *																  						  *
 *		Filename:		STDIni.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	Initalise all of the needed Memory card stuff					  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/


#include "memcard.h"

long Ev0,Ev1,Ev2,Ev3,Ev10,Ev11,Ev12,Ev13;

int _mc_InitializeCardAndEventsStandard(int shared)
{
if(shared > 1)		return 0;	// id the number is out of range terminate

InitCARD(shared);
StartCARD();

_bu_init();

EnterCriticalSection();
Ev0  = OpenEvent(SwCARD, EvSpIOE,    EvMdNOINTR, NULL);
Ev1  = OpenEvent(SwCARD, EvSpERROR,  EvMdNOINTR, NULL);
Ev2  = OpenEvent(SwCARD, EvSpTIMOUT, EvMdNOINTR, NULL);
Ev3  = OpenEvent(SwCARD, EvSpNEW,    EvMdNOINTR, NULL);
Ev10 = OpenEvent(HwCARD, EvSpIOE,    EvMdNOINTR, NULL);
Ev11 = OpenEvent(HwCARD, EvSpERROR,  EvMdNOINTR, NULL);
Ev12 = OpenEvent(HwCARD, EvSpTIMOUT, EvMdNOINTR, NULL);
Ev13 = OpenEvent(HwCARD, EvSpNEW,    EvMdNOINTR, NULL);

EnableEvent(Ev0);
EnableEvent(Ev1);
EnableEvent(Ev2);
EnableEvent(Ev3);
EnableEvent(Ev10);
EnableEvent(Ev11);
EnableEvent(Ev12);
EnableEvent(Ev13);
ExitCriticalSection();

return 1;
}