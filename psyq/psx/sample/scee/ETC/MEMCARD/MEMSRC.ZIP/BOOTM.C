 /****************************************************************************
 *		Lib Rev 4.0											 	  			 *
 *																  			 *
 *		Filename:		BootM.c 								  			 *
 *																 			 *
 *		Author:		    Kevin Thompson						   	  			 *													
 *																			 *
 *		Description:	Messages for use when the game is booting			 *
 *																			 *
 *		History:												 			 *
 *			01-07-97	(LPGE)									 			 *
 *						Created									 			 *
 *																 			 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    			 * 
 *		  All Rights Reserved												 *
 *																 			 *
 *****************************************************************************/


#include "memcard.h"


int _mc_BootUpMessage(int message, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"%s is full.  Insert a %s with at least %d free blocks or delete some blocks using the Console's internal %s Manager.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,AUTH_NAMES1);
if(message == 2)  KanjiFntPrint(mess,"Insufficient space on %s.  Insert a %s with at least %d free blocks or delete some blocks using the Console's internal %s Manager.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,AUTH_NAMES1);
if(message == 3)  KanjiFntPrint(mess,"Unformatted %s.  Insert a formatted %s with at least %d free blocks or press %s  to continue without saving.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,FORWARD_BUTTON);
if(message == 4)  KanjiFntPrint(mess,"Caution! If you wish to save your game data, insert a formatted %s with at least %d free blocks or press %s to continue without saving.",AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,FORWARD_BUTTON);
return mess;
}

