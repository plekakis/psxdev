 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		FileONMC.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Checks to see if the selected file exists on the Memory card	  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/



#include "memcard.h"

int _mc_FileExistsOnCard(char *fileName)
{
int file;
char name[20];

file = open(fileName, O_RDONLY);
if(file >= 0)
{
  close(file);
  return 1;
}

close(file);
return 0;
}

				   