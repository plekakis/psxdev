 /****************************************************************************
 *		Lib Rev 4.0											 	  			 *
 *																  			 *
 *		Filename:		STIMMess.c 								  			 *
 *																 			 *
 *		Author:		    Kevin Thompson						   	  			 *													
 *																			 *
 *		Description:	Saving to the Internal Memory warnings and messages	 *
 *																			 *
 *		History:												 			 *
 *			01-07-97	(LPGE)									 			 *
 *						Created									 			 *
 *																 			 * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    			 * 
 *		  All Rights Reserved												 *
 *																 			 *
 *****************************************************************************/

#include "memcard.h"


int _mc_SavingToTheInternalMemoryMessages(int message, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nSaving data to Console's memory. If you do not save to a %s before turning off the Console, all data will be lost!",AUTH_NAMES1);
return mess;
}
