 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		LFMCMSLA.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	Loading from the Memory card with multiple slots available		  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"


int _mc_LoadingFromMemoryCardMultipleSlotsAvMessages(int message, char *slot, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nPlease select %s",AUTH_NAMES2);
if(message == 2)  KanjiFntPrint(mess,"\nNo %s save data present in %s %s",GAME_TITLE,AUTH_NAMES2,slot);
if(message == 3)  KanjiFntPrint(mess,"\n%s in %s %s is unformatted. Insert a formatted %s.",AUTH_NAMES1,AUTH_NAMES2,slot,AUTH_NAMES1);
if(message == 4)  KanjiFntPrint(mess,"\nNo %s inserted in %s %s.",AUTH_NAMES1,AUTH_NAMES2,slot);
if(message == 5)  KanjiFntPrint(mess,"\nLoad failed!  Check %s and please try again.",AUTH_NAMES1);
if(message == 6)  KanjiFntPrint(mess,"\n%s error! Load failed.  Please insert a new %s containing %s saved data into %s %s",AUTH_NAMES1,AUTH_NAMES1,GAME_TITLE,AUTH_NAMES2,slot);
if(message == 7)  KanjiFntPrint(mess,"\nLoad Completed. OK");
if(message == 8)  KanjiFntPrint(mess,"\nCancel load? Y or N");
return mess;
}



													    