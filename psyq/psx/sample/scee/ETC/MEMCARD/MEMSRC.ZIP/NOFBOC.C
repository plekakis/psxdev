 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		NOFBOC.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	How Many free blocks are there on the selected Memory card		  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"

int _mc_NumberOfFreeBlocksOnCard(FILE_HEADER *fileheader)
{
int loop;
int remaining=15;

   for(loop=0; loop<15; loop++)
   {
    remaining -= fileheader[loop].blockEntry;
   }

return remaining;
}
