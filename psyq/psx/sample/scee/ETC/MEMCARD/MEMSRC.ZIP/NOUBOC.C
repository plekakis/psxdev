 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		NOUBOC.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	How Many Used blocks are there on the selected Memory card		  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"

int _mc_NumberOfUsedBlocksOnCard(FILE_HEADER *fileheader)
{
int loop;
int rem=0;

   for(loop=0; loop<15; loop++)
   {
    rem += fileheader[loop].blockEntry;
   }

return rem;
}


							    