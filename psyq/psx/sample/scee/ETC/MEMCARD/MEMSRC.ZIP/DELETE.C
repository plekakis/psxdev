 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		Delete.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Deletes a file from the Memory card..							  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"

int _mc_DeleteFileFromCard(char *drive, char *name)	 // the complete name of the filto be removed
{
int err;  
char remove[64];

  sprintf(remove, "%s%s",drive,name);
  
  err = delete(remove);
  if(err == -1);		return 0;		// if this is called it means that the file has failed to be deleted
  return 1;
}
									    