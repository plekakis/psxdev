 /***************************************************************************************
 *		Lib Rev 4.0											 	  			 			*
 *																  			 			*
 *		Filename:		CCEvenSw.c 								  			 			*
 *																 			 			*
 *		Author:		    Kevin Thompson						   	  			 			*													
 *																			 			*
 *		Description:    Clears the Memory card Events									*		 
 *																						*
 *		History:												 			 			*
 *			01-07-97	(LPGE)									 						*
 *						Created									 						*
 *																 						* 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    					 	* 
 *		  All Rights Reserved														 	*
 *																 					    *
 ****************************************************************************************/

#include "memcard.h"

void _mc_ClearEventSw(void)
{
    TestEvent(Ev0);
    TestEvent(Ev1);
    TestEvent(Ev2);
    TestEvent(Ev3);
}
