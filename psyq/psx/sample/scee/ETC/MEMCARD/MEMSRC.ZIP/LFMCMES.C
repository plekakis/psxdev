 /*****************************************************************************************
 *		Lib Rev 4.0											 	  			 			  *
 *																  						  *
 *		Filename:		LFMCMes.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:    Loading from the Memory card Warnings and messages				  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/

#include "memcard.h"


int _mc_LoadingFromTheMemoryCardMessages(int message, int mess)
{
if(message == 1)  KanjiFntPrint(mess,"\nNo %s save data present.",GAME_TITLE);
if(message == 2)  KanjiFntPrint(mess,"\n%s unformatted.  Please insert a formatted %s.",AUTH_NAMES1,AUTH_NAMES1);
if(message == 3)  KanjiFntPrint(mess,"\nNo %s inserted. Please insert a %s containing %s saved data.",AUTH_NAMES1,AUTH_NAMES1,GAME_TITLE);
if(message == 4)  KanjiFntPrint(mess,"\nLoad failed! Check %s and please try again.",AUTH_NAMES1);
if(message == 5)  KanjiFntPrint(mess,"\n%s error! Load failed. Please insert a new %s containing %s saved data.",AUTH_NAMES1,AUTH_NAMES1,GAME_TITLE);
if(message == 6)  KanjiFntPrint(mess,"\nLoading data. Do not remove %s!",AUTH_NAMES1);
if(message == 7)  KanjiFntPrint(mess,"\nLoad Completed. OK");
if(message == 8)  KanjiFntPrint(mess,"\nCancel load? Y or N");
return mess;
}





												  			 