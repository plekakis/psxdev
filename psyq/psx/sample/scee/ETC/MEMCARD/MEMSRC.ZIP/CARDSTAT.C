 /***************************************************************************************
 *		Lib Rev 4.0											 	  			 			*
 *																  			 			*
 *		Filename:		CardStat.c 								  			 			*
 *																 			 			*
 *		Author:		    Kevin Thompson						   	  			 			*													
 *																			 			*
 *		Description:   Check the card status.. will return a load of different numebers	*		 *
 *					   ranging from 0 to 4..											*
 *		History:												 			 			*
 *			01-07-97	(LPGE)									 						*
 *						Created									 						*
 *																 						* 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe    					 	* 
 *		  All Rights Reserved														 	*
 *																 					    *
 ****************************************************************************************/


#include "memcard.h"

int _mc_GetCardStatus(long channel, int StartUp) 
{
  int 		ret;


if(StartUp != 0)
{
  _mc_ClearEventSw();
  _card_info (channel);
  ret = _mc_GetCardEventSw();

  switch (ret)
  {
    case EVENT_IOE:
            return PRESENT_CARD_FORMATTED;			// change to PRESENT_CARD_FORMATTED = 0
            break;

    case EVENT_ERROR:
            return PRESENT_CARD_BAD;				// change to PRESENT_CARD_BAD = 1
            break;

    case EVENT_TIMEOUT:
            return PRESENT_CARD_NONE;				// change to PRESENT_CARD_NONE = 2
            break;
  }

}

  /* The card is newly inserted */
  _mc_ClearEventHw();
  _card_clear(channel);
  ret = _mc_GetCardEventHw();

  _mc_ClearEventSw(); 
  _card_load(channel);
  ret = _mc_GetCardEventSw(); 
  
  switch (ret) 
  {
    case EVENT_IOE:
	  return NEW_CARD_FORMATTED;
          break;

    case EVENT_ERROR:
	  return NEW_CARD_BAD;
          break;

    case EVENT_TIMEOUT:
	  return NEW_CARD_NONE;
          break;

    case EVENT_NEWCARD:
	  return NEW_CARD_UNFORMATTED;
          break;
  }
  return -1 ;
}
