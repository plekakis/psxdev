/******************************************************************************************
 *																  						  *
 *		Filename:		STCMes.c 								  						  *
 *																 						  *
 *		Author:		    Kevin Thompson						   	  						  *													
 *																						  *
 *		Description:   	Saving to the Memory card										  *
 *																						  * 
 *		History:													 					  * 	
 *			01-07-97	(LPGE)										 					  * 
 *						Created										 					  * 
 *																	 					  * 
 *	    Copyright (c) 1997 Sony Computer Entertainment Europe  	  						  * 
 *		  All Rights Reserved															  *
 *																 						  * 
 ******************************************************************************************/


#include "memcard.h"

int _mc_SavingToTheMemoryCardMessages(int message, int blocksfree, int mess)
{
if(message == 1)   KanjiFntPrint(mess,"\n%s requires %d blocks to save - %d free blocks available on %s",GAME_TITLE,NUMBER_OF_BLOCKS_USED,blocksfree,AUTH_NAMES1);
if(message == 2)   KanjiFntPrint(mess,"\n%s is full. Insert a new %s or delete %d blocks.",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED);
if(message == 3)   KanjiFntPrint(mess,"\n%s is full. Insert a new %s, delete %d blocks or overwrite previous %s save?",AUTH_NAMES1,AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,GAME_TITLE);
if(message == 4)   KanjiFntPrint(mess,"\n%s unformatted. Format %s?",AUTH_NAMES1,AUTH_NAMES1);
if(message == 5)   KanjiFntPrint(mess,"\nInsufficient space. Delete %d blocks or insert a new %s or overwrite non %s data.",NUMBER_OF_BLOCKS_USED,AUTH_NAMES1,GAME_TITLE);
if(message == 6)   KanjiFntPrint(mess,"\nInsufficient space. Insert a new %s, delete %d blocks or overwrite previous %s save?",AUTH_NAMES1,NUMBER_OF_BLOCKS_USED,GAME_TITLE);
if(message == 7)   KanjiFntPrint(mess,"\nNo %s inserted.  Please insert a %s",AUTH_NAMES1,AUTH_NAMES1);
if(message == 8)   KanjiFntPrint(mess,"\nSaving data. Do not remove %s!",AUTH_NAMES1);
if(message == 9)   KanjiFntPrint(mess,"\nFile already exists. Create new file or overwrite previous data?");
if(message == 10)  KanjiFntPrint(mess,"\nSave failed!  Check %s and please try again.",AUTH_NAMES1);
if(message == 11)  KanjiFntPrint(mess,"\n%s error! Save failed. Please insert a new %s.",AUTH_NAMES1,AUTH_NAMES1);
if(message == 12)  KanjiFntPrint(mess,"\nSaving data. Do not remove %s!",AUTH_NAMES1);
if(message == 13)  KanjiFntPrint(mess,"\nAutosaving data. Do not remove %s!",AUTH_NAMES1);
if(message == 14)  KanjiFntPrint(mess,"\nData has changed. Overwrite previous game data? Y or N");
if(message == 15)  KanjiFntPrint(mess,"\nSave Completed. OK");
if(message == 16)  KanjiFntPrint(mess,"\nCancel save? Y or N");
return mess;
}
