/* Code demonstrating use of some low level functions, this
*	program is a CD browser which allows any PlayStation CD
*	to be placed in the drive and you can view the files on
*	it. Currently the only files capable of being viewed are
*	movie streams
*
*	NOTES   
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	11/03/98	Mike Kav		Created
*
*/

#include <sys/types.h>
#include <kernel.h>
#include <libsn.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <libcd.h>
#include <libspu.h>
#include <libsnd.h>
#include <libgs.h>

#include "main.h"
#include "sceecd.h"
#include "control.h"
#include "movie.h"
#include "timview.h"

// Maximum Volume
#define MAX_VOL				127
#define INPUT_DELAY			5

#define VIEWFILES			10

#ifdef FINAL
u_long _ramsize   = 0x00200000;				// Use 2MB for final.
u_long _stacksize = 0x00004000;
#else
u_long _ramsize   = 0x00800000;				// Use 8MB for development.
u_long _stacksize = 0x00008000;
#endif

extern unsigned long pictureTIM[];			// picture inbin'd from
											// test.tim
// Polygon details for displaying texture
POLY_FT4 poly;
int polyWidth;
int polyHeight;
int tpage_x, tpage_y;
TEXTURE_INFO texture;


static volatile long frameNo = 0;			// Current frame No.
DB		db[2];		
short	cdb = 0;							// Current double buffer.

long	fIdA;								// Applic font id.

// File menu variables
int offset = 0;
int highlight = 0;

// Last directory successfully displayed
int lastDir=0;
int lastDirLength=0;

// Root directory info
int startSec,secLength, numFiles;

// Set up array for holding file details, this should be dynamic
// but I'm lazy
#define MAXFILES 500
EXTENDEDFILEDETAILS fileDetails[MAXFILES];

// MAX 8 directory levels + filename + separators
char currentPath[((8*8)+15+9)];

// Stream values, ready for stream viewer
short	streamMode = STR_MODE24,
		borders = STR_BORDERS_ON,
		volume = MAX_VOL;

int main(void)
{
	short	block = INPUT_DELAY;

	int currentFile;

	InitSys();
	ClearVRAM();
	InitEnvs(db);

// Init Graphic
	InitPoly();

	PutDispEnv(&db[cdb].disp);
	SetDispMask(1);

	if(!InitCDBrowser())
		return;

	while (1)
	{
		cdb ^= 1;

		FntPrint(fIdA, "CD Browser V1.0\n\n");

		FntPrint(fIdA, "Stream Parameters\n", volume);		
		FntPrint(fIdA, "L2,R2 Volume+/-\t= %d\n", volume);
		FntPrint(fIdA, "L1       = Mode %s\n", (streamMode) ? "24Bit" : "16Bit");
		FntPrint(fIdA, "R1       = Borders %s\n\n", (borders) ? "On" : "Off");

		// Now print directory listing
		currentFile = drawFileList(numFiles);

		if (Pressed(SQUARE_KEY))
		{
			SwapDisk();
			InitCDBrowser();
		}
		else if (Pressed(TRIANGLE_KEY))
		{
			;
//			printf("Triangle");
		}
		else if (Pressed(CIRCLE_KEY))
		{
			displayFileDetails(currentFile);
		}
		else if (Pressed(X_KEY))
		{
			// If the lid is up wait for the lid to shut, check disk
			// and reload root directory
			IsCdReady();
			numFiles = selectEntry(currentFile);
		}
		else if (Pressed(R2_KEY))
		{
			volume += 2;
			if (volume > MAX_VOL)
				volume = MAX_VOL;
		}
		else if (Pressed(L2_KEY)) {
			volume -= 2;
			if (volume < 0)
				volume = 0;
		}
		else if (!block && Pressed(UP_KEY))
		{
			MoveHighlight(1,numFiles);
			block = INPUT_DELAY;
		}
		else if (!block && Pressed(DOWN_KEY))
		{
			MoveHighlight(0,numFiles);
			block = INPUT_DELAY;
		}
		else if (!block && Pressed(L1_KEY))
		{
			streamMode = (streamMode == STR_MODE24) ? STR_MODE16 : STR_MODE24;	
			block = INPUT_DELAY;
		}
		else if (!block && Pressed(R1_KEY))
		{
			borders = (borders == STR_BORDERS_ON) ? STR_BORDERS_OFF : STR_BORDERS_ON;	
			block = INPUT_DELAY;
		}

		if (block > 0)
			block--;

//	int polyY=0;
//	int polyX=20;
//	int polyW=texture.texture_w;
//	int polyH=texture.texture_h;
//	setXYWH(&poly, polyX, polyY, polyW, polyH);

		DrawPrim(&poly);

		FntFlush(fIdA);
		DrawSync(0);
		VSync(0);

		PutDrawEnv(&db[cdb].draw);
		PutDispEnv(&db[cdb].disp);
	}

	CloseSys();
	return 0;
}

/*
*
*       NAME            static void InitSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       20/03/98        Mike Kav        Created
*
*/
static void InitSys(void)
{
	ResetGraph(0);
	ResetCallback();
	SetGraphDebug(0);
	CdInit();

	// Video Mode.
	SetVideoMode(MODE_PAL);

	InitGeom();
	InitControllers();
	SndInit();
	VSyncCallback((void (*)()) VSyncCB);

}

/*
*
*       NAME            static void CloseSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       20/03/98        Mike Kav        Created
*
*/
static void CloseSys(void)
{
	VSyncCallback(NULL);
	StopCallback();
	StopControllers();
	ResetGraph(3);
}

/*
*
*       NAME		void InitEnvs(DB *db)
*
*       FUNCTION	Init the drawing and display environments.
*					Also init the application and profiler
*					FntPrint streams. 
*
*		NOTES
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void InitEnvs(DB *db)
{

	// Init the display and drawing environments.
	SetDefDrawEnv(&db[0].draw, 0,   0,       FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[0].disp, 0,   FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDrawEnv(&db[1].draw, 0,   FRAME_Y, FRAME_X, FRAME_Y);
	SetDefDispEnv(&db[1].disp, 0,   0,       FRAME_X, FRAME_Y);
	
	setRECT(&db[0].disp.screen, SCREEN_X, SCREEN_Y, 0, FRAME_Y);	
	setRECT(&db[1].disp.screen, SCREEN_X, SCREEN_Y, 0, FRAME_Y);	
	setRGB0(&db[0].draw, 0, 0, 50);
	setRGB0(&db[1].draw, 0, 0, 50);
	db[1].draw.isbg = db[0].draw.isbg = 1;

	// Init font environment.
	FntLoad(960, 256);	
	fIdA = FntOpen(18, 16, 310, 200, 0, 1024);			// Applic stream.
	SetDumpFnt(fIdA);	
}

/*
*
*       NAME		void SndInit(void)
*
*       FUNCTION	Init sound system and volumes.
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void SndInit(void)
{

	CdlATV	aud;
	char	result[8];

	aud.val0 = 127;
	aud.val1 = 127;
	aud.val2 = 127;
	aud.val3 = 127;

	CdControl(CdlDemute, NULL, result);
	CdControlB(CdlSetfilter, NULL, result);
	CdMix(&aud);

	// Clear last 100K of SPU RAM (i.e. maximum reverb workarea). 
	SpuInit();
	SpuSetTransStartAddr(421887);
	SpuWrite0(1024 * 100);

	SsInit();

	SsUtReverbOff();
	SsUtSetReverbType(0);
	SsUtSetReverbDepth(0, 0);

	SsSetTickMode(SS_TICKVSYNC);
	SsSetMVol(127, 127);

	SsSetSerialAttr(SS_SERIAL_A, SS_MIX, SS_SON);
	SsSetSerialVol(SS_SERIAL_A, 127, 127);

	SsUtSetReverbType(SS_REV_TYPE_STUDIO_B);
	SsUtReverbOn();
	VSync(75);						//Delay for a while =;-D
	SsUtSetReverbDepth(40, 40);
}

/*
*
*       NAME		void SndShutDown(void)
*
*       FUNCTION	Shut down the sound system, clear
*					reverb buffer etc
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void SndShutDown(void)
{

    SsUtReverbOff();
    SsUtSetReverbType(0);
    SsUtSetReverbDepth(0,0);

    // Clear last 100K of SPU RAM (i.e. maximum reverb workarea). 
    SpuSetTransStartAddr(421887);
    SpuWrite0(1024 * 100);

	// Wait until SPU RAM cleared.
	VSync(100);

    SsEnd();            
} 	

/*
*
*       NAME		static void VSyncCB(void)
*
*       FUNCTION	VSyncCallback. Check status of controllers
*					every second (50 VSyncs).
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
static void VSyncCB(void)
{

	frameNo++;

	if (!(frameNo % CHECK_CONTROLLERS))
		CheckControllers();
}

/*
*
*       NAME		void ClearVRAM(void)
*
*       FUNCTION	Clear entire contents of VRAM.
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void ClearVRAM(void)
{

	RECT	rectTL, rectTR,
			rectBL, rectBR;
	
	setRECT(&rectTL, 0, 0, 512, 256);
	setRECT(&rectTR, 512, 0, 512, 256);
	setRECT(&rectBL, 0, 256, 512, 256);
	setRECT(&rectBR, 512, 256, 512, 256);

	ClearImage(&rectTL, 0, 0, 0);
	ClearImage(&rectTR, 0, 0, 0);
	ClearImage(&rectBL, 0, 0, 0);
	ClearImage(&rectBR, 0, 0, 0);

	DrawSync(0); // Ensure VRAM is cleared before exit.
}


/*
*
*       NAME		int selectEntry(int currentFile)
*
*       FUNCTION	Process users file selection
*
*       NOTES		Function either passes the file number
*					to ParseFileType() if it is a file. If
*					it is a directory the new directory
*					details are created. Function returns
*					the number of files in the current
*					directory
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
int selectEntry(int currentFile)
{
	char endString[6];
	int numFiles,startSec,secLength;

	// get last two characters of selected file
	strncpy(endString,(fileDetails[currentFile].filename+strlen(fileDetails[currentFile].filename)-2),2);
	endString[2] = '\0';
	if( strcmp(endString,";1")==0 )
	{
		strncpy(endString,(fileDetails[currentFile].filename+strlen(fileDetails[currentFile].filename)-5),5);
		endString[5] = '\0';
		ParseFileType(endString,currentFile);
	}
	else
	{
		// Its a directory, rebuild directory view
		highlight = 0;
		offset = 0;
		startSec = fileDetails[currentFile].pos;
		secLength = (fileDetails[currentFile].size / 2048);

		lastDir			= startSec;
		lastDirLength	= secLength;

		CreatePath(fileDetails[currentFile].filename);
	}

	numFiles = GetNumDirEntries(lastDir,lastDirLength);
	if(numFiles > MAXFILES)
		printf("** Time to increase fileDetails structure\n");
	
	GetDirDetails(lastDir,lastDirLength);
	return numFiles;
}

/*
*
*       NAME		MoveHighlight(int i, int numFiles)
*
*       FUNCTION	Process users directional buttons
*
*       NOTES		Function controls highlight processing
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void MoveHighlight(int i, int numFiles)
{
	int displayFiles = VIEWFILES;

	// Check that we have greater than ten files to view
	// if not then set the displayed files correctly
	if(displayFiles > numFiles)
		displayFiles = numFiles;

	// up
	if(i==1)
	{
		// Check if we are at top of list
		if(highlight == 0)
		{
			if( offset > 0)
				offset--;
		}
		else
			highlight--;
	}
	// down
	if(i==0)
	{
		// Check if we are at bottom of list
		if(highlight == (displayFiles-1))
		{
			if( offset < (numFiles-VIEWFILES))
				offset++;
		}
		else
			highlight++;
	}

	return;
}

/*
*
*       NAME		int drawFileList(int numFiles)
*
*       FUNCTION	Draws file list, complete with colours
*					indicating directories
*
*       NOTES		Returns new current file number
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
int drawFileList(int numFiles)
{
	int number = 1;
	int ctr=0;
	char test[6];
	int fileNumber=0;
	int numDisplayFiles=VIEWFILES;

	// Normally display ten files, unless we have not got that many
	if(numDisplayFiles > numFiles)
		numDisplayFiles = numFiles;

		fileNumber+=offset;
		number+=offset;
		FntPrint("Files %2d to %d of %d files\n",(1+offset),(numDisplayFiles+offset),numFiles);

		FntPrint("%s\n\n",currentPath);		
		for(ctr=0;ctr<numDisplayFiles;ctr++)
		{
			if(highlight == ctr)
			FntPrint("\t~c800%2d:%s~c888\n",number++,fileDetails[fileNumber].filename);
			else
			{
				strncpy(test,(fileDetails[fileNumber].filename+strlen(fileDetails[fileNumber].filename)-5),5);
				test[5] = '\0';
				if( strcmp(test,"STR;1") == 0 )			
					FntPrint("\t~c080%2d:%s~c888\n",number++,fileDetails[fileNumber].filename);
				else
				{
					strncpy(test,(fileDetails[fileNumber].filename+strlen(fileDetails[fileNumber].filename)-2),2);
					test[2]='\0';

					if(strcmp(test,";1") != 0)
					{
						FntPrint("\t~c880%2d:%s~c888\n",number++,fileDetails[fileNumber].filename);
					}
					else
					{
						FntPrint("\t%2d:%s\n",number++,fileDetails[fileNumber].filename);
					}
				}
			}

			fileNumber++;
		} 

		return(highlight+offset);
}

/*
*
*       NAME		void ParseFileType(char *string,int currentFile)
*
*       FUNCTION	Used to hook in viewers, currently only TIM 
*					viewer is supported
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void ParseFileType(char *string,int currentFile)
{
	if( strcmp(string,"STR;1")==0 )
	{
		InitStream(currentFile);
	}
	else if( strcmp(string,"TIM;1")==0 )
	{
		TimViewer(fileDetails[currentFile]);
	}
	else
		return;

	InitPoly();
	return;
}

/*
*
*       NAME		void displayFileDetails(int file)
*
*       FUNCTION	Display files name, size and position
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void displayFileDetails(int file)
{
	int fileNumber=0;
	char endString[3];
	CdlLOC fp;

	CdIntToPos(fileDetails[file].pos,&fp);

	while( !Pressed(TRIANGLE_KEY) )
	{
		cdb ^= 1;

		fileNumber+=offset;
				
		strncpy(endString,(fileDetails[file].filename+strlen(fileDetails[file].filename)-2),2);
		endString[2] = '\0';
		if( strcmp(endString,";1")==0 )
		{
			FntPrint("File Details\n\n");
			FntPrint("File = %s\n",fileDetails[file].filename);
		}
		else
		{
			FntPrint("Directory Details\n\n");
			FntPrint("Directory = %s\n",fileDetails[file].filename);
		}
		
		FntPrint("Size = %d\n",fileDetails[file].size);
		FntPrint("Absolute Position = %d\n",fileDetails[file].pos);
		FntPrint("Position:\n");
		FntPrint("\tMin:%02x,Sec:%02x,Sector:%02x\n",fp.minute,fp.second,fp.sector);
		FntPrint("\nPress Triangle to continue\n");

		DrawSync(0);
		FntFlush(-1);
		VSync(0);

		PutDrawEnv(&db[cdb].draw);
		PutDispEnv(&db[cdb].disp);
	}
	
	return;
}

/*
*
*       NAME		void CreatePath(char *filename)
*
*       FUNCTION	Creates directory path for display
*					on screen
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
void CreatePath(char *filename)
{
	char *nameptr = currentPath;

	if( strcmp(filename,".") == 0 )
		return;

	if( strcmp(filename,"..") == 0 )
	{
		nameptr += (strlen(currentPath)-1);

		while(*nameptr != '\\')
		{
			*nameptr='\0';
			nameptr--;
		}
		
		if( strcmp(currentPath,"\\") != 0 )
			*nameptr='\0';
	}
	else
	{
		if(strlen(currentPath) != 1)
			strcpy( (currentPath + strlen(currentPath)) ,"\\");
		strcpy( (currentPath + strlen(currentPath)),filename);
	}
		
	return;
}

/*
*
*       NAME		int InitCDBrowser(void)
*
*       FUNCTION	Initialises the CD Browser by loading up
*					the root directory details and setting some
*					variables
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       20/03/98	Mike Kav        Created
*
*/
int InitCDBrowser(void)
{
	if(!CheckISO())
	{
		return 0;
	}

	offset = 0;
	highlight = 0;

	IsCdReady();
	// Initially get root dir details, use these to load in first directory
	GetRootDirDetails(&startSec,&secLength);

	lastDir			= startSec;
	lastDirLength	= secLength;
	strcpy(currentPath,"\\");

	IsCdReady();
	numFiles = GetNumDirEntries(startSec,secLength);
	if(numFiles > MAXFILES)
	{
		printf("** Time to increase fileDetails structure\n");
	}

	IsCdReady();
	GetDirDetails(startSec,secLength);

	return 1;
}


/*
*
*       NAME		static short ExitPressed(void)
*
*       FUNCTION	Normally returns 0 until a button is
*					pressed, used by the streaming code
*					to stop playing a stream
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       23/03/98	Mike Kav        Created
*
*/
static short ExitPressed(void) {
	return (Pressed(X_KEY) || Pressed(SELECT_KEY));
}

/*
*
*       NAME		void InitStream(int file)
*
*       FUNCTION	Gets video stream details and fills
*					out a stream data structure to enable good
*					old MOVIE2 to play the stream (note that the
*					movie code is MOVIE2 with a couple of modifcations)
*
*       NOTES		
*
*       CHANGED		PROGRAMMER      REASON
*       -------		----------      ------
*       23/03/98	Mike Kav        Created
*
*/
StrInfo streamFile;

void InitStream(int file)
{
	u_char gbuffer[2340];	// CD data loaded to this buffer
	u_long *cAddress = (u_long *)gbuffer;	// used to get buffer details
	int result;				// CD read return value
	CdlLOC fp = {0,0,0,0};				// CD file details

	CdSectorHeader headerDetails;


	CdIntToPos(fileDetails[file].pos,&fp);

    while (!CdControlB(CdlSeekL,(unsigned char *)&fp, 0))
    {
      printf("CdlSeekL failed\n");
    }

    if(!CdRead (1, (unsigned long *)gbuffer,(CdlModeSpeed|CdlModeRT|CdlModeSF|CdlModeSize1)))
    {
      printf("CdRead failed\n");
      return;
    }

    // Block until the CD has finished reading
    do
    {
		result = CdReadSync(1,0);
		if (result < 0)       // error
		{
        	return;
		}
	}while (result != 0);

	headerDetails.id=*(unsigned short*)(cAddress+3);
	headerDetails.type=*( ((unsigned short*)(cAddress+3)+1) );

	cAddress+=4;
	headerDetails.secCount=*(unsigned short*)(cAddress);
	headerDetails.nSectors=*( ((unsigned short*)(cAddress)+1) );

	cAddress+=1;
	headerDetails.frameCount=*(unsigned short *)(cAddress);
	cAddress+=1;
	headerDetails.frameSize=*(unsigned short *)(cAddress);

	cAddress+=1;
	headerDetails.width=*(unsigned short *)(cAddress);
	headerDetails.height=*( ((unsigned short *)(cAddress)+1) );

	cAddress+=3;
	headerDetails.reserved=*(unsigned short *)(cAddress);

	strcpy(streamFile.strName,fileDetails[file].filename);
	streamFile.strPos = fp;
	streamFile.mode = streamMode;
	streamFile.drawBorders = borders;
	streamFile.scrWidth = 320;
	streamFile.x = 0;
	streamFile.y = 0;
	streamFile.width = headerDetails.width;
	streamFile.height = headerDetails.height;
	streamFile.endFrame = 40000;
	streamFile.vlcBufSize = 0;
	streamFile.volume = volume;


        printf("Stream:%s\n",streamFile.strName);
        printf("File Pos:");
//        streamFile.strPos = fp;
//        streamFile.mode = streamMode;
 //       streamFile.drawBorders = borders;
//        streamFile.scrWidth = 320;
//        streamFile.x = 0;
//        streamFile.y = 0;

        printf("Width:%d,Height:%d\n",streamFile.width,streamFile.height);
//        streamFile.height = headerDetails.height;
//        streamFile.endFrame = 40000;
//        streamFile.vlcBufSize = 0;
//        streamFile.volume = volume;


	PlayStream(&streamFile, ExitPressed);

	return;
}

InitPoly()
{
	// Load texture to VRAM
	texture.addr=pictureTIM;
	if(!loadTIM(&texture))
		return;

	// Initialise poly
    SetPolyFT4(&poly);
    setRGB0(&poly, 100, 100, 100);
    tpage_x = (texture.texture_x>>6)<<6;
    tpage_y = (texture.texture_y>>8)<<8;
    poly.tpage = getTPage(texture.mode, 1, tpage_x, tpage_y);

    if (texture.mode == 0)
    {
//                printf("4-bit texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w*4-1, texture.texture_h-1);
		setXYWH(&poly, 255, 0, texture.texture_w*4, texture.texture_h);
		poly.clut = getClut( texture.clut_x, texture.clut_y);
    }
    else if (texture.mode == 1)
    {
//                printf("8-bit texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w*2-1, texture.texture_h-1);
		setXYWH(&poly, 255, 0, texture.texture_w*2, texture.texture_h);
		poly.clut = getClut( texture.clut_x, texture.clut_y);
    }
    else
    {
//                printf("16 bit direct texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w-1, texture.texture_h-1);
		setXYWH(&poly, 255, 0, texture.texture_w, texture.texture_h);
    }
}
