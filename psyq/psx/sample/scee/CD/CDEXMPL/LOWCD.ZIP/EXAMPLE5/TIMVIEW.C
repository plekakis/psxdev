/* Functions to read and display any .TIM image
*
*       NOTES   There are a few limitations. Texture width / height
*				must not be greater than 256 and the program cannot
*				display 24bit .TIMs.
*
*				Controls are:
*					Directional buttons - move image
*					Select 		- reset TIM to original values
*					Triangle 	- quit
*					R1/R2		- enlarge/shrink texture width
*					L1/L2		- enlarge/shrink texture height
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	20/03/98	Mike Kav        Created
*       30/03/98        Mike Kav        Added .TIM with controls to be displayed
*                                       
*/
#include <sys/types.h>
#include <kernel.h>
#include <libsn.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <libcd.h>
#include <libspu.h>
#include <libsnd.h>
#include <libgs.h>

#include "main.h"
#include "sceecd.h"
#include "timview.h"
#include "control.h"

#define FORM1_SIZE     2048 			  
#define Sectors(x) ((x+FORM1_SIZE-1)/FORM1_SIZE)
#define INPUT_DELAY 20

extern DB		db[2];		
extern short	cdb;							// Current double buffer.

// need to malloc this at some point, TIM image buffer
unsigned char loadbuf[327680];
u_long* addr = (unsigned long *)&loadbuf[0];

// Polygon details for displaying texture
POLY_FT4 poly;
int polyWidth;
int polyHeight;
int tpage_x, tpage_y;
TEXTURE_INFO texture;


// Screen resolution values
int xSize = 3;
int resX =512;
int resY=256;

#define	FRAME_X			512
#define	FRAME_Y			256

#define SCREEN_X		0
#define SCREEN_Y		18	

int		scrTable[5] =
		{256, 320, 368, 512, 640};

/*
*
*	NAME		void TimViewer(EXTENDEDFILEDETAILS file)
*
*	FUNCTION	Main control function, loads TIM into
*				VRAM and then displays the texture using
*				TimView()
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	20/03/98	Mike Kav		Created
*
*/
void TimViewer(EXTENDEDFILEDETAILS file)
{
	CdlLOC filePos;
	int numSectors;
	int mode = 0;

	CdIntToPos(file.pos,&filePos);

retry:

	if(!CdControlB(CdlSeekL,(unsigned char *)&filePos, 0))
	{
		printf("ERROR: could not do seek\n");  
		goto retry;
	}                               

	numSectors = Sectors(file.size);
	mode |= CdlModeSpeed;

	if(!CdRead(numSectors,addr,mode))
	{
		printf("ERROR: could not execute read\n");  
		goto retry;
	}                               

	while (CdReadSync(1,0) > 0 );

	// Load texture to VRAM
	texture.addr=addr;
	if(!loadTIM(&texture))
		return;

	// Initialise poly
    SetPolyFT4(&poly);
    setRGB0(&poly, 100, 100, 100);
    tpage_x = (texture.texture_x>>6)<<6;
    tpage_y = (texture.texture_y>>8)<<8;
    poly.tpage = getTPage(texture.mode, 1, tpage_x, tpage_y);

    if (texture.mode == 0)
    {
	//	printf("4-bit texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w*4-1, texture.texture_h-1);
		setXYWH(&poly, 20, 40, texture.texture_w*4, texture.texture_h);
		poly.clut = getClut( texture.clut_x, texture.clut_y);
    }
    else if (texture.mode == 1)
    {
	//	printf("8-bit texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w*2-1, texture.texture_h-1);
		setXYWH(&poly, 20, 40, texture.texture_w*2, texture.texture_h);
		poly.clut = getClut( texture.clut_x, texture.clut_y);
    }
    else
    {
	//	printf("16 bit direct texture\n");
		setUVWH(&poly, texture.texture_x-tpage_x, texture.texture_y-tpage_y,
		 texture.texture_w-1, texture.texture_h-1);
		setXYWH(&poly, 20, 40, texture.texture_w, texture.texture_h);
    }

	ViewTim();

	return;
}

/*
*
*	NAME		int	loadTIM(TEXTURE_INFO *info)
*
*	FUNCTION	Loads TIM into VRAM, displays error
*				message if TIM is too big to be put on a
*				polygon
*
*	NOTES		Taken for Dave V's TIM Preview Program
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	20/03/98	Mike Kav		Created
*
*/
int	loadTIM(TEXTURE_INFO *info)
{
	TIM_IMAGE	image;		/* TIM header */

        RECT srcRect;
	
	if( OpenTIM(info->addr) == 0)
			;
//		printf("Successfully Opened TIM\n");
	else
		printf("Failed to open TIM\n");

	while (ReadTIM(&image)) {
		if (image.caddr) {	// load CLUT (if needed)

			image.crect->x = 768;
			image.crect->y = 500;

			LoadImage(image.crect, image.caddr);

			info->clut_x = image.crect->x;
			info->clut_y = image.crect->y;

//			printf("Clut X = %d , Clut Y = %d \n", image.crect->x, image.crect->y);
//			printf("Clut Width = %d , Clut= %d \n", image.crect->w, image.crect->h);

		}
		if (image.paddr)
		{
                        // load texture pattern

			// Check size
			if( (image.prect->w > 256) || (image.prect->h > 256) )
			{
                                while( !Pressed(TRIANGLE_KEY) )
                                {
                                        cdb ^= 1;

                                        FntPrint("Cannot display texture\n");
                                        FntPrint("using %d,%d dimensions\n\n",image.prect->w,image.prect->h);
                                        FntPrint("Press Triangle to continue\n");

                                        DrawSync(0);
                                        FntFlush(-1);
                                        VSync(0);
                                
                                        PutDrawEnv(&db[cdb].draw);
                                        PutDispEnv(&db[cdb].disp);
                                }
                                return 0;
                        }

			image.prect->x = 768;
			image.prect->y = 0;
			info->mode      = image.mode & 3;

			// Check mode
			if(info->mode == 3)
			{
				while( !Pressed(TRIANGLE_KEY) )
				{
					cdb ^= 1;

					FntPrint("24bit mode not supported\n\n");
					FntPrint("Press Triangle to continue\n");

					DrawSync(0);
					FntFlush(-1);
					VSync(0);

					PutDrawEnv(&db[cdb].draw);
					PutDispEnv(&db[cdb].disp);
				}
				return 0;
			}

			LoadImage(image.prect, image.paddr);

			info->texture_x = image.prect->x;
			info->texture_y = image.prect->y;
			info->texture_w = image.prect->w;
			info->texture_h = image.prect->h;
			info->tpage	= image.prect->x>>6 + ((image.prect->y>>8) * 16);
// divide x by 64 to give tpage id then to see if 2nd row divide y by 256
//			printf("Texture X = %d , Texture Y = %d \n", image.prect->x, image.prect->y);
//			printf("Texture Width = %d , Height = %d \n", image.prect->w, image.prect->h);

		}
	}

	return 1;
}

/*
*
*	NAME		void ViewTim(void)
*
*	FUNCTION	Displays texture and allows user to manipulate
*				textures values
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	20/03/98	Mike Kav		Created
*       30/03/98        Mike Kav                Reset resolution on quitting
*                                               viewer
*
*/
void ViewTim(void)
{
	int polyY=0;
	int polyX=20;
	int polyW=texture.texture_w;
	int polyH=texture.texture_h;
	int initPolyY, initPolyX, initPolyW, initPolyH;

	short block = INPUT_DELAY;

	// Hold initial values ready for reset
	initPolyY = polyY;
	initPolyX = polyX;
	initPolyW = polyW;
	initPolyH = polyH;

	while(!Pressed(TRIANGLE_KEY))
	{
		cdb ^= 1;

		FntPrint(fIdA, "TIM Viewer V1.0\n\n");

		FntPrint(fIdA, "Current Res: %d,%d\n",resX,resY);
		FntPrint(fIdA, "Directional Buttons = Move Texture\n\n");		
		FntPrint(fIdA, "Triangle = Quit\n");
		FntPrint(fIdA, "L1,L2    = Height+/-\n");
		FntPrint(fIdA, "R1,R2    = Width+/-\n");
		FntPrint(fIdA, "Select   = Reset Texture\n");
		FntPrint(fIdA, "Start    = Change Resolution\n");

		if (Pressed(DOWN_KEY))
		{
			if(polyY < 512)
				polyY++ ;
		}
		else if (Pressed(UP_KEY))
		{
			if(polyY > -512)
				polyY--;
		}
		
		if (Pressed(LEFT_KEY))
		{
			if(polyX > -320)
				polyX--;
		}
		else if (Pressed(RIGHT_KEY))
		{
			if(polyX < 640)
				polyX++;
		}

		if (Pressed(L1_KEY))
		{
				if(polyH < 511)
				polyH++;
		}
		else if (Pressed(L2_KEY))
		{
				if(polyH > 0)
				polyH--;
		}

		if (Pressed(R1_KEY))
		{
				if(polyW < 1023)
				polyW++;
		}
		else if (Pressed(R2_KEY))
		{
				if(polyW > 0)
				polyW--;
		}

		if (Pressed(SELECT_KEY))
		{
			polyY = initPolyY;
			polyX = initPolyX;
			polyW = initPolyW;
			polyH = initPolyH;
		}

		if (!block && Pressed(START_KEY))
		{
			if (xSize == 4)
			     xSize = 0;
			else
			     xSize++;
			resX=scrTable[xSize];
			resY=FRAME_Y;
			changeRes();
			block = INPUT_DELAY;
		}

		if (block > 0)
			block--;

		setXYWH(&poly, polyX, polyY, polyW, polyH);

		DrawPrim(&poly);
		DrawSync(0);
		FntFlush(-1);
		VSync(0);

		PutDrawEnv(&db[cdb].draw);
		PutDispEnv(&db[cdb].disp);

	}

        // reset to original resolution
        resX=scrTable[3];
        resY=FRAME_Y;
        changeRes();

        return;
}

/*
*
*	NAME		void changeRes(void)
*
*	FUNCTION	Changes screen resolution
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	20/03/98	Mike Kav		Created
*
*/
void changeRes(void)
{
    ResetGraph(1);
    SetDefDrawEnv(&db[0].draw, 0,   0,       resX, resY);
    SetDefDispEnv(&db[0].disp, 0,   resY, resX, resY);
    SetDefDrawEnv(&db[1].draw, 0,   resY, resX, resY);
    SetDefDispEnv(&db[1].disp, 0,   0,       resX, resY);

    setRECT(&db[0].disp.screen, SCREEN_X, SCREEN_Y, 0, resY);
    setRECT(&db[1].disp.screen, SCREEN_X, SCREEN_Y, 0, resY);
    // keep the geomoffset as the centre of the screen
	setRGB0(&db[0].draw, 0, 0, 50);
	setRGB0(&db[1].draw, 0, 0, 50);
	db[1].draw.isbg = db[0].draw.isbg = 1;

    SetGeomOffset((resX / 2), (resY / 2));
}
