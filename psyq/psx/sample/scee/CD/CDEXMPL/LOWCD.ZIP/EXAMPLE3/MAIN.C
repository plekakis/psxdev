/* Code demonstrating use of some low level functions, this
*	program fills a data structure with CD file details to
*	allow loading of these files at a later time
*
*	NOTES   
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------		------
*	19/03/98	Mike Kav		Created
*
*/

#include <sys/types.h>
#include <kernel.h>
#include <libsn.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <libcd.h>
#include <libspu.h>
#include <libsnd.h>
#include <libgs.h>

#include "sceecd.h"

#ifdef FINAL
u_long _ramsize   = 0x00200000;				// Use 2MB for final.
u_long _stacksize = 0x00004000;
#else
u_long _ramsize   = 0x00800000;				// Use 8MB for development.
u_long _stacksize = 0x00008000;
#endif

static void InitSys(void); 
static void CloseSys(void);
static void drawFileList(int numFiles);

// Set up array for holding file details, this should be dynamic
// but I'm lazy
#define MAXFILES 500
EXTENDEDFILEDETAILS fileDetails[MAXFILES];

int main(void)
{

	int startSec,secLength, numFiles;

	InitSys();

	printf("** Test of CheckISO\n");
	if(CheckISO())
		printf("ISO Image Found\n\n");
	else
		printf("CD does not have an ISO image\n");

	// Initially get root dir details, use these to load in first directory
	GetRootDirDetails(&startSec,&secLength);

	numFiles = GetNumDirEntries(startSec,secLength);
	if(numFiles > MAXFILES)
	{
		printf("** Time to increase fileDetails structure\n");
	}

	GetDirDetails(startSec,secLength);
	drawFileList(numFiles);

	CloseSys();

	return 0;
}

/*
*
*       NAME            static void InitSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       19/03/98        Mike Kav        Created
*
*/
static void InitSys(void)
{
	ResetGraph(0);
	ResetCallback();
	SetGraphDebug(0);
	CdInit();
}

/*
*
*       NAME            static void CloseSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       19/03/98        Mike Kav        Created
*
*/
static void CloseSys(void)
{
	VSyncCallback(NULL);
	StopCallback();
	ResetGraph(3);
}

/*
*
*	NAME		void drawFileList(int numFiles)
*
*	FUNCTION	Displays filelist
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	19/03/98	Mike Kav		Created
*
*/
void drawFileList(int numFiles)
{
	int ctr=0;

		for(ctr=0;ctr<numFiles;ctr++)
		{
			printf("Filename:%s\tSize:%d\tPos:%d\n",fileDetails[ctr].filename,fileDetails[ctr].size,fileDetails[ctr].pos);
		} 

	return;
}
