/* CdSearchFile Replacement plus other low level CD stuff
*
*       NOTES   The new CdSearchFile can find files on an
*               ISO image without the limitations of the
*               original CdSearchFile. Note that however
*               the maximum number of directories that
*               it can search is 256, however you can have
*               as many files as you want in each directory
*               A limitation of ISO 9660 means that the
*               maximum depth of directories is 8
*
*               The new CdSearchFile also returns just the
*               position of the file and the length in bytes
*               This is to conserve space as to convert to a
*               value that can be used just involves a call
*               to CdIntToPos()
*               Normal format is:
*               Sectors
*               0 - 15 Used by device defined in System ID
*               16      PVD - primary volume descriptor
*               17 PVDT - primary volume decriptor terminator
*               18 le path table
*               19 optional le path table
*               20 be path table
*               21 be optional path table
*               22 Root Directory location
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/03/98	Mike Kav        Created
*/

#include "SCEEcd.h"

// Private functions only used by SCEECdSearchFile() and displayPVD()
void    cd_read(long size,long loc,char* buf);
void    GetRootDirDetails(int *secNum, int *numSectors);
int     IsFileInDir(int *startSec, int *numSectors, char *name);
void	printString (int first, int last);
int		makeInt(int start);
short	makeShort(int start);
void	displayTime (int i);
void	displayDir(int i);
void	displayLPath(char *title, unsigned long int sec);

unsigned char loadbuf[2048];

/*
*
*	NAME		void cd_read(long size,long loc,char* buf)
*
*	FUNCTION	Basic function to load data from CD
*
*	NOTES		Parameters are:
*					Number of sectors to read
*					Sector number to start read from
*					Memory buffer to put the data into
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	11/03/98	Mike Kav		Created
*
*/
void cd_read(long size,long loc,char* buf)
{
    CdlLOC pos;

    CdIntToPos(loc,&pos);
    CdControl(CdlSetloc, (u_char *)&pos,0);

    CdRead(size,(u_long *)buf,CdlModeSpeed);
    CdReadSync(0,0);

	return;
}

/*
*
*	NAME		void GetRootDirDetails(int *secNum, int *numSectors)
*
*	FUNCTION	Gets the root directory starting sector and size from the
*				little endian path table
*
*	NOTES		This should be the starting position for getting all the
*				files and directories on a CD. The root directory will be
*				a multiple of 2048. Normal PSX CD's using CdSearchFile are
*				limited to only one sectors worth of files. Hence all old
*				PSX titles using CdSearchFile will be 2048 long, and normally
*				starting at sector 22.
*                       Parameters are:
*                                       secNum - returns starting sector
*                                       numSectors - returns number of sectors
*                                               for the root dir
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	09/03/98	Mike Kav		Created
*
*/
void GetRootDirDetails(int *secNum, int *numSectors)
{
        // read PVD details from sector 16
        cd_read(1,0x10,&loadbuf);

        // Get value of sector position
        *secNum  = makeInt(158);
        *numSectors  = makeInt(166);

        *numSectors = *numSectors / 2048;

        return;
}

/*
*
*	NAME		int SCEECdSearchFile(char *name, FILEDETAILS *fp)
*
*	FUNCTION	Returns the file position and size of the specified
*				file. Function returns 1 on success, 0 on failure
*
*
*	NOTES		This CdSearchFile does not have the limitation
*				imposed as the normal library CdSearchFile, i.e.
*				the CD can have as many files as it wants in each
*				directory. The CD is limited to 256 directories
*				but not for this function.
*				The function returns an absolute sector location
*				which must be converted using CdIntToPos() before
*				being used in any CdRead style functions
*                       	
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	11/03/98	Mike Kav		Created
*
*/
int SCEECdSearchFile(char *name, FILEDETAILS *fp)
{
	char work[12];
	char *workPtr;
	char *namePtr;
	int i;
	int secNum, numSectors;
	int numBytes;

        // Check we have a root directory
	if(*name!='\\')
		return(0);

	GetRootDirDetails(&secNum,&numSectors);

	// Now create a directory name and check that it is on the CD
	// only do this a maximum of 8 times (iso 9660 limitation)
	namePtr = name;

	for(i=0;i<8;i++)
	{
		work[0] = '\0';
		workPtr=&work[0];
		namePtr++;

		while(*namePtr != '\\' && *namePtr != '\0')
			*workPtr++ = *namePtr++;

		*workPtr = '\0';

		if(*namePtr=='\0')
		{
			// find file in root directory
                        if( (numBytes = IsFileInDir(&secNum,&numSectors,work)) )
                        {
                        fp->pos = secNum;
                        fp->size = numBytes;
                        return 1;
                        }
                        else
                                return 0;
		}
		else
                {
                        // check that directory exists and use it's
                        // pos / size in the next loop
                        if( !IsFileInDir(&secNum,&numSectors,work) )
				return 0;
                }
	}

	return 0;
}

/*
*
*	NAME		int IsFileInDir(int *startSec, int *numSectors, char *name)
*
*	FUNCTION	Loops through a directory specified in startSec
*				and if it finds the name passed in returns the
*				found files start sector and length
*
*
*	NOTES		
*                       	
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	12/03/98	Mike Kav		Created
*
*/
int IsFileInDir(int *startSec, int *numSectors, char *name)
{

	int i;
	int j=0;
	int first,last;
	unsigned long value;
	unsigned long length;
	int l;
	char work[12];

	// Loop through all the sectors, checking for directory or filename
	for(i=0;i<*numSectors;i++)
	{ 
		j=0;
		cd_read(1,(*startSec+i),&loadbuf);
			
		while(loadbuf[j])
		{
			// Copy name from directory record
			first = (j+33);
			last = (j+32+loadbuf[j+32]);
			l = 0;
			while (first <= last)
			{
				work[l++] = loadbuf[first++];
			}

			work[l]='\0';

			// compare directory record to filename being searched
			// for, if they are equal than return the sector position
			// and length
			if( strcmp(work,name) == 0)
			{
				// Get value of sector position
				value  = loadbuf[j+2];
				value += loadbuf[j+3]<<8;
				value += loadbuf[j+4]<<16;
				value += loadbuf[j+5]<<24;
				length  = loadbuf[j+10];
				length += loadbuf[j+11]<<8;
				length += loadbuf[j+12]<<16;
				length += loadbuf[j+13]<<24;

                *startSec   = value;
                *numSectors = (length / 2048);
                return length;
            }
	        // Not found, now check next record
                j+=loadbuf[j];
        }
    }

	return 0;
}

/*
*
*	NAME		int CheckISO(void)
*
*	FUNCTION	Checks if CD has an ISO image
*
*	NOTES		Function retruns 1 if CD is an ISO image
*				Sector 16 contains the PVD of the CD. This has
*				a value 1CD0011 in the first 7 bytes. 
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/03/98	Mike Kav		Created
*
*/
int CheckISO(void)
{
	// Read sector 16 and check header
        cd_read(1,0x10,&loadbuf[0]);

        if(strncmp(&loadbuf[1],"CD001",5) == 0)
		return 1;

	return 0;
}

/*
*
*	NAME		void displayPVD(void)
*
*	FUNCTION	Prints out Primary Volume Descriptor details
*
*	NOTES		The PVD contains details such as system id, 
*				volume id, path tables, and important information
*				such as the root directory start point
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
void displayPVD(void)
{
	unsigned int lpathsec, optlpathsec;		// path table variables

	// PVD always at sector 16
	cd_read(1,0x10,&loadbuf);

	// Convert lpath values ready to use as a sector location to load
	lpathsec = makeInt(140);
	optlpathsec = makeInt(144);

	printf("Primary Volume Descriptor\n");
	printf("ID :\t\t\t\t%c%c%c%c%c\n", loadbuf[1], loadbuf[2], loadbuf[3], loadbuf[4], loadbuf[5]);
	printf("Version :\t\t\t%d\n", loadbuf[6]);
	printf("System ID :\t\t\t"); printString(8, 39);
	printf("\nVolume Identifier :\t\t"); printString(40, 71);
	printf("\nVolume Space Size :\t\t%d\n", makeInt(80));
	printf("Volume Set Size :\t\t%d\n",loadbuf[120]);
	printf("Volume Sequence Number :\t%d\n", loadbuf[124]);
	printf("Logical Block Size :\t\t%d\n",makeShort(128));
	printf("Path Table Size :\t\t%d\n", makeShort(132));
	printf("L-Path Table Location :\t\t%d\n",lpathsec);
  	printf("Optional L-Path Table Location :%d\n", optlpathsec);
	printf("Root directory entry :\n");
	displayDir(156);
	printf("Volume Set Identifier :\t\t"); printString(190, 317);
	printf("\nPublisher Identifier :\t\t"); printString(318, 445);
	printf("\nData Preparer Identifier :\t"); printString(446, 573);
	printf("\nApplication Identifier :\t");	printString(574, 701);
	printf("\nCopyright File Identifier :\t"); printString(702, 738);
	printf("\nAbstract File Identifier :");	printString(739, 775);
	printf("\nBibliography File Identifier :");	printString(776, 812);
	printf("\nVolume Creation Date/Time :\t");
	displayTime(813);
	printf("\nVolume Modification Date/Time :\t");
	displayTime(830);
	printf("\nVolume Expiration Date/Time :\t");
	displayTime(847);
	printf("\nVolume Effective Date/Time :\t");
	displayTime(864);
	printf("\nFile Structure Version :\t%d\n\n",loadbuf[881]);

	if (lpathsec)
		displayLPath("L-Path", lpathsec);
	if (optlpathsec)
		displayLPath("Optional L-Path", optlpathsec);

	return;
}

/*
*
*	NAME		void displayTime (int i)
*
*	FUNCTION	formats and displays the date / time
*				values from a given position in the load
*				buffer
*
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
void displayTime (int i)
{
	printString(i+6, i+7);
	printf("/");
	printString(i+4, i+5);
	printf("/");
	printString(i, i+3);
	printf(" ");
	printString(i+8, i+9);
	printf(":");
	printString(i+10, i+11);
	printf(":");
	printString(i+12, i+13);
	printf(".");
	printString(i+14, i+15);
	printf(" GMT offset %d", loadbuf[i+16]);
}

/*
*
*	NAME		void displayDir(int i)
*
*	FUNCTION	formats and displays a directory record
*				from a given position in the load buffer
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
void displayDir(int i)
{
	printf("\t\tLength :\t\t\t%d\n", loadbuf[i]);
	printf("\t\tExtended Attribute Length :\t%d\n", loadbuf[i+1]);
	printf("\t\tStart Location :\t\t%d\n", makeInt(i+2) );
	printf("\t\tData Length :\t\t\t%d\n", makeInt(i+10));
	printf("\t\tRecording Date/Time : ");
	printf("%d/%d/%d %d:%d:%d GMT offset %d",
		loadbuf[i+20], loadbuf[i+19], loadbuf[i+18]+1900, loadbuf[i+21], loadbuf[i+22],loadbuf[i+23], loadbuf[i+24]);
	printf("\n\t\tFile Flags :\t\t\t%d\n", loadbuf[i+25]);
	printf("\t\tFile Unit Size :\t\t%d\n", loadbuf[i+26]);
	printf("\t\tInterleave Gap Size :\t\t%d\n", loadbuf[i+27]);
	printf("\t\tVolume Sequence Number :\t%d\n", makeShort(i+28));
	printf("\t\tName :\t\t\t");
	if ((loadbuf[i+33] == 1) && (loadbuf[i+34] == 0))
		printf(".");
	else if ((loadbuf[i+33] == 1) && (loadbuf[i+34] == 1))
		printf("..");
	else
		printString(i+34, i+33+loadbuf[i+34]);
	printf("\n");
}

/*
*
*	NAME		void displayLPath(char *title, unsigned long int sec)
*
*	FUNCTION	formats and displays a path table record
*				from a given position in the load buffer
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
void displayLPath(char *title, unsigned long int sec)
{
	int i = 0, j = 1;

	cd_read(1,sec,&loadbuf);
	printf("Sector %d : %s\n\n", sec, title);
	printf("Ent  ID len  Ext Attr Len     Start  Parent Dir  ID\n");
	printf("====================================================================\n");

	while (loadbuf[i]) {
		if (i >= 2048)
		{
			sec++;
			cd_read(1,sec,&loadbuf);
			i -= 2048;
		}
		printf("%3d  %6d  %12d  %8d  %10d  ", j++, loadbuf[i], loadbuf[i+1], 
				makeInt(i+2), makeShort(i+6) );
		if ((loadbuf[i] == 1) && (loadbuf[i+8] == 0))
			printf(".");
		else if ((loadbuf[i] == 1) && (loadbuf[i+8] == 1))
			printf("..");
		else
			printString(i+8, i+7+loadbuf[i]);
		i += ((loadbuf[i] + 8 + 1) & 0xfffe);
		printf("\n");
	}

	printf("=====================================================================\n\n");
}

/*
*
*	NAME		int makeInt(int start)
*
*	FUNCTION	Converts 4 characters from loadbuf into a usable
*				value
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
int makeInt(int start)
{
/*
	int value;
					value  = loadbuf[start];
					value += loadbuf[start+1]<<8;
					value += loadbuf[start+2]<<16;
					value += loadbuf[start+3]<<24;
	return value;
*/
	return( loadbuf[start]+(loadbuf[start+1]<<8)+(loadbuf[start+2]<<16)+(loadbuf[start+3]<<24) );

}

/*
*
*	NAME		short makeShort(int start)
*
*	FUNCTION	Converts 2 characters from loadbuf into a usable
*				value
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
short makeShort(int start)
{
/*
	short value;
					value  = loadbuf[start];
					value += loadbuf[start+1]<<8;
	return value;
*/
	return( loadbuf[start] + (loadbuf[start+1]<<8) );

}

/*
*
*	NAME		void printString (int first, int last)
*
*	FUNCTION	Displays a string from the load buffer
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	12/03/98	Mike Kav		Created
*
*/
void printString (int first, int last)
{
	while (first <= last)
		printf("%c",loadbuf[first++]);
}

/*
*
*	NAME		void PrintDirDetails(int startSec, int numSectors)
*
*	FUNCTION	Prints out directory details from the CD
*
*	NOTES		Input parameters contain the starting sector position
*				and the number of sectors to read for that directory
*				This function will travel down any directories it finds
*				This function also wraps the array of directories around
*				at 256 to avoid overwriting memory, to alter this value
*				just change the dirsToDo array and remove the
*					todoptr &= 255;
*				line
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	09/03/98	Mike Kav		Created
*
*/
void PrintDirDetails(int startSec, int numSectors)
{
	int i;
	int j=0;
	int first,last;
	unsigned long value;
	unsigned long length;
	unsigned long dirsToDo[256][2];

	int todoptr = 0, donext = 0;

	// set up array, place first sector and length in first element of array
	dirsToDo[todoptr][0] = startSec;
	dirsToDo[todoptr++][1] = numSectors;

	// Initially todoptr = 1 and donext = 0;
	while (donext != todoptr)
	{
		startSec = dirsToDo[donext][0];
		numSectors = dirsToDo[donext++][1];

		for(i=0;i<numSectors;i++)
		{	
			j=0;
			// Read Sector, for each entry if file output file details, if dir call this
			// function with start sector and number of sectors
		    cd_read(1,(startSec+i),&loadbuf);

			printf("Sector %d :\n\n",(startSec+i));
			printf("Len Ext    Start  DataLen    Recording Date GMT Flg USz IGp Vol ID\n");
			printf("===============================================================================\n");
			
			while(loadbuf[j])
			{
				// Get start sector and length for file / dir entry
				value = makeInt(j+2);
				length = makeInt(j+10);

				printf("%3d %3d %8d %8d ",loadbuf[j],loadbuf[j+1],value,length);
				printf("%2d/%2d/%2d %2d:%2d:%2d %3d", loadbuf[j+20], loadbuf[j+19],loadbuf[j+18], loadbuf[j+21], loadbuf[j+22], loadbuf[j+23], loadbuf[j+24]);
				printf("%4d%4d%4d%4d ", loadbuf[j+25], loadbuf[j+26], loadbuf[j+27], makeShort(j+28));

				// Is it current directory [32] == 1
				if( (loadbuf[j+32] == 1) && (loadbuf[j+33] == 0))
					printf(".");
				else if( (loadbuf[j+32] == 1) && (loadbuf[j+33] == 1))
					printf("..");
				else
				{			
					// Print file name
					first = (j+33);
					last = (j+32+loadbuf[j+32]);
					printString(first,last);

					if(loadbuf[j+25] & 2)
					{
						// new directory, put in array to process later
						dirsToDo[todoptr][0] = value;
						dirsToDo[todoptr++][1] = length / 2048;
						// make sure pointer does go over the array size
						todoptr &= 255;

					}
				}
				// add the number of bytes in the record onto j
				j+=loadbuf[j];
				printf("\n");
			}
		}
	}
}
