/* CdSearchFile Replacement
*
*       NOTES   The new CdSearchFile can find files on an
*               ISO image without the limitations of the
*               original CdSearchFile. Note that however
*               the maximum number of directories that
*               it can search is 256, however you can have
*               as many files as you want in each directory
*               A limitation of ISO 9660 means that the
*               maximum depth of directories is 8
*
*               The new CdSearchFile also returns just the
*               position of the file and the length in bytes
*               This is to conserve space as to convert to a
*               value that can be used just involves a call
*               to CdIntToPos()
*               Normal format is:
*               Sectors
*               0 - 15 Used by device defined in System ID
*               16      PVD - primary volume descriptor
*               17 PVDT - primary volume decriptor terminator
*               18 le path table
*               19 optional le path table
*               20 be path table
*               21 be optional path table
*               22 Root Directory location
*
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*       11/03/98        Mike Kav        Created
*/

#include "SCEEcd.h"

// Private functions only used by SCEECdSearchFile()
void    cd_read(long size,long loc,char* buf);
void    GetRootDirDetails(int *secNum, int *numSectors);
int     IsFileInDir(int *startSec, int *numSectors, char *name);


unsigned char loadbuf[2048];

/*
*
*	NAME		void cd_read(long size,long loc,char* buf)
*
*	FUNCTION	Basic function to load data from CD
*
*	NOTES		Parameters are:
*					Number of sectors to read
*					Sector number to start read from
*					Memory buffer to put the data into
*
*       CHANGED         PROGRAMMER      REASON
*	-------  	----------  	------
*       11/03/98        Mike Kav        Created
*
*/
void cd_read(long size,long loc,char* buf)
{
    CdlLOC pos;

    CdIntToPos(loc,&pos);
    CdControl(CdlSetloc, (u_char *)&pos,0);

    CdRead(size,(u_long *)buf,CdlModeSpeed);
    CdReadSync(0,0);

	return;
}

/*
*
*       NAME            void GetRootDirDetails(int *secNum, int *numSectors)
*
*	FUNCTION	Gets the root directory starting sector and size from the
*				little endian path table
*
*	NOTES		This should be the starting position for getting all the
*				files and directories on a CD. The root directory will be
*				a multiple of 2048. Normal PSX CD's using CdSearchFile are
*				limited to only one sectors worth of files. Hence all old
*				PSX titles using CdSearchFile will be 2048 long, and normally
*				starting at sector 22.
*                       Parameters are:
*                                       secNum - returns starting sector
*                                       numSectors - returns number of sectors
*                                               for the root dir
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	09/03/98	Mike Kav		Created
*
*/
void GetRootDirDetails(int *secNum, int *numSectors)
{
        // read PVD details from sector 16
        cd_read(1,0x10,&loadbuf);


        // Get value of sector position
        *secNum  = loadbuf[158];
        *secNum += loadbuf[159]<<8;
        *secNum += loadbuf[160]<<16;
        *secNum += loadbuf[161]<<24;
        *numSectors  = loadbuf[166];
        *numSectors += loadbuf[167]<<8;
        *numSectors += loadbuf[168]<<16;
        *numSectors += loadbuf[169]<<24;

        *numSectors = *numSectors / 2048;

        return;
}

/*
*
*       NAME            int SCEECdSearchFile(char *name, FILEDETAILS *fp)
*
*       FUNCTION        
*
*       NOTES           
*                       Parameters are:
*                                       secNum - returns starting sector
*
*       CHANGED         PROGRAMMER      REASON
*	-------  	----------  	------
*       11/03/98        Mike Kav        Created
*
*/
int SCEECdSearchFile(char *name, FILEDETAILS *fp)
{
	char work[12];
	char *workPtr;
	char *namePtr;

	int i;

	int secNum, numSectors;
        int numBytes;

        // Check we have a root directory
	if(*name!='\\')
		return(0);

	GetRootDirDetails(&secNum,&numSectors);

	// Now create a directory name and check that it is on the CD
	// only do this a maximum of 8 times (iso 9660 limitation)
	namePtr = name;

	for(i=0;i<8;i++)
	{
		work[0] = '\0';
		workPtr=&work[0];
		namePtr++;

		while(*namePtr != '\\' && *namePtr != '\0')
			*workPtr++ = *namePtr++;

		*workPtr = '\0';

		if(*namePtr=='\0')
		{
			// find file in root directory
                        if( (numBytes = IsFileInDir(&secNum,&numSectors,work)) )
                        {
                        fp->pos = secNum;
                        fp->size = numBytes;
                        return 1;
                        }
                        else
                                return 0;
		}
		else
                {
                        // check that directory exists and use it's
                        // pos / size in the next loop
                        if( !IsFileInDir(&secNum,&numSectors,work) )
				return 0;
                }
	}

	return 0;
}

int IsFileInDir(int *startSec, int *numSectors, char *name)
{
	unsigned char loadbuf[2048];

	int i;
	int j=0;
	int first,last;
	unsigned long value;
	unsigned long length;
	int l;
	char work[12];

        for(i=0;i<*numSectors;i++)
        { 
                j=0;
                // Read Sector, for each entry if file output file details, if dir call this
                // function with start sector and number of sectors
                cd_read(1,(*startSec+i),&loadbuf);
			
                while(loadbuf[j])
                {
                        // Get value of sector position
                        value  = loadbuf[j+2];
                        value += loadbuf[j+3]<<8;
                        value += loadbuf[j+4]<<16;
                        value += loadbuf[j+5]<<24;
                        length  = loadbuf[j+10];
                        length += loadbuf[j+11]<<8;
                        length += loadbuf[j+12]<<16;
                        length += loadbuf[j+13]<<24;

                        // Is it current directory [32] == 1
//                        if( (loadbuf[j+32] == 1) && (loadbuf[j+33] == 0))
//                                printf(".");
//                        else if( (loadbuf[j+32] == 1) && (loadbuf[j+33] == 1))
//                                printf("..");
//                        else
//                        {                
                                // Print file name
                                first = (j+33);
                                last = (j+32+loadbuf[j+32]);
                                l = 0;
                                while (first <= last)
                                {
                                        work[l++] = loadbuf[first++];
                                }

                                work[l]='\0';

                                if( strcmp(work,name) == 0)
                                {
                                        *startSec   = value;
                                        *numSectors = (length / 2048);
                                        return length;
                                }

//                        }

                // add the number of bytes in the record onto j
                j+=loadbuf[j];
                }
        }

	return 0;
}
