/* Code demonstrating use of new SCEECdSearchFile function
*
*       NOTES   The new CdSearchFile can find files on an
*               ISO image without the limitations of the
*               original CdSearchFile. Note that however
*               the maximum number of directories that
*               it can search is 256, however you can have
*               as many files as you want in each directory
*               A limitation of ISO 9660 means that the
*               maximum depth of directories is 8
*
*               The new CdSearchFile also returns just the
*               position of the file and the length in bytes
*               This is to conserve space as to convert to a
*               value that can be used just involves a call
*               to CdIntToPos()
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*       11/03/98        Mike Kav        Created
*
*/

#include <sys/types.h>
#include <kernel.h>
#include <libsn.h>
#include <libgte.h>
#include <libgpu.h>
#include <libetc.h>
#include <libcd.h>
#include <libspu.h>
#include <libsnd.h>

#include "main.h"
#include "sceecd.h"
#include "control.h"

#ifdef FINAL
u_long _ramsize   = 0x00200000;				// Use 2MB for final.
u_long _stacksize = 0x00004000;
#else
u_long _ramsize   = 0x00800000;				// Use 8MB for development.
u_long _stacksize = 0x00008000;
#endif

static void InitSys(void); 
static void CloseSys(void);


int main(void) {


        FILEDETAILS fp;

	InitSys();

        printf("** Test of Searchfile\n\n");

        // Insert your filenames here

        if(SCEECdSearchFile("\\SYSTEM.CNF;1",&fp) == 1)
                printf("\\SYSTEM.CNF;1 fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("\\SYSTEM.CNF;1 Not Found\n");

        if(SCEECdSearchFile("\\BIN\\GOENG.FNT;1",&fp) == 1)
                printf("\\BIN\\GOENG.FNT;1 fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("\\BIN\\GOENG.FNT;1 Not Found\n");

        if(SCEECdSearchFile("\\GRAPHICS\\DIALOG\\SOUND\\SOUND.TIM;1",&fp) == 1)
                printf("\\GRAPHICS\\DIALOG\\SOUND\\SOUND.TIM;1 fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("\\GRAPHICS\\DIALOG\\SOUND\\SOUND.TIM;1 Not Found\n");

        if(SCEECdSearchFile("\\SOUND.TIM;1",&fp) == 1)
        printf("\\SOUND.TIM;1 fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("\\SOUND.TIM;1 Not Found\n");

        if(SCEECdSearchFile("\\GRAPHICS\\SOUND.TIM;1",&fp) == 1)
        printf("fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("Not Found\n");

        if(SCEECdSearchFile("\\GRAPHICS\\SPOON\\SOUND.TIM;1",&fp) == 1)
        printf("fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("Not Found\n");

        if(SCEECdSearchFile("\\SYSTEM.CNF;1",&fp) == 1)
                printf("fp.pos:%d,size:%d\n",fp.pos,fp.size);
        else
                printf("\\SYSTEM.CNF;1 Not Found\n");

	CloseSys();
	return 0;
}

/*
*
*       NAME            static void InitSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       11/03/98        Mike Kav        Created
*
*/
static void InitSys(void)
{
	ResetGraph(0);
	ResetCallback();
	SetGraphDebug(0);
	CdInit();
	CdSetDebug(1);
}

/*
*
*       NAME            static void CloseSys(void)
*
*       FUNCTION        Does the necessary initialization
*
*       NOTES           Copied from MOVIE2 for some reason
*
*
*       CHANGED         PROGRAMMER      REASON
*       -------         ----------      ------
*       11/03/98        Mike Kav        Created
*
*/
static void CloseSys(void)
{
	VSyncCallback(NULL);
	StopCallback();
	StopControllers();
	ResetGraph(3);
}

