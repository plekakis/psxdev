/* CD code to load data files from CD.
*
*	NOTES		DEBUG can be defined to allow the printing of messages
*				to the debug window
*				DEVKIT can be defined to allow the writing of 'pos.h'
*				containing the file positions that could be used instead
*				of CdSearchFile in the end build
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav	Created
*
*/

//#define DEBUG
#define DEVKIT

#include <sys/types.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include "cd.h"

  
#ifdef DEBUG
	char gDebugLine[80];
	int debugFileHandle=0;
	#define WRITEDEBUGLINE PCwrite(gDebugfileHandle,gDebugLine,strlen(gDebugLine));
#endif

FILEDETAILS CdFileData[] = 
	{
		{"\\RS\\ANALOG.RS;1",0},	// Analog pad		0
		{"\\RS\\DWARNING.RS;1",0},	// Piracy Screen	1
		{"\\RS\\SONY.RS;1",0},	// Sony Presents	2
		{"\\RS\\BACK.RS;1",0},	// Menu background	3
		{"\\RS\\TILES.RS;1",0},	// Tile graphics	4
		{"\\RS\\MEMSPRT.RS;1",0},	// Memory card		5
		{"\\RSB\\ANALOG.RSB;1",0},	// Analog pad		0
		{"\\RSB\\DWARNING.RSB;1",0},	// Piracy Screen	1
		{"\\RSB\\SONY.RSB;1",0},	// Sony Presents	2
		{"\\RSB\\BACK.RSB;1",0},	// Menu background	3
		{"\\RSB\\TILES.RSB;1",0},	// Tile graphics	4
		{"\\RSB\\MEMSPRT.RSB;1",0},	// Memory card		5
		{"",0}				// Null string to terminate
	};

/*
*
*	NAME		void displayFilePositions(void)
*
*	FUNCTION	displays details on CD file positions from a given array
*
*	NOTES		The array contains a list of files that are expected
*				on the CD. The function checks that all files exist and
*				displays the CDlLoc details for each file. Note that this
*				data could be used in the final game rather than using
*				CDSearchFile() as the data files once burnt onto CD will
*				never change
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
void DisplayFilePositions(void)
{
	int ctr,numFiles=0;

	while(CdFileData[numFiles].filename[0] != '\0')
		numFiles++;

	for(ctr=0; ctr<numFiles; ctr++)
	{
		printf(">> %s .. Name:%s,Size:%u,in sectors:%d\n",CdFileData[ctr].filename,CdFileData[ctr].fileDetails.name,CdFileData[ctr].fileDetails.size,Sectors(CdFileData[ctr].fileDetails.size));
		printf(">> Min:%02x,Sec:%02x,Sector:%02x,Track:%02x\n",CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track);
	}

	return;
}

/*
*
*	NAME		int CacheFilePos(void)
*
*	FUNCTION	Retrieve all file positions for the CdFileData files
*
*	NOTES		Function returns zero if a file is missing, however the
*				function retries RETRY_ATTEMPTS (10) times to get the
*				file list before giving up.
*				This function by default writes a 'pos.h' file containing
*				all the file positions if DEVKIT is defined
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
int CacheFilePos(void)
{
	int ctr=0;					// Loop counter
	int numFiles=0;				// Number of files 
	int retryCount=0;

#ifdef DEVKIT
	int PcfileHandle=0;			// File Handle for pos.h
	char dataLine[80];			// Character string used to write out each line of data
	char fullFile[MAXFILELEN];	// Holds complete file path for writing to pos.h
#endif

//	Calculate number of files required
	while(CdFileData[numFiles].filename[0] != '\0')
		numFiles++;

#ifdef DEBUG
	printf("Total number of files:%d\n",numFiles);
#endif

SearchFileRetry:
//	Search for each file and print out details to debug window if required
	for(ctr=0; ctr<numFiles; ctr++)
	{
		if (CdSearchFile(&CdFileData[ctr].fileDetails,&CdFileData[ctr].filename[0])==0)
		{
			if(retryCount < RETRY_ATTEMPTS)
			{
				retryCount++;
				// argh, a goto !
				goto SearchFileRetry;
			}
			// Tried enough times, lets give up
			#ifdef DEBUG
      			printf(">> %s Not Found after %d attempts .. Aborting\n",CdFileData[ctr].filename,retryCount);
			#endif
			return 0;
		}
	  	else
		{
			#ifdef DEBUG
				printf(">> %s Found .. Name:%s,Size:%u,in sectors:%d\n",CdFileData[ctr].filename,CdFileData[ctr].fileDetails.name,CdFileData[ctr].fileDetails.size,Sectors(CdFileData[ctr].fileDetails.size));
				printf(">> Min:%02x,Sec:%02x,Sector:%02x,Track:%02x\n",CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track);
			#endif
		}
	}

#ifdef DEVKIT
	if(PCInit())
	{
		printf("** Unable to initialise PC file system **\n");
		return 1;
	}
	PcfileHandle = PCcreat("pos.h",0);

	// Write header
	sprintf(dataLine,"FILEDETAILS CdFileData[] =\n\t{\n");
	PCwrite(PcfileHandle,dataLine,strlen(dataLine));

	// Create Records
	for(ctr=0; ctr<numFiles; ctr++)
	{
		// Create filename with '\\' instead of '\' for path separators
		CreateFullFile(CdFileData[ctr].filename,fullFile);
		sprintf(dataLine,"\t\t{\"%s\",0x%x,0x%x,0x%x,0x%x,%u,\"%s\"},\n",fullFile,CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track,CdFileData[ctr].fileDetails.size,CdFileData[ctr].fileDetails.name);
		PCwrite(PcfileHandle,dataLine,strlen(dataLine));
	}

	// Write footer
	sprintf(dataLine,"\t\t{\"\",0}		// Null string to terminate\n\t};\n");
	PCwrite(PcfileHandle,dataLine,strlen(dataLine));
	PCclose(PcfileHandle);
	printf("** pos.h has been created containing CD file locations **\n");
#endif
	return 1;
}

/*
*
*	NAME		void CreateFullFile(char *source, char *dest)
*
*	FUNCTION	Modify input string to add the double slash i.e.
*				\DATA\MYFILE.DAT;1 becomes \\DATA\\MYFILE.DAT;1
*
*	NOTES		Only needs to be used if DEVKIT is defined as it's
*				only use is with writing out 'pos.h'
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
#ifdef DEVKIT
void CreateFullFile(char *source, char *dest)
{

	while((*dest = *source))
	{
		if(*dest == '\\')
		{
			dest++;
			*dest = '\\';
		}

		dest++;
		source++;
	}
	return;
}
#endif

/*
*
*	NAME		void InitCd(void)
*
*	FUNCTION	Initializes the CD subsystem and sets the mode (double
*				speed)
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
void InitCd(void)
{
//  Use CdlModeSize1 if you want to view the sectors going past
//	unsigned char CDmode = (CdlModeSpeed|CdlModeRT|CdlModeSize1);
	unsigned char CDmode = (CdlModeSpeed|CdlModeRT);
	CdInit();

	if(!CdControl(CdlSetmode,&CDmode,0))
		printf("** Failed to set double speed\n");

	#ifdef DEBUG
		debugFileHandle = PCcreat("debug.txt",0);
	#endif

	return;
}

/*
*
*	NAME		void DeInitCd(void)
*
*	FUNCTION	Closes down CD system
*
*	NOTES		Doesn't really, however it is there if needed
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
void DeInitCd(void)
{

#ifdef DEBUG
	PCclose(debugFileHandle);
#endif
	// Not really needed, however StopCallBack must be called somewhere
	// in the close of the system
//	CdControlB(CdlStop, 0, 0);
//	CdFlush();

	return;
}

/*
*
*	NAME		int CdLoadFile(int fileNo, u_long *addr)
*
*	FUNCTION	Loads a file from CD, inputs are the file number
*				and the address to load to. Returns the file size
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
int CdLoadFile(int fileno, u_long *addr)
{
	
	int numBytes     = CdFileData[fileno].fileDetails.size; // File size
	int sectorCnt    = Sectors(CdFileData[fileno].fileDetails.size);
	int oldsectorCnt = sectorCnt;

	int retryCount=0;

	static CdlFILE	fp;
	int n;

#ifdef DEBUG
	printf("reading %s to 0x%08x (%d bytes)\n", CdFileData[fileno].filename, addr, numBytes);
#endif
	
	// First check that the CD lid is shut
	IsCdReady();

LoadFileRetry:
  
	if (CdControl(CdlSetloc, (u_char *)&CdFileData[fileno].fileDetails.pos, 0) == 0)
	{
			if(retryCount < RETRY_ATTEMPTS)
			{
				retryCount++;
				// argh, a goto !
				goto LoadFileRetry;
			}
			// Tried enough times, lets give up
			#ifdef DEBUG
      			printf(">> Unable to seek to %s ..\n",CdFileData[fileno].filename);
			#endif
			return(0);
	}

	if (CdRead((n = (numBytes+2047)/FORM1_SIZE), addr, CdlModeSpeed) == 0)
	{
		if(retryCount < RETRY_ATTEMPTS)
		{
			retryCount++;
			// argh, a goto !
			goto LoadFileRetry;
		}
		// Tried enough times, lets give up
		#ifdef DEBUG
  			printf(">> Unable to load to %s ..\n",CdFileData[fileno].filename);
		#endif
		return(0);
	}

	#ifdef DEBUG
		printf("Total number of sectors:%d\n",sectorCnt);
	#endif

	do
	{
		if(sectorCnt != oldsectorCnt)
		{

			#ifdef DEBUG
		   		printf("*%d*",sectorCnt);
				drawOnVRAM();
			#endif
			if(sectorCnt == -1)
			{
				// read error
				if(retryCount < RETRY_ATTEMPTS)
				{
					retryCount++;
					// argh, a goto !
					goto LoadFileRetry;
				}
				// Tried enough times, lets give up
				#ifdef DEBUG
		  			printf(">> Too many read errors loading %s ..\n",CdFileData[fileno].filename);
				#endif
				return(0);
			}
			else
				oldsectorCnt = sectorCnt;

		}
	}
	while ( (sectorCnt = CdReadSync(1,0)) > 0 );

	CdPause();

	return(numBytes);
}

/*
*
*       NAME            int IsCdReady(void)
*
*	FUNCTION	Checks that the lid is shut before initializing a load.
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
void IsCdReady(void)
{
	int ready  = 0;
	int doorStatus = 1;

	VSync(0);
	CdControl(CdlNop,0,0);
	doorStatus = (CdStatus() & CdlStatShellOpen);
	while(doorStatus)
  	{
			CdControl(CdlNop,0,0);
			doorStatus = (CdStatus() & CdlStatShellOpen);
			#ifdef DEBUG
				printf("Shut the lid\n");
			#endif
	}

	return;
}


/*
*
*	NAME		void drawOnVRAM(void)
*
*	FUNCTION	Test function that just rotates a colour whilst a file
*				is loading
*
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	09/12/97	Mike Kav		Created
*
*/
void drawOnVRAM(void)
{
	RECT theRect;
	static int fade=255;

	setRECT(&theRect,0,0,320,480);
	ClearImage(&theRect,fade,0,0);
	fade-=10;

	DrawSync(0);
}

