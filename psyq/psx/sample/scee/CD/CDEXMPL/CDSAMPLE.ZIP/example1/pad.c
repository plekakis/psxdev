#include <sys/types.h>
#include <libetc.h>
#include "pad.h"

/*
*	NAME		int padButton(void)
*
*	FUNCTION	Checks what button is currently being pressed and
*				returns that value 
*
*	NOTES		Only returns one value, and that being dependant on
*				the order of 'if' statements
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	02/12/97	Mike Kav		Created
*/
int padButton(void)
{
	u_long input = PadRead(1);

	if(input & PADselect) 	return LEFT_SELECT;
	if(input & PADstart)	return LEFT_START;

	if(input & PADLup)		return LEFT_UP;
	if(input & PADLdown)	return LEFT_DOWN;
	if(input & PADLleft)	return LEFT_LEFT;
	if(input & PADLright)	return LEFT_RIGHT;

	if(input & PADRup)		return LEFT_TRIANGLE;
	if(input & PADRdown)	return LEFT_CROSS;
	if(input & PADRleft)	return LEFT_SQUARE;
	if(input & PADRright)	return LEFT_CIRCLE;

	if(input & PADL1)		return LEFT_L1;
	if(input & PADL2)		return LEFT_L2;
	if(input & PADR1)		return LEFT_R1;
	if(input & PADR2)		return LEFT_R2;

	return 0;
}

/*
*	NAME		int padButtonDelay(void)
*
*	FUNCTION	Checks what button is currently being pressed and
*				returns that value if the delay has timed out 
*
*	NOTES		Only returns one value, and that being dependant on
*				the order of 'if' statements
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	02/12/97	Mike Kav		Created
*/
int padButtonDelay()
{
	static int delayValue;
	u_long input = PadRead(1);

	if(!delayValue)
	{
		if(input & PADselect)	{ delayValue = 15; return LEFT_SELECT; }
		if(input & PADstart)	{ delayValue = 15; return LEFT_START; }

		if(input & PADLup)		{ delayValue = 15; return LEFT_UP; }
		if(input & PADLdown)	{ delayValue = 15; return LEFT_DOWN; }
		if(input & PADLleft)	{ delayValue = 15; return LEFT_LEFT; }
		if(input & PADLright)	{ delayValue = 15; return LEFT_RIGHT; }

		if(input & PADRup)		{ delayValue = 15; return LEFT_TRIANGLE; }
		if(input & PADRdown)	{ delayValue = 15; return LEFT_CROSS; }
		if(input & PADRleft)	{ delayValue = 15; return LEFT_SQUARE; }
		if(input & PADRright)	{ delayValue = 15; return LEFT_CIRCLE; }

		if(input & PADL1)		{ delayValue = 15; return LEFT_L1; }
		if(input & PADL2)		{ delayValue = 15; return LEFT_L2; }
		if(input & PADR1)		{ delayValue = 15; return LEFT_R1; }
		if(input & PADR2)		{ delayValue = 15; return LEFT_R2; }
	}
	return 0;
}

/*
*	NAME		int padPressAndRelease(void)
*
*	FUNCTION	Returns 1 if the any button is being pressed at that
*				moment
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	02/12/97	Mike Kav		Created
*/
int padPressAndRelease(void)
{
	static int pressed;

	u_long input = PadRead(1);

	if(!pressed)
	{
		pressed==1;
	if(input & PADselect) 	return LEFT_SELECT;
	if(input & PADstart)	return LEFT_START;

	if(input & PADLup)		return LEFT_UP;
	if(input & PADLdown)	return LEFT_DOWN;
	if(input & PADLleft)	return LEFT_LEFT;
	if(input & PADLright)	return LEFT_RIGHT;

	if(input & PADRup)		return LEFT_TRIANGLE;
	if(input & PADRdown)	return LEFT_CROSS;
	if(input & PADRleft)	return LEFT_SQUARE;
	if(input & PADRright)	return LEFT_CIRCLE;

	if(input & PADL1)		return LEFT_L1;
	if(input & PADL2)		return LEFT_L2;
	if(input & PADR1)		return LEFT_R1;
	if(input & PADR2)		return LEFT_R2;
	}

	// if we get to here then make sure notPressed is set
	if(input==0)
		pressed=0;

	return 0;
}

/*
*	NAME		int padPressed(void)
*
*	FUNCTION	Returns 1 if the any button is being pressed at that
*				moment
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------		----------		------
*	02/12/97	Mike Kav		Created
*/
int padPressed(void)
{
	if(PadRead(1)!=0)
		return 1;
	return 0;
}

