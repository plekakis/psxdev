/*
*	My own standard pad handler, very basic
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/

// Left hand controller
#define LEFT_UP			1
#define LEFT_DOWN		2
#define LEFT_LEFT		3
#define LEFT_RIGHT		4
#define LEFT_SQUARE		5
#define LEFT_TRIANGLE	6
#define LEFT_CIRCLE		7
#define LEFT_CROSS		8
#define LEFT_SELECT		9
#define LEFT_START		10
#define LEFT_L1			11
#define LEFT_L2			12
#define LEFT_R1			13
#define LEFT_R2			14

// function prototypes
int			padButton(void);
int			padButtonDelay(void);
int			padPressAndRelease(void);
int	 		padPressed(void);
