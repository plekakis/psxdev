This example shows the ability to load CD data and recover from both
 CD errors and the opening of the CD.

The function to cache the file positions can be used during development
 however this could be removed along with the file list once the
 development has ended and the files are no longer moving or changing
 size. However to remove the file caching routine may alter the file
 position or size so it is best to only cache the data files
 and put the executable as the last data file on the CD so that it's
 size does not effect any of the data files.