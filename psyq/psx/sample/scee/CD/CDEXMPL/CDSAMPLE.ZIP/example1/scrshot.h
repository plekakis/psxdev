/*
*	Header file for screenshot function, function allows you to
*	grab an area of VRAM and saves it to memory followed by saving
*	to disk
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	03/12/97	Mike Kav	Created
*
*/

//#include <libps.h>
		
void ScreenShot(u_long *dest, int x, int y, int width, int height);
void StoreScreen (void);
