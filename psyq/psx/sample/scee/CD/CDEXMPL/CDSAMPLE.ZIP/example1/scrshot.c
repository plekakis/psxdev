/*	Screenshot grabber utility
*
*	NOTES		
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	03/12/97	Mike Kav	Created
*
*/

#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include "scrshot.h"

/*
*
*	NAME		void ScreenShot(u_long *dest, int x, int y, int width, int height)
*
*	FUNCTION	Grab current image on screen and save in memory and on disk
*				as a .TIM file
*
*	NOTES		The area grabbed is from position x,y and the width and height
*			specified
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	03/12/97	Mike Kav	Created
*
*/
void ScreenShot(u_long *dest, int x, int y, int width, int height)
{

	RECT theRect;
	int PcfileHandle;
	int fileNo=0;
	char filename[14];

	*(dest+0) = 0x00000010;		// ID 
	*(dest+1) = 0x00000002;		// Flag (15bit Direct,No Clut)
	*(dest+2) = (width*height/2+3)*4;		// pixel bnum, data length
											// of CLUT block, in bytes plus
											// the 4 bytes of bnum value
	*(dest+3) = ((0 & 0xffff) << 16) | (640 & 0xffff);
						// pixel DX,DY: at 640, 0 in frame buffer
	*(dest+4) = ((height & 0xffff) << 16) | (width & 0xffff);
						// pixel width and height

	// NO CLUT since 16-bit mode used

	// set up actual grab rectangle from values passed in.
	theRect.x = x; 
	theRect.y = y;
	theRect.w = width; 
	theRect.h = height;

	DrawSync(0);

	// Store all data from rectangle into pixel data buffer
	StoreImage(&theRect, dest+5);		

	printf("Memory buffer %08x %x\n\n\n", dest, (width*height/2+5)*4);

	DrawSync(0);
	VSync(0);

	// Write out .TIM to file
	if(PCInit())
	{
		printf("** Unable to initialise PC file system **\n");
		return;
	}
	
	// First attempt to open file, if it exists then increment file
	// number and repeat
	for(fileNo=0;fileNo<100;fileNo++)
	{
		sprintf(filename,"screen%d.TIM",fileNo);

		if( (PcfileHandle = PCopen(filename,0,0)) == -1 )
		{
			PcfileHandle = PCcreat(filename,0);
			PCwrite(PcfileHandle,dest,(width*height/2+5)*4);
			PCclose(PcfileHandle);
			return;
		}
		else
		{
			// File exists, close it and try again
			printf("File:%s, already exists,trying again\n",filename);
			PCclose(PcfileHandle);	
		}
	}

	printf("Unable to allocate filename for screenshot\n");

	return;
}