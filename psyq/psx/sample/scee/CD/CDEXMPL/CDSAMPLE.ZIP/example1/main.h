/*
*	Cd data reading sample, uses a caching system to remove the
*	need to search for any files after the initialization.
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/

// Just enough to FntPrint to screen
typedef struct {
        u_long          ot;
//        POLY_FT4        background;
//        POLY_FT4        foreground;
//        POLY_FT4        select;
//        POLY_FT4        numbers;
//        POLY_FT4        tiles;
//		POLY_FT4		tileTest[100];
//        POLY_FT4        chars;
        DRAWENV         draw;
        DISPENV         disp;
} DB;