/*
	Header file for cd loading, currently the file details are held
	in this file, however CacheFilePos will write out the file
	positions into a file called 'pos.h' if DEVKIT is defined.
	This can replace the specified files. If we are not using
	'pos.h' then CacheFilePos must be executed at the start of the
	program after InitCdSystem().

*/

#define MAXFILELEN 		50
// Retry attempts for CD access
#define RETRY_ATTEMPTS	10

// Macro definition used to calculate the number of sectors to read
// from a given filesize
#define FORM1_SIZE	2048
#define Sectors(x)	(((x)+FORM1_SIZE-1)/FORM1_SIZE)
#define Words(x)	(((x)+3) / 4)

typedef struct
{
	char filename[MAXFILELEN];
	CdlFILE fileDetails;       	
}FILEDETAILS;

/*
*	The following definitions need to be changed from project to
*	project, or alternatively replaced with a structure just
*	holding the file number and the position to save space
*/
#define ANALOGRS			0
#define WARNINGRS			1
#define SONYRS				2
#define BACKRS				3
#define TILESRS				4
#define MEMORYRS			5

#define ANALOGRSB			6
#define WARNINGRSB			7
#define SONYRSB				8
#define BACKRSB				9
#define TILESRSB			10
#define MEMORYRSB			11

#define ANALOG				12
#define WARNING				13
#define SONY				14
#define BACK				15
#define TILES				16
#define MEMORY				17

void DisplayFilePositions(void);
int CacheFilePos(void);
void PrintFileDetails(void);
void CreateFullFile(char *source, char *dest);
void InitCd(void);
void DeInitCd(void);
int CdLoadFile(int fileno, u_long *addr, u_long *outaddr);
void IsCdReady(void);
void drawOnVRAM(void);
long Decompress( unsigned char *in, unsigned char *out);
void FirstDecomp(u_char *in, u_char *out);
long DecodeSector( unsigned char *inp, unsigned char *out );
