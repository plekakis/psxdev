/*
*	Cd data reading sample, uses a caching system to remove the
*	need to search for any files after the initialization.
*	Uses an RSB compression system to uncompress files after loading
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/

#include <sys/types.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libcd.h>
#include "main.h"

// For handling pad
#include "pad.h"
// loading functions
#include "cd.h"

// Function Prototypes
void main(void);
void LoadTestFiles(void);
void Demo(void);
void CleanUp(void);
void ResetDemo(void);
void VRAM(void);
void displayscreen(u_long* addr);
void initGraph(void);

#define	SCREEN_X		320		
#define	SCREEN_Y		256


// Buffers for test program
unsigned char analogbuf[ 131092 ];
unsigned char backbuf[ 131092 ];
unsigned char warningbuf[ 163860 ];
unsigned char memsprtbuf[ 131092 ];
unsigned char sonybuf[ 163860 ];
unsigned char tilebuf[ 131092 ];

unsigned char testanalogbuf[ 131092 ];
unsigned char testbackbuf[ 131092 ];
unsigned char testwarningbuf[ 163860 ];
unsigned char testmemsprtbuf[ 131092 ];
unsigned char testsonybuf[ 163860 ];
unsigned char testtilebuf[ 131092 ];

unsigned char finalbuf[ 163860 ];

int currentBuffer;

extern int _ramsize;
extern int _stacksize;
extern int __heapbase;
extern int __heapsize;

void main(void)
{
	int buttonValue=0;	// Value returned from pad

	PadInit(0);
	InitCd();
	

	printf("RamSize:%u...\n",_ramsize);
	printf("StackSize:%u...\n",_stacksize);
	printf("HeapBase:%u...\n",__heapbase);
	printf("HeapSize:%u...\n",__heapsize);

// Load up .TIM's for comparison later
	LoadTestFiles();

	if(!CacheFilePos())
	{
		printf("Failed To Find All Files\n");
		return;
	}

	initGraph();
	printf("Initialised Graphics System\n");
	printf("Press X to run demo\nCircle to display file positions\n");
	printf("Square to view VRAM\n");
	while((buttonValue = padButton()) != LEFT_SELECT)
	{
		switch(buttonValue)
		{
			case LEFT_CROSS:
			{	
					Demo();
					break;
			}
			case LEFT_CIRCLE:
			{
					displayFilePositions();
					break;
			}
			case LEFT_SQUARE:
			{
				VRAM();
				buttonValue = 0;
				break;
			}
			case LEFT_TRIANGLE:
			{
				buttonValue = 0;
				break;
			}
		}

	}

	ResetGraph(1);
	StopCallback();
    return;
}

/*
*
*	NAME		void Demo(void)
*
*	FUNCTION	loads files from CD
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void Demo(void)
{
	int i;
	int startTime;
	int readbytes;

	printf("Enter Demo\n");

	printf("\n** Loading Analog Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(ANALOGRSB,(u_long *)testanalogbuf,(u_long *)finalbuf);
//	Decompress(testanalogbuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testanalogbuf,analogbuf,131092 ) );
	printf( ", Original Data at %X",testanalogbuf );
	printf( ", Reference data at %X\n",analogbuf );
        displayscreen((unsigned long*)finalbuf);

	printf("\n** Loading Piracy Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(WARNINGRSB,(unsigned long*)testwarningbuf,(u_long *)finalbuf);
//	Decompress(testwarningbuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testwarningbuf,warningbuf,163860 ) );
	printf( ", Original Data at %X",testwarningbuf );
	printf( ", Reference data at %X\n",warningbuf );
	displayscreen((unsigned long*)finalbuf);

	printf("\n** Loading Sony Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(SONYRSB,(unsigned long*)testsonybuf,(u_long *)finalbuf);
//	Decompress(testsonybuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testsonybuf,sonybuf,10 ) );
	printf( ", Original Data at %X",testsonybuf );
	printf( ", Reference data at %X\n",sonybuf );
        displayscreen((unsigned long*)finalbuf);
									
	printf("\n** Loading Analog Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(ANALOGRSB,(unsigned long*)testanalogbuf,(u_long *)finalbuf);
//	Decompress(testanalogbuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testanalogbuf,analogbuf,131092 ) );
	printf( ", Original Data at %X",testanalogbuf );
	printf( ", Reference data at %X\n",analogbuf );
        displayscreen((unsigned long*)finalbuf);

	printf("\n** Loading Backdrop Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(BACKRSB,(unsigned long*)testbackbuf,(u_long *)finalbuf);
//	Decompress(testbackbuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testbackbuf,backbuf,131092 ) );
	printf( ", Original Data at %X",testbackbuf );
	printf( ", Reference data at %X\n",backbuf );
        displayscreen((unsigned long*)finalbuf);

	printf("\n** Loading Tiles Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(TILESRSB,(unsigned long*)testtilebuf,(u_long *)finalbuf);
//	Decompress(testtilebuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testtilebuf,tilebuf,131092 ) );
	printf( ", Original Data at %X",testtilebuf );
	printf( ", Reference data at %X\n",tilebuf );
        displayscreen((unsigned long*)finalbuf);

	printf("\n** Loading Memory Card Screen");
	startTime=VSync(-1);
	readbytes = CdLoadFile(MEMORYRSB,(unsigned long*)testmemsprtbuf,(u_long *)finalbuf);
//	Decompress(testmemsprtbuf,finalbuf,readbytes);
	printf("\n***** Load Time:%d,bytes read:%d *****",VSync(-1)-startTime,readbytes);
	printf( "\nCompare %d",memcmp( testmemsprtbuf,memsprtbuf,131092 ) );
	printf( "\nCompare %d",memcmp( testmemsprtbuf,finalbuf,131092 ) );
	printf( ", Original Data at %X",testmemsprtbuf );
 	printf( ", Reference data at %X\n",memsprtbuf );
        displayscreen((unsigned long*)finalbuf);
  
	return;
}

/*
*
*	NAME		void CleanUp(void)
*
*	FUNCTION	Removes CD system etc ..
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void CleanUp(void)
{
	// Clear up cd system
	DeInitCd();
	StopCallback();      /* Stop the CD callbacks. */
	ResetGraph(3);       /* GPU warm reset */
	
	return;
}

/*
*
*	NAME		void initGraph(void)
*
*	FUNCTION	Uses Gs to initialize graphics
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void initGraph(void)
{

	FntLoad(960,256);
	FntOpen(-96,-96,192,192,0,512);

	SetVideoMode(MODE_PAL);
	GsInitGraph(SCREEN_X, SCREEN_Y,GsINTER|GsOFSGPU,1,0);
	GsDefDispBuff(0,0,0,SCREEN_Y);
	SetBackColor(128, 128, 128);	

}


/*
*
*	NAME		void displayscreen(u_long *addr)
*
*	FUNCTION	Displays 16-bit .TIM on screen
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void displayscreen(u_long *addr)
{
	// 5 seconds worth
	int timer=5*60;
//	int timer=5;
	GsIMAGE theImage;
	RECT r={0,0,320,256};	

	// Get TIM image details

	GsGetTimInfo(++addr,&theImage);
	printf("Image Data-Pixel Mode:%d,width:%d,height:%d\n",theImage.pmode,theImage.pw,theImage.ph);
	
	r.w = theImage.pw;
	r.h = theImage.ph;

	SetDispMask(1);

		// Quick way of displaying 16 bit TIM on screen
	while(timer>0)
	{
		currentBuffer=GsGetActiveBuff();
		LoadImage(&r,theImage.pixel);		
		DrawSync(0);
		VSync(0);
		timer--;
	}	  

	return;
}

/*
*
*	NAME		void VRAM(void)
*
*	FUNCTION	Have a look round VRAM
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void VRAM(void)
{
	RECT	vram;
	DISPENV	disp;
	u_long	padd;

	while (((padd = PadRead(1))&PADk) == 0) {
		
		if (padd & PADl)	disp.screen.w -= 2;
		if (padd & PADm)	disp.screen.w += 2;
		if (padd & PADn)	disp.screen.h -= 2;
		if (padd & PADo)	disp.screen.h += 2;
		
		if (padd & PADLleft)	disp.disp.x -= 2;
		if (padd & PADLright)	disp.disp.x += 2;
		if (padd & PADLup)	disp.disp.y -= 2;
		if (padd & PADLdown)	disp.disp.y += 2;
		
		if (padd & PADRleft)	disp.screen.x -= 2;
		if (padd & PADRright)	disp.screen.x += 2;
		if (padd & PADRup)	disp.screen.y -= 2;
		if (padd & PADRdown)	disp.screen.y += 2;

		/* Clear VRAM if start pressed. */
		if (padd & PADstart) {
		    setRECT(&vram, 0, 0, 1023, 511);
		    ClearImage(&vram, 0, 0, 40);
		}
		
		VSync(0);
		GsSwapDispBuff();
	}
}

/*
*
*	NAME		void LoadTestFiles(void)
*
*	FUNCTION	Loads files to compare against my loading code
*
*	NOTES		
*
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	11/12/97	Mike Kav		Created
*
*/
void LoadTestFiles(void)
{

	int temp;
	int readbytes;

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\BACK.RSB;1",(u_long *)backbuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\ANALOG.RSB;1",(u_long *)analogbuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\DWARNING.RSB;1",(u_long *)warningbuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\MEMSPRT.RSB;1",(u_long *)memsprtbuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\TILES.RSB;1",(u_long *)tilebuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	temp=VSync(-1);
	readbytes = CdReadFile( "\\RSB\\SONY.RSB;1",(u_long *)sonybuf,0 );
	CdReadSync( 0,0 );
	printf("***** Load Time:%d,bytes read:%d *****\n",VSync(-1)-temp,readbytes);

	return;

}

