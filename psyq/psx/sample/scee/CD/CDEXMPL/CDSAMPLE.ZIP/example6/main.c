/*	Test shell for CD code
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/98	Mike Kav		Created
*
*/
#include <r3000.h>
#include <asm.h>
#include <kernel.h>
#include <sys/file.h>
#include <sys/types.h>
#include <libgte.h>
#include <libgpu.h>
#include <libgs.h>
#include <libetc.h>
#include <libsn.h>
#include <libsnd.h>

#include "cd.h"

//#define FILENAME "\\TEST.TXT"
#define FILENAME "\\QUOTES.DAT"

void main(void);
void Test_Normal_file(void);
void Test_Sector_Read(void);
void Test_GetString(void);

/*
*
*	NAME		void main(void)
*
*	FUNCTION	Tests CD code, first test uses openFile and
*				readFile which read a set number of sectors
*				from the file into an area of memory
*
*				the second test uses fopen and getc, which opens
*				and fills out a file structure, this structure
*				contains a 2048 byte buffer which is filled
*				with data from the file as needed.
*
*				the third test uses gets to get a string of data
*				from the file using the same technique as test
*				two
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
void main(void)
{
	ResetCallback();
	printf("***** Cd Test *****\n");
	CdInit();
	ResetGraph(0);

	Test_Normal_file();

	Test_Sector_Read(); // getc test

	Test_GetString(); // gets test

	printf("\n** End of Test **\n");

	return;
}

void Test_Sector_Read(void)
{
	char i;
	FILE newFile;

	fopen(&newFile,FILENAME);

	printf("** Sector Read File Details:%s,%u **\n",newFile.Cdfile.name,newFile.Cdfile.size);
	printf("** min %d sec %d sector %d **\n",newFile.Cdfile.pos.minute,newFile.Cdfile.pos.second,newFile.Cdfile.pos.sector);
	printf("** Starting getc test **\n");

	// Read to the end of the file, denoted by receiving a '#' character
	do
	{
		i = fgetc(&newFile);
		if(i != '#')
			printf("%c",i);

	} while(i != '#');

	return;
}
        
void Test_Normal_file(void)
{

	int		retVal;
	char	tempAddr[6144];
	int i;
	FILE newFile;

	printf("\n** Test Normal File - Start **\n");
	retVal = openFile(&newFile,FILENAME);
	
	if(retVal)
	{
		printf("\n** File Details:%s,%u **\n",newFile.Cdfile.name,newFile.Cdfile.size);
		printf("** min %d sec %d sector %d **\n",newFile.Cdfile.pos.minute,newFile.Cdfile.pos.second,newFile.Cdfile.pos.sector);
	}

	// Read three sectors from disk
	retVal = readFile(&newFile,&tempAddr,3);

	for(i=0;i<117;i++)
		printf("%c",tempAddr[i]);
	
	printf("\n** Normal File Function Complete **\n\n");
	return;
}
                                         
void Test_GetString(void)
{

	char i,j,k;
	FILE newFile;
	char aString[244];		// Longest string in file is 243 characters

	fopen(&newFile,FILENAME);

	printf("** GetString File Details:%s,%u **\n",newFile.Cdfile.name,newFile.Cdfile.size);
	printf("** min %d sec %d sector %d **\n",newFile.Cdfile.pos.minute,newFile.Cdfile.pos.second,newFile.Cdfile.pos.sector);
	printf("** Starting getc test **\n");

	// print first 5 lines
	for(i=0;i<5;i++)
	{
		for(k=0;k<245;k++)
			aString[k]='\0';
   		j = fgets(aString, 244, &newFile);
		printf("fgets:%s",aString);
	}
	return;
}
