#include <kernel.h>
#include <sys/types.h>
#include <libcd.h>

#define SUCCESS 1
#define FAILURE 0
#define EOF '#'		// Character to send when EOF has been reached


#define _F_EOF 0x0001
#define _F_NEWFILE 0x0002
#define FORM1_SIZE  2048 /* Size of an XA mode 1 form 1 sector. */
#define SECTORS(x)  ((x+FORM1_SIZE-1)/FORM1_SIZE)
#define success int
#define DEBUG_STRING printf

typedef struct
{
	short		flags;				// Flags - e.g. EOF
	u_long		pos;				// Position in the file we are up to
	int			num_sectors;		// Number of sectors the file takes up on the CD
	char		sectorbuf [2048];	// Buffer CD data is read into - allow for up
									//	to 2048 bytes, i.e. 1 sector
	CdlFILE		Cdfile;  
} FILE;


int openFile (FILE *newFile, char *fn);
int readFile (FILE *fp, void *addr, u_long numSectors);
int fopen (FILE *file,char *filename);
char fgetc (FILE *f);
int fgets (char *buf, int n, FILE *stream);
void IsCdReady(void);
int ReadNextSector (int offset, FILE *fp);