This example shows the ability to load CD data in two distinct ways

1) Specifying a file and the number of sectors worth of data to load
2) Specifying a file and reading data on a per sector basis as needed

The example code also has three functions emulating the PC style, fopen,
 fgets, and fgetc. Both fgetc and fgets read in a sectors worth of data
 until more is needed and then another sector is loaded. This means
 that the size of the buffer that data is being loaded into is only 2k

Thanks to Mike Kennedy (Oxford Softworks) for the original problem,
and the original source