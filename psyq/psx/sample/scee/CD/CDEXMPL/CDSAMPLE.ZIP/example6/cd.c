/*	File handling code for opening files and reading data from them in 2048
*	chunks.
*
*	NOTES		openFile() followed by readFile to read a set number
*				of sectors to the address specified
*
*				fopen to get all file details followed by either readFile or
*				fgetc to get required data from file.
*
*				Currently the symbol '#' is used to denote the end of a file,
*					this can be replaced with a symbol of your choice
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/98	Mike Kav		Created
*
*/

#include "cd.h"

/*
*
*	NAME		int openFile (FILE *newFile, char *fn)
*
*	FUNCTION	Fills out a FILE structure with all the information required
*				to read from the file using readFile or fgetc
*				Function returns 1 to indicate success
*
*	NOTES		Function currently will not exit until the file is found.
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
int openFile (FILE *newFile, char *fn)
{
        int  retrys = 10;
        char realfn [80];
        sprintf (realfn, "\\%s;1", fn);     // make absolute path, and add ISO version

		// Check CD lid is not open
		IsCdReady();
gRetry:
        if (!CdSearchFile(&(newFile->Cdfile), realfn))
        {
                printf("Error Finding %s, retry count:%d..\n",realfn,retrys);
                if (--retrys != 0)
                        goto gRetry;

                printf("I'm not leaving till I find this file!\n");
                retrys = 10;
                goto gRetry;
        }

        newFile->flags  = 0;
        newFile->pos    = 0;       // Start of file
        newFile->num_sectors = SECTORS(newFile->Cdfile.size);

        return (1);
}

/*
*
*	NAME		int readFile (FILE *fp, void *addr, u_long numSectors)
*
*	FUNCTION	Reads 'numSectors' worth of data into memory address
*				'addr'
*
*	NOTES		Function currently does not return if seek fails
*				constantly
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
int readFile (FILE *filePtr, void *addr, u_long numSectors)
{
    int result;

    // Call Cd control (blocking) to seek to the logical file position.
	// Could use an if or a retry limit here and return a fail if necessary
    while (!CdControlB(CdlSeekL,(unsigned char *)&(filePtr->Cdfile.pos), 0))
    {
      printf("CdlSeekL failed\n");
    }

    // Call CdRead() to read the sectors into the buffer at double speed.
    // If the CD doesn't respond, then return 0.
    if(!CdRead (numSectors, (unsigned long *)addr, CdlModeSpeed))
    {
      printf("CdRead failed\n");
      return (0);
    }

    // Block until the CD has finished reading
    do
    {
		result = CdReadSync(1,0);
		if (result < 0)       // error
		{
        	return (0);
		}
	}while (result != 0);

    return (1);
}

/*
*
*	NAME		int fopen (FILE *file,char *filename)
*
*	FUNCTION	Fills out FILE data structure with details on filename
*				passed in. Return 1 to indicate success
*
*	NOTES		Due to the fact that openFile will not return until it
*				succeeds at the moment this function also will not
*				return 0
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
int fopen (FILE *file,char *filename)
{
    if (openFile (file, filename) == 0)
	{
      return (0);
	}

	// Set flag to indicate this file has just been opened, so we can
	// reset the file pointer to the start of the file
	file->flags |= _F_NEWFILE;

	return 1;
}

/*
*
*	NAME		int ReadNextSector (int offset,CdlLOC tempLoc, FILE *filePtr)
*
*	FUNCTION	Reads a sector of data specified by the file and offset into
*				the sector buffer in the FILE structure
*
*	NOTES		Don't need the offset but calculating this would limit the
*				loading code to only loading in sequence
*					filePtr->pos/FORM1_SIZE
*				Using CdlSetloc does not seek to that position, this will be
*				done by CDRead or CdReadN ..
*				Use CdlSeekL if you want the CD to seek and pause before the
*				CdRead call
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
int ReadNextSector (int offset, FILE *filePtr)
{
    int result;
	CdlLOC tempLoc;

    CdIntToPos(CdPosToInt(&(filePtr->Cdfile.pos))+offset, &tempLoc);
	printf("\n** Reading: min %d sec %d sector %d **\n",tempLoc.minute,tempLoc.second,tempLoc.sector); 

    while (CdControlB(CdlSetloc, (u_char *)&tempLoc, 0) == 0)
    {
            printf("NextSector Seek Error\n");
    }

	if (CdRead(1, (u_long *)(filePtr->sectorbuf), CdlModeSpeed) == 0)
    {
            printf("CdRead Command Error\n");
            return(0);
    }

	do
	{
		result = CdReadSync(1,0);
		if (result < 0)       // error?
		{
			printf("\nData Read Error\n");
			return (0);
		}
	} while (result != 0);

	return(1);
}

/*
*
*	NAME		char fgetc (FILE *f)
*
*	FUNCTION	Gets the next character from a file stream
*
*	NOTES		Uses a 2k sector buffer held in the FILE structure
*				
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	14/01/97	Mike Kav		Created
*
*/
char fgetc (FILE *filePtr)
{
	char byte = '@';
	static int current_byte;
	static int offset;

	// check if file has just been opened, set byte value to 2k to force a sector
	// load and set sector offset to the first sector in a file
	if (filePtr->flags & _F_NEWFILE)
	{
		current_byte = 2048;
		offset = 0;
		filePtr->flags = 0;
	}

	// Check if at end of file, should never happen
	if (filePtr->flags & _F_EOF)
	{
		printf("End of file");
		return (EOF);
	}

	// If our character position in the file is less than the overall file size
	if ((filePtr->pos) < (filePtr->Cdfile.size))
	{
		if(current_byte == 2048)		
		{      		
			ReadNextSector(offset,filePtr);
			current_byte = 0;
			offset++;
		}

		byte = filePtr->sectorbuf[current_byte++];
		filePtr->pos++;					// Move the file pointer along
		return byte;					// And return the info
	}

	// If we are here then we are at end of file so set up flags and return
	// end of file character
	filePtr->flags |= _F_EOF;
		return (EOF);
}

/*
*
*	NAME		int fgets (char *buf, size_t n, FILE *stream)
*
*	FUNCTION	Gets a string from the file either up to 'n' characters
*				or up to the first '\n' character
*
*	NOTES		Uses a 2k sector buffer held in the FILE structure
*				
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/01/97	Mike Kav		Created
*
*/
int fgets (char *buf, int n, FILE *stream)
{
  int  index      = 0;
  char byte      = 0;
  int  n_elements = n - 1;

  while ( (n_elements-- >= 0) && (byte != EOF) )
  {
    byte = (char) fgetc (stream);

    if (byte == EOF)
      return NULL;

    buf[index++] = byte;

    if (byte == '\n')
      break;
  }

  if ( n_elements == (n - 1) )
    return NULL;
  else
    return 1;
}

/*
*
*	NAME		void IsCdReady(void)
*
*	FUNCTION	Checks that the lid is shut, does not return
*				until it is
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	02/12/97	Mike Kav		Created
*
*/
void IsCdReady(void)
{
        int doorStatus = 1;

        VSync(0);
        CdControl(CdlNop,0,0);
        doorStatus = (CdStatus() & CdlStatShellOpen);
        while(doorStatus)
        {
                CdControl(CdlNop,0,0);
                doorStatus = (CdStatus() & CdlStatShellOpen);
                printf("Shut the lid\n");
        }

        return;
}

