#include <stddef.h>
#include <limits.h>
#include <assert.h>
#include "clock.h"

//------------------------------------------------------------------------

void SetTime(JClock *c, int time)
{
#ifdef NTSC
	c->Ticks = time*60/100;
	c->d     = 0;
#else
	c->Ticks = time*50/100;
	c->d     = 0;
#endif
	c->Time[0] = time/60000;
	time -= c->Time[0]*60000;
	c->Time[1] = time/6000;
	time -= c->Time[1]*6000;
	c->Time[3] = time/1000;
	time -= c->Time[3]*1000;
	c->Time[4] = time/100;
	time -= c->Time[4]*100;
	c->Time[6] = time/10;
	time -= c->Time[6]*10;
	c->Time[7] = time;

	c->Time[0]+=0x30;
	c->Time[1]+=0x30;
	c->Time[2] =':';
	c->Time[3]+=0x30;
	c->Time[4]+=0x30;
	c->Time[5] =':';
	c->Time[6]+=0x30;
	c->Time[7]+=0x30;
	c->Time[8] ='\0';
}

//------------------------------------------------------------------------

int GetTime(JClock *c)
{
	int m,s,h;

	m = atoi(&c->Time[0]);
	s = atoi(&c->Time[3]);
	h = atoi(&c->Time[6]);
	return(m*60000+s*100+h);
}

//------------------------------------------------------------------------

void ClearTime(JClock *c)
{
	c->Ticks = 0;
	c->d = 0;

	c->Time[0]=0x30;
	c->Time[1]=0x30;
	c->Time[2]=':';
	c->Time[3]=0x30;
	c->Time[4]=0x30;
	c->Time[5]=':';
	c->Time[6]=0x30;
	c->Time[7]=0x30;
	c->Time[8]='\0';
}

//------------------------------------------------------------------------
void CopyTime(JClock *c, JClock *t)
{
	strncpy(&c->Time,&t->Time,10);
	c->d = t->d;
	c->Ticks = t->Ticks;
}

//------------------------------------------------------------------------
void AddTime(JClock *c, JClock *t)
{
	int i;
	int carry;

	/* Add ticks */
	c->Ticks += t->Ticks;

	/* Add strings */
	c->Time[7] += t->Time[7]-0x30;
	carry = c->Time[7]>0x39?1:0;
	if(carry) c->Time[7]-=10;
	c->Time[6] += t->Time[6]-0x30+carry;
	carry = c->Time[6]>0x39?1:0;
	if(carry) c->Time[6]-=10;

	c->Time[4] += t->Time[4]-0x30+carry;
	carry = c->Time[4]>0x39?1:0;
	if(carry) c->Time[4]-=10;
	c->Time[3] += t->Time[3]-0x30+carry;
	carry = c->Time[3]>0x35?1:0;
	if(carry) c->Time[3]-=6;

	c->Time[1] += t->Time[1]-0x30+carry;
	carry = c->Time[1]>0x39?1:0;
	if(carry) c->Time[1]-=10;
	c->Time[0] += t->Time[0]-0x30+carry;
}

//------------------------------------------------------------------------

int IncreaseTime(JClock *c)
{
	int add;
	int i;

	/* Increase time by 1 tick */
	c->Ticks++;

	/* Increase time by 1/60 of a second */
#ifdef NTSC
	c->d+=40;
	add=1;
	if(c->d>=60) c->d-=60,add++;
#else
	add=2;
#endif
	c->Time[7]+=add;

	/* Carry */
	if(c->Time[7]>0x39)
	{
		c->Time[7]-=10;
		c->Time[6]++;
	}
	if(c->Time[6]>0x39)
	{
		c->Time[6]-=10;
		c->Time[4]++;
	}
	if(c->Time[4]>0x39)
	{
		c->Time[4]-=10;
		c->Time[3]++;
	}
	if(c->Time[3]>0x35)
	{
		c->Time[3]-=6;
		c->Time[1]++;
	}
	if(c->Time[1]>0x39)
	{
		c->Time[1]-=10;
		c->Time[0]++;
	}
	return(0);
}

//------------------------------------------------------------------------

int DecreaseTime(JClock *c)
{
	int sub;
	int i;

	/* Decrease time by 1 tick */
	c->Ticks--;

	/* Decrease time by 1/60 of a second */
#ifdef NTSC
	c->d-=40;
	sub=1;
	if(c->d<0) c->d+=60,sub++;
#else
	sub=2;
#endif
	c->Time[7]-=sub;

	/* Carry */
	if(c->Time[7]<0x30)
	{
		c->Time[7]+=10;
		c->Time[6]--;
	}
	if(c->Time[6]<0x30)
	{
		c->Time[6]+=10;
		c->Time[4]--;
	}
	if(c->Time[4]<0x30)
	{
		c->Time[4]+=10;
		c->Time[3]--;
	}
	if(c->Time[3]<0x30)
	{
		c->Time[3]+=6;
		c->Time[1]--;
	}
	if(c->Time[1]<0x30)
	{
		c->Time[1]+=10;
		c->Time[0]--;
	}
	if(c->Time[0]<0x30)
	{
		c->Ticks = 0;
		c->d = 0;
		c->Time[0]=0x30;
		c->Time[1]=0x30;
		c->Time[3]=0x30;
		c->Time[4]=0x30;
		c->Time[6]=0x30;
		c->Time[7]=0x30;
		return(1);
	}
	return(0);
}


