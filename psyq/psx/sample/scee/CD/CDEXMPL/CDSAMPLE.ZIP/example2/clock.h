#ifndef CLOCK_H
#define CLOCK_H

//------------------------------------------------------------------------

typedef struct
{
	char	Time[10];
	unsigned short d;
	int	Ticks;
} JClock;

//------------------------------------------------------------------------

#define TIME(m,s,h) ((m)*6000+(s)*100+(h))

//------------------------------------------------------------------------

void SetTime(JClock *c, int time);
int GetTime(JClock *c);
void ClearTime(JClock *c);
void CopyTime(JClock *c, JClock *t);
void AddTime(JClock *c, JClock *t);
int IncreaseTime(JClock *c);
int DecreaseTime(JClock *c);

#endif
