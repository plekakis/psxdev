/* CD code to load data files from CD.
*
*	NOTES		DEBUG can be defined to allow the printing of messages
*				to the debug window
*				DEVKIT can be defined to allow the writing of 'pos.h'
*				containing the file positions that could be used instead
*				of CdSearchFile in the end build
*				TRACKER can be defined to write out a file onto PC
*				showing the order that the files are accessed, TRACKER
*				requires DEBUG to be set too at the moment
*
*                               you can attach your graphic routine to the loading
*                               code, an example routine DrawOnVRAM just cycles through
*                               red whilst loading a file
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav	Created
*
*/

//#define DEBUG
#define DEVKIT
//#define TRACKER

#include <sys/types.h>
#include <kernel.h>
#include <libetc.h>
#include <libgte.h>
#include <libgpu.h>
#include <libcd.h>
#include "cd.h"

// Set up variables for writing debug.txt out during execution
#ifdef DEBUG
	char	gDebugLine[80];
	int		debugFileHandle=0;
	#define WRITEDEBUGLINE PCwrite(debugFileHandle,gDebugLine,strlen(gDebugLine));
#endif

#ifdef TRACKER
	char gTrackerLine[80];
	int trackerFileHandle=0;
	#define WRITETRACKERLINE PCwrite(trackerFileHandle,gTrackerLine,strlen(gTrackerLine));
#endif

FILEDETAILS CdFileData[] = 
{
	{"\\TIM\\ANALOG.TIM;1",0},	// Analog pad		0
	{"\\TIM\\DWARNING.TIM;1",0},	// Piracy Screen	1
	{"\\TIM\\SONY.TIM;1",0},	// Sony Presents	2
	{"\\TIM\\BACK.TIM;1",0},	// Menu background	3
	{"\\TIM\\TILES.TIM;1",0},	// Tile graphics	4
	{"\\TIM\\MEMSPRT.TIM;1",0},	// Memory card		5
	{"",0}					// Null string to terminate
};

// Global variables

// Used to check if door is open or shut, CdStatus() only returns a byte of info
unsigned char gDoorStatus = 0;
// Current file we are loading
int gCurrentFile;
// Number of sectors file contains
int gSectors;
// Initial address passed in, needs to be global due to use in ReInit, should never be modified
unsigned char* gInitialAddr;
// address for next sector of data to be put into
unsigned char* constructAddr;
// Number of sectors read in
int readSectors;

// Number of sectors we have currently read from sector buffer to main memory
int gDecodedSectors;
// Disk Mode, either compressed or uncompressed
unsigned char gDiskMode = 0;
// reset request, used to indicate that the Cd has encountered a disk error
//and the file needs to be reloaded from the start
unsigned char resetRequest = 0;

// Returns total amount of bytes read in, can be used to compare against
// expected size as this value is returned by CdLoadFile()
unsigned long totalFileSize;

/*
*
*	NAME		void displayFilePositions(void)
*
*	FUNCTION	displays details on CD file positions from a given array
*
*	NOTES		The array contains a list of files that are expected
*				on the CD. The function checks that all files exist and
*				displays the CDlLoc details for each file. Note that this
*				data could be used in the final game rather than using
*				CDSearchFile() as the data files once burnt onto CD will
*				never change
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*/
void DisplayFilePositions(void)
{
	int ctr,numFiles=0;

	while(CdFileData[numFiles].filename[0] != '\0')
		numFiles++;

	for(ctr=0; ctr<numFiles; ctr++)
	{
		printf(">> %s .. Name:%s,Size%u,in sectors:%d\n",CdFileData[ctr].filename,CdFileData[ctr].fileDetails.name,CdFileData[ctr].fileDetails.size,Sectors(CdFileData[ctr].fileDetails.size));
		printf(">> Min:%02x,Sec:%02x,Sector:%02x,Track:%02x\n",CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track);
	}

	return;
}

/*
*
*	NAME		int CacheFilePos(void)
*
*	FUNCTION	Retrieve all file positions for the CdFileData files
*
*	NOTES		Function returns zero if a file is missing, however the
*				function retries RETRY_ATTEMPTS (10) times to get the
*				file list before giving up.
*				This function by default writes a 'pos.h' file containing
*				all the file positions if DEVKIT is defined
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*/
int CacheFilePos(void)
{
	int ctr=0;					// Loop counter
	int numFiles=0;				// Number of files 
	int retryCount=0;

#ifdef DEVKIT
	int PcfileHandle=0;			// File Handle for pos.h
	char dataLine[80];			// Character string used to write out each line of data
	char fullFile[MAXFILELEN];	// Holds complete file path for writing to pos.h
#endif

//	Calculate number of files required
	while(CdFileData[numFiles].filename[0] != '\0')
		numFiles++;

#ifdef DEBUG
	printf("Total number of files:%d\n",numFiles);
#endif

SearchFileRetry:
//	Search for each file and print out details to debug window if required
	for(ctr=0; ctr<numFiles; ctr++)
	{
		if (CdSearchFile(&CdFileData[ctr].fileDetails,&CdFileData[ctr].filename[0])==0)
		{
			if(retryCount < RETRY_ATTEMPTS)
			{
				retryCount++;
				// argh, a goto !
				goto SearchFileRetry;
			}
			// Tried enough times, lets give up
			#ifdef DEBUG
      			printf(">> %s Not Found after %d attempts .. Aborting\n",CdFileData[ctr].filename,retryCount);
			#endif
			return 0;
		}
	  	else
		{
			#ifdef DEBUG
				printf(">> %s Found .. Name:%s,Size%u,in sectors:%d\n",CdFileData[ctr].filename,CdFileData[ctr].fileDetails.name,CdFileData[ctr].fileDetails.size,Sectors(CdFileData[ctr].fileDetails.size));
				printf(">> Min:%02x,Sec:%02x,Sector:%02x,Track:%02x\n",CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track);
			#endif
		}
	}

#ifdef DEVKIT
	PcfileHandle = PCcreat("pos.h",0);

	// Write header
	sprintf(dataLine,"FILEDETAILS CdFileData[] =\n\t{\n");
	PCwrite(PcfileHandle,dataLine,strlen(dataLine));

	// Create Records
	for(ctr=0; ctr<numFiles; ctr++)
	{
		// Create filename with '\\' instead of '\' for path separators
		CreateFullFile(CdFileData[ctr].filename,fullFile);
		sprintf(dataLine,"\t\t{\"%s\",0x%x,0x%x,0x%x,0x%x,%u,\"%s\"},\n",fullFile,CdFileData[ctr].fileDetails.pos.minute,CdFileData[ctr].fileDetails.pos.second,CdFileData[ctr].fileDetails.pos.sector,CdFileData[ctr].fileDetails.pos.track,CdFileData[ctr].fileDetails.size,CdFileData[ctr].fileDetails.name);
		PCwrite(PcfileHandle,dataLine,strlen(dataLine));
	}

	// Write footer
	sprintf(dataLine,"\t\t{\"\",0}		// Null string to terminate\n\t};\n");
	PCwrite(PcfileHandle,dataLine,strlen(dataLine));
	PCclose(PcfileHandle);
	printf("** pos.h has been created containing CD file locations **\n\n");
#endif

	return 1;
}

/*
*
*	NAME		void CreateFullFile(char *source, char *dest)
*
*	FUNCTION	Modify input string to add the double slash i.e.
*				\DATA\MYFILE.DAT;1 becomes \\DATA\\MYFILE.DAT;1
*
*	NOTES		Only needs to be used if DEVKIT is defined as it's
*				only use is with writing out 'pos.h'
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*/
#ifdef DEVKIT
void CreateFullFile(char *source, char *dest)
{

	while((*dest = *source))
	{
		if(*dest == '\\')
		{
			dest++;
			*dest = '\\';
		}

		dest++;
		source++;
	}
	return;
}
#endif

/*
*
*	NAME		void InitCd(void)
*
*	FUNCTION	Initializes the CD subsystem and sets the mode (double
*				speed)
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*
*/
void InitCd(void)
{
	unsigned char CDmode = (CdlModeSpeed|CdlModeRT);

	CdInit();

	if(!CdControl(CdlSetmode,&CDmode,0))
		printf("** Failed to set double speed\n");

	#ifdef DEBUG
	if(PCInit())
	{
		printf("** Unable to initialise PC file system **\n");
		return;
	}

	debugFileHandle = PCcreat("debug.txt",0);
	#endif

	#ifdef TRACKER
		trackerFileHandle = PCcreat("tracker.txt",0);
	#endif

	return;
}

/*
*
*	NAME		void DeInitCd(void)
*
*	FUNCTION	Closes down CD system
*
*	NOTES		Doesn't really, however it is there if needed
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*/
void DeInitCd(void)
{

#ifdef DEBUG
	PCclose(debugFileHandle);
#endif

#ifdef TRACKER
	PCclose(trackerFileHandle);
#endif

// Not really needed, however StopCallBack must be called somewhere
// to close the CD system
//	CdControlB(CdlStop, 0, 0);
//	CdFlush();

	return;
}

/*
*
*	NAME		u_long CdLoadFile(int fileNo, u_long *memAddr)
*
*	FUNCTION	Loads a file from CD, inputs are the file number
*				and the address to load to. Returns the file size
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav		Created
*
*/
u_long CdLoadFile(int fileNo, u_long* memAddr)
{

	gCurrentFile = fileNo;
	// Initialize CD system and variables for loading the datafile
	CdInitialize(memAddr);

// Start reading CD data and set up callbacks
	StartLoadingCd();

	// while still loading poll the CD system
	while(!DoneLoading())
	{
// You should be able to add whatever you want here to do whilst the
// CD is loading, if disk compression is set then the uncompressing is done
// within CdPoll()
		
		CdPoll();
// Example graphical function
		drawOnVRAM();
	}

#ifdef DEBUG
	sprintf(gDebugLine,"*CdLoadFile*gSectors:%d,Decoded Sectors:%d\n",gSectors,gDecodedSectors);
	WRITEDEBUGLINE
	sprintf(gDebugLine,"*CdLoadFile*Finished Loading:File Size:%d,Expected:%d\n",totalFileSize,CdFileData[gCurrentFile].fileDetails.size);
	WRITEDEBUGLINE
#endif
	// Finished loading, stop the CD system
	StopCd();

// return the filesize
//	return CdSubBuiltSize();
	return totalFileSize;
}

/*
*
*	NAME		void CdInitialize(unsigned long* memAddr)
*
*	FUNCTION	Initializes variables and checks that we can load
*				datafile from CD
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	16/12/97	Mike Kav		Created
*
*/
void CdInitialize(unsigned long* memAddr)
{
	
	CheckLid();

	// Loop until the case lid is shut
	while(gDoorStatus)
	{
		printf("Shut the bloody lid!\n");
		CheckLid();
	}

	// Calculate sectors
	gSectors = Sectors(CdFileData[gCurrentFile].fileDetails.size);

	gDecodedSectors	= 0;
	totalFileSize	= 0;
	readSectors		= 0;
	resetRequest	= 0;

#ifdef DEBUG
	sprintf(gDebugLine,"*CdInitialize* Sectors required%d\n",gSectors);
	WRITEDEBUGLINE
#endif

	// Set up pointers gInitialAddr holds the starting memory location for use in 
	// reinitialising the loading of the file whilst constructAddr
	// is used to load data as it is read in
	constructAddr = gInitialAddr = (unsigned char *)memAddr;
}

/*
*
*	NAME		void StartLoadingCd(void)
*
*	FUNCTION	Checks that case lid is shut, seeks to file and starts
*				reading data. Cd Callbacks are setup to enable data
*				transfer
*
*	NOTES		If DEBUG is set then the sector number is written to
*				'debug.txt', allowing us to check that no sectors are
*				being lost
*				Note that this function does not have a MAX_RETRY_LIMIT
*				but will try to load the file indefinately.
*				Double speed mode is set for each file, this could be moved
*				to the initialization function if you don't use .DA
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	16/12/97	Mike Kav		Created
*
*/
void StartLoadingCd(void)
{
	int ready=0;
	#ifdef DEBUG
		unsigned char CDmode = (CdlModeSpeed|CdlModeRT|CdlModeSize1);
		CdlLOC currentLOC;
	#else
		unsigned char CDmode = (CdlModeSpeed|CdlModeRT);
	#endif

// Loop until ready is set, the following checks are performed:
//	1) Wait for the lid to be shut
//	2) Seek to files position on disk
//	3) Set up callbacks
//	4) Attempt the starting read

// Ready is set to 1 when we have managed to get through the seek and start
// reading the data
	while(!ready)
  	{

		VSync(0);

		CheckLid();
		// Shut the bloody door !
		while(gDoorStatus)
		{
			CheckLid();
		}

		if(!CdControl(CdlSeekL,(unsigned char*)&CdFileData[gCurrentFile].fileDetails.pos,0))
		{
			#ifdef DEBUG
				currentLOC = CdFileData[gCurrentFile].fileDetails.pos;
				sprintf(gDebugLine,"Current file details:%s,%x,%x,%x,%x\n",CdFileData[gCurrentFile].filename,currentLOC.minute,currentLOC.second,currentLOC.sector,currentLOC.track);
				WRITEDEBUGLINE
			#endif
			// break to top, retry
			continue;
		}

		if(!CdControl(CdlSetmode,&CDmode,0))
		{
			printf("** Failed to set double speed\n");
			continue;
		}

// Set up both data and CD callbacks
		CdDataCallback(DataReadyCallBackFunc);
		CdReadyCallback((CdlCB)CdReadyCallBackFunc);

		#ifdef DEBUG
			currentLOC = CdFileData[gCurrentFile].fileDetails.pos;
			sprintf(gDebugLine,"Current file details:%s,%x,%x,%x,%x\n",CdFileData[gCurrentFile].filename,currentLOC.minute,currentLOC.second,currentLOC.sector,currentLOC.track);
			WRITEDEBUGLINE
		#endif

// Start reading
		if(!CdControl(CdlReadN,0,0))
		{
			// bugger, reset callbacks and retry
			printf("** Failed to read data\n");
			CdDataCallback(NULL);
			CdReadyCallback(NULL);
			continue;
		}

		// Hurrah we have started to read the data
		ready=1;	
	}	

	#ifdef DEBUG	
	   	sprintf(gDebugLine,"*StartLoadingCd* File Read Initialized\n");
		WRITEDEBUGLINE
	#endif
	return;
}

/*
*
*	NAME		void CdPoll(void)
*
*	FUNCTION	Called in a loop in CdLoadFile while the file is
*				still loading, reinitializes loading if needed due
*				to the lid being opened or a CdlDiskError
*				This function performs the following
*					Check door status, if the door is not open and no reset
*					has been requested then just check the door otherwise
*					reset callbacks and reinit if necessary
*					Reset request can be set by an error in CdReadyCallback
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	16/12/97	Mike Kav		Created
*
*/
void CdPoll(void)
{
// Check lid has not been lifted
	if(!gDoorStatus && !resetRequest)
	{
		CheckLid();
	}
	else
	{
// If we've received a reset request or the lid has been opened then reset
// and start loading from scratch	
		EnterCriticalSection();
		CdDataCallback(NULL);
		CdReadyCallback(NULL);
		ExitCriticalSection();

		if(resetRequest)
		{
			resetRequest=0;
			#ifdef DEBUG
				sprintf(gDebugLine,"**Received reset\n");
				WRITEDEBUGLINE
			#endif
		}

		CdReInit();			// Reinitialise the load
	}

	return;
}

/*
*
*	NAME		void CdReadyCallBackFunc(int intr,unsigned char* result)
*
*	FUNCTION	
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	16/12/97	Mike Kav		Created
*
*/
void CdReadyCallBackFunc(int intr,unsigned char* result)
{
	unsigned long* currentAddress;
// sector size, used to increment memory location and file size, the final
// sector will probably be less than 2048 and this is calculated from the
// expected file size minus the number of read sectors.
	unsigned short size = FORM1_SIZE;
	unsigned long sectorCheck[3];

	if(intr == CdlDataReady)
	{
		if(readSectors == gSectors)
		{
			#ifdef DEBUG
				sprintf(gDebugLine,"**CdReadyCallBack - Read all of file\n");
				WRITEDEBUGLINE
			#endif
			// Reset Cd Callback as we have finished reading the file,
			// however we may not having finished transferring the data
			CdReadyCallback((CdlCB)NULL);
			return;
		}

		currentAddress = (unsigned long*)constructAddr;
		#ifdef DEBUG
			sprintf(gDebugLine,"**CdReadyCallBack - curAddr:%u constrAddr:%u,read:%d,g:%d\n",currentAddress,constructAddr,readSectors,gSectors);
			WRITEDEBUGLINE
		#endif
			
		// Calculate final size of data as it won't be a full sector
		if(readSectors == gSectors-1)
		{
			#ifdef DEBUG
				sprintf(gDebugLine,"**CdReadyCallBack - Calculating final sector size\n");
				WRITEDEBUGLINE
			#endif
			size = CdFileData[gCurrentFile].fileDetails.size - (readSectors * FORM1_SIZE);
		}

		// Add the amount read, this enables us to set the correct memory location next loop and
		// to calculate the size of the file to compare against the expected file
		constructAddr +=size;
		totalFileSize +=size;

		readSectors++;

		// If we are debugging then get the first thee words as they will be the sector
		// count
		#ifdef DEBUG
			CdGetSector(currentAddress,3);
			sprintf(gDebugLine,"Sec Count:%d ",( CdPosToInt( (CdlLOC *)currentAddress) ) );
			WRITEDEBUGLINE
		#endif
		CdGetSector(currentAddress,Words(size));
	}
	else
	{
		// Line in most used order, might be quicker to OR first two
		if(intr==CdlComplete)
		{
			printf("CdlComplete\n");
			return;
		}
		if(intr==CdlDataEnd)
		{
			printf("CdlDataEnd\n");
			return;
		}
		if(intr== CdlDiskError)
		{
			printf("CdlDiskError\n");
			resetRequest = 1;
		}
	}

	return;
}

/*
*
*	NAME		void DataReadyCallBackFunc(void)
*
*	FUNCTION	Executed when data has been transfered from the CD
*				sector buffer into main memory by CdGetSector
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
void DataReadyCallBackFunc(void)
{
	#ifdef DEBUG
		static int datacallbackCnt;
		datacallbackCnt++;
		sprintf(gDebugLine,"**CdDataCallBack:%d\n",datacallbackCnt);
		WRITEDEBUGLINE
	#endif

		gDecodedSectors++;

	if(readSectors == gSectors)
	{
		CdDataCallBack(NULL);
		printf("DataReadyCallBack ended, file read\n");
		#ifdef DEBUG
			sprintf(gDebugLine,"DataCallback:gSectors:%dgDecoded:%dreadSectors:%d\n",gSectors,gDecodedSectors,readSectors);
			WRITEDEBUGLINE
		#endif		
		gDecodedSectors = gSectors;
	}

	return;
}

/*
*
*	NAME		void CdReInit(void)
*
*	FUNCTION	Restart the file load if the lid is opened
*
*	NOTES		Mike::Check this, when reinit happens does it arse
				up
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
void CdReInit(void)
{
	printf("CD ReInit\n");

	gSectors = Sectors(CdFileData[gCurrentFile].fileDetails.size);
	totalFileSize	= 0;
	gDecodedSectors	= 0;
	readSectors		= 0;
	
	// Set pointer back to start of memory address passed in
	constructAddr = gInitialAddr;

	CheckLid();

	if(gDoorStatus)
		return;
		
	StartLoadingCd();
		
	return;
}

/*
*
*	NAME		void StopCd(void)
*
*	FUNCTION	After file is loaded pause the CD and clear callbacks
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
void StopCd(void)
{
	printf("** Finished loading\n");
	
	// don't stop it, just pause
	CdPause();
	// Clear Callbacks, make sure they don't occur whilst being cleared
	EnterCriticalSection();
	CdDataCallback(NULL);
	CdReadyCallback(NULL);
	ExitCriticalSection();

	return;
}

/*
*
*	NAME		int DoneLoading(void)
*
*	FUNCTION	Check that data is still loading in and return 1 when
*				there is no more data to load
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
int DoneLoading(void)
{

// Check that there is at least one sector to load in
	if ( !gSectors )
		return 1;
	else
		return ( gDecodedSectors >= gSectors );
}

/*
*
*	NAME		void CheckLid(void)
*
*	FUNCTION	Check if the lid is open and set DoorStatus if so
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
void CheckLid(void)
{

	CdControl(CdlNop,0,0);		// To get the very latest CD status
	gDoorStatus = (CdStatus() & CdlStatShellOpen);

	return;
}

/*
*
*	NAME		void drawOnVRAM(void)
*
*	FUNCTION	Test function that just rotates a colour whilst a file
*				is loading
*
*
*	NOTES		
*
*	CHANGED		PROGRAMMER		REASON
*	-------  	----------  	------
*	17/12/97	Mike Kav		Created
*
*/
void drawOnVRAM(void)
{
	RECT theRect;
	static int fade=255;

	setRECT(&theRect,0,0,320,480);
	ClearImage(&theRect,fade,0,0);
	fade-=10;
        if(fade<0)
                fade=255;

	DrawSync(0);
}
