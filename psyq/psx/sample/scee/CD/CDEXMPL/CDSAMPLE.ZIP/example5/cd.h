/* CD header to load data files from CD.
*
*	NOTES		
*
*	CHANGED		PROGRAMMER	REASON
*	-------  	----------  	------
*	15/12/97	Mike Kav	Created
*
*/
/*
	FILEDETAILS structure holds the cd filename (for use with
		CdSearchFile) and CdlFILE details. CdlFILE contains
		CdlLOC for the file position, the size and the filename 
*/

#define MAXFILELEN		50
#define RETRY_ATTEMPTS	10

#define FORM1_SIZE	2048
#define Sectors(x)	(((x)+2048-1)/2048)
#define Words(x)	(((x)+3) / 4)


typedef struct
{
	char filename[MAXFILELEN];
	CdlFILE fileDetails;       	
}FILEDETAILS;

#define ANALOG			0
#define WARNING			1
#define SONY			2
#define BACK			3
#define TILES			4
#define MEMORY			5

void	DisplayFilePositions(void);
int		CacheFilePos(void);
void	CreateFullFile(char *source, char *dest);
void	InitCd(void);
void	DeInitCd(void);
u_long	CdLoadFile(int fileNo, u_long* memAddr);
void	CdInitialize(unsigned long* memAddr);
void	StartLoadingCd(void);
void	CdPoll(void);
void	CdReadyCallBackFunc(int intr,unsigned char* result);
void	DataReadyCallBackFunc(void);
void	CdReInit(void);
void	StopCd(void);
int		DoneLoading(void);
void	CheckLid(void);
void	drawOnVRAM(void);