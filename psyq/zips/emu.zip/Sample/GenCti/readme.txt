August 11, 1997.

This sample directory contains a sample "Test.cti" 
output file from the "GenCTI" program.  
Refer to the "GenCTI" instructions in the "readme.doc"
of this distribution for more details on the syntax
of GenCTI.

Please note that "GenCTI" was never updated beyond 1.0beta.
For more details on the CTI syntax, refer to the CD Emulator
manual.