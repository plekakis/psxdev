PlayStation Programmer's Tool
CD-ROM Generator Version 1.30 

For installation with Windows 3.1 or Windows 95
run the SETUP.EXE, and follow the onscreen instructions

Please refer to the CD-ROM Generator User's Manual 
for more info.

This version has been successfully tested using the
CDU-921S/CDU920S Drives under Windows 95.

It may have problems with the CDW 900e under Windows 95.




		(C)Copyright 1994,1995,1996 Sony Conputer Entertaiment Inc.
				All rights reserved.