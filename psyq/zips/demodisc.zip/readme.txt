DEMOSPEC.ZIP

This zip file contains DEMOSPEC.TXT and DEMOSPEC.DOC, originally hidden away in the SAMPLER.ZIP archive.
Both files are different versions of the same document, which describes the describing how the playable 
game segments should be constructed.

