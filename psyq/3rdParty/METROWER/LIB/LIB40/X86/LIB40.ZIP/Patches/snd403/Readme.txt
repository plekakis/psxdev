FILE: 
snd43e.zip

DATE: 
July 14, 1997


INSTRUCTIONS:
Use pkunzip or WinZip to unzip the contents of this file into a temporary directory,
such as "c:\tmp".  Then move the contents of the "c:\tmp\lib" directory into your
usual "lib" directory (such as "c:\ps\psx\lib") and move the contents of the 
"c:\tmp\include" directory into your usual "include" directory (such as "c:\ps\psx\include").

CONTENTS:
The "zip" file contains the following ECOFF formatted library files for our Metrowerks
CodeWarrior users:

	libsnd.a (version 4.0.3).  
	libspu.a (version 4.0.1).
	
You must convert these files to CodeWarrior's format, as described in the 
CodeWarrior documentation that came with your development kit.
These files contain the following changes:

	- When using SsSetSeq(Sep)Decrescendo/SsSetSeq(Sep)Crescendo,
	  the volume can now be changed more smoothly.

	- When calling SsSeqStop and SsSeqClose consecutively, all the
	  sound can be stopped completely.
	  (In version 4.0.1, the long release sound remained.)


REMARKS:
	There are no changes in libsnd.h from version 4.0.1.
	When using libsnd.lib(version 4.0.3), please use libspu.lib
	(version 4.0.1).

-------------------------------------------------------------
Copyright (c) 1997. Sony Computer Entertainment America Inc.