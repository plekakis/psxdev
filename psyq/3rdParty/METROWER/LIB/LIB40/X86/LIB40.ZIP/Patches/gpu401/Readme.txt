
        libgpu.lib ver.4.0.1

        DR_STP structure and SetDrawStp function are added.

============================================================================
DR_STP
============================================================================
                                           STP bit process change primitives

Structure
        typedef struct {
                u_long tag;
                u_long code[2];
        } DR_STP;

Members
        tag     Hook to the next primitives (reserved)
        code    Primitive ID

Explanation
        The DR_STP primitive modifies only the STP bit process in the middle
        of the drawing.
        The SetDrawStp() function is used to set contents.

============================================================================
SetDrawStp
============================================================================
                 Initializes the content of STP bit process change primitive

Syntax
        void SetDrawStp (
        DR_STP *p,
        int pbw
        )

Arguments
        p       Primitive start address
        pbw     Flag of set STP bit (0:STP OFF, 1: STP ON)

Explanation

        This function initializes the STP bit process change primitives.
        pbw specified value is listed below.

        -------------------------------------------------
        pbw     Action
        -------------------------------------------------
        0       Normal drawing
        1       Set STP bits of frame buffers in drawing
        -------------------------------------------------

============================================================================
Copyright (C) 1997. Sony Computer Entertainment Inc.
