Date: 
October 1, 1997.


Contents:
This directory contains a number of patches released
by SCE.  In order to recreate the latest version of this
library, please install them in this order:

1. gpu401
2. gsgte402
3. snd403
4. snd404

----------------------------------------------------
Copyright (C) 1997.  Sony Computer 