Date: October 1, 1997

Contents:

This directory contains patches for Library 3.7.  In order
update the main library 3.7 to the latest version, 
you can just move these files into your library directory.


-------------------------------------------------------
Copyright (C) 1997. Sony Computer Entertainment Inc.
