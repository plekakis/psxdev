ECOFF 3.7.5.  March 13, 1997.

This "zip" file contains two files, "libcomb.h" and "libcomb.a" in ECOFF format, 
which you should replace in your current library 3.7.3 directories. 

This  libcomb fixes the bug that caused the system to hang up on rare occasions 
when returning to the menu from a process child using overlays, after the 
completion of  a combat communication  session.  This bug was caused by  
inappropriate handling of the libcomb asynchronous communication process. 


----------------------------------------------------------------
(C) Copyright 1997. Sony Computer Entertainment America Inc.
