To licensees
                                                            Nov. 10, 1998
                                                                 R&D Div.
                                         Sony Computer Entertainment Inc.


		Libds version 4.4.1 (bug-fixed version)

Libds(.lib, .a) will be released. The following malfunction has been fixed
in this version. Please use this version if your title under development 
uses the libds and it requires disc change.

< Symptom >
With DsGetDiskType(), an infinite loop might occur in the library when 
recognizing a disc other than the PlayStation disc. 

< Remedy >
The error handling for the command issue to the CD subsystem has been 
enforced.

< Contents of this package >
libds.lib	ver.4.4.1
libds.a		ver.4.4.1 (for NEWS/CodeWarrior)
libds.h		
readme_e.txt	this file

< Note >
This symptom doesn't occur with the similar function, CdGetDiskType(), 
of the libcd.


