Lib 3.6.2 consisted of patches to libapi.lib and libtap.lib.  
However, these are identical in functionality to those in 
Library 3.7.  The only difference is the additional embedding 
of version information in library 3.7. 

Please  use those versions of the library 
to upgrade a library 3.6 configuration to 3.6.2.