To: Licensees
				                 November 11, 1997
		                                               R&D 
                                   Sony Computer Entertainment Inc.


     libpress.lib version 4.1.1

libpress.lib version.4.1.1. will be released. The following 
malfunctions in libpress.lib version.4.1 have been fixed in 
this version 4.1.1.

[Symptom]
The decode size obtained using DecDCTBufSize() is not the same as 
that obtained using DecDCTvlc() nor and DecDCTvlc2().  To be 
more specific, excess 33 words of memory was overwritten besides the 
number of words required for decoding. 

[Remedy]
Use libpress.lib (version.4.1.1) or libpress.a (version.4.1.1) in 
which the malfunctions above have been fixed. These are contained 
in this package.

[Problems Fixed]
Before the problem fix, the buffer size needed for carrying out VLC decoding 
was as follows:

	| size | ranlevel DATA  |    NOP     |
	 1word      sizeword          32word

Thus the buffer size required for decoding runlevel by using 
DecDCTvlc()/DecDCTvlc2() was (DecDCTbufSize() + 33) words.

With the problem fix, unnecessary NOP was deleted and the buffer 
size required for decoding is: 

	DecDCTBufSize() + header(1 word) or
	(DecDCTBufSize() + 1) words.

[Remarks]
(1)Note that this modification has not been reflected in library 
   version.4.1 CD-ROM DTL-S2330 which will be distributed in the 
   beginning of November.
(2)This package contains libpress.lib version.4.1.1 of both DOS/V(PC) 
   and NEWS/CodeWarrior versions.  Use the one you need.

   libpress.lib version.4.1.1	DOS/V(PC) version
   libpress.a version.4.1.1	NEWS/CodeWarrior version

							
